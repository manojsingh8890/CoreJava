package com.ibm.sec.service;

import com.ibm.sec.model.AlgosecObject;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * An instance of this class is supposed to hold network and service objects and their values given as input.
 * It also should contain device specific network and service objects and their values.
 */
@Setter
@Getter
public class ObjectsData {

    private Map<String, Map<String, String>> deviceNameNetworkObjectDetailsMapAsInAlgosec;
    private Map<String, Map<String, List<String>>> deviceNameServiceObjectDetailsMap;
    private Map<String, List<AlgosecObject>> algosecObjectNameObjectMap = new HashMap<>();

}
