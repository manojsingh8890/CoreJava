package com.ibm.sec.controller;


import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/swagger")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SwaggerController {
    private final ResourceLoader resourceLoader;

    @GetMapping
    public String swagger() throws IOException {
        Resource resource = resourceLoader.getResource("classpath:swagger.yml");
        return StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
    }
}