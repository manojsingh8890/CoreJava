package com.ibm.sec.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AlgosecObject {
    private String objectName;
    private List<String> values;
    private String algosecDeviceName;
}
