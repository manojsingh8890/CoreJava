package com.ibm.sec.repository;

import com.ibm.sec.model.FirewallChangeEntity;
import com.ibm.sec.util.IConstant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FirewallChangeRepository extends JpaRepository<FirewallChangeEntity, Integer>{

    List<FirewallChangeEntity> findBySessionIdAndAlgoSecChangeRetentionTypeAndChangeTypeIn(String sessionId, IConstant.AlgosecChangeRententionType algoSecChangeRetentionType, List<IConstant.AlgosecChangeType> changeTypes);
	
//	FirewallChangeEntity findByChangeId(String firewallChangeId);
//
//	FirewallChangeEntity findByItsmId(String firewallItsmId);
//
//	@Modifying
//	@Query(
//    value = "SELECT * FROM firewall_change f WHERE f.Status = 'NEW' AND f.Timestamp <= DATE_SUB(NOW(), INTERVAL :intervalHours HOUR)",
//    nativeQuery = true)
//    List<FirewallChangeEntity> findAllLastDateNewFirewallChange(@Param("intervalHours") int intervalHours);

}
