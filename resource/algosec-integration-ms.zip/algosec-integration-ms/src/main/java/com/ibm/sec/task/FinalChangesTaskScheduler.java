package com.ibm.sec.task;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class FinalChangesTaskScheduler {

    @Autowired
    private ObjectChangeCompletionTracker objectChangeCompletionTracker;

    /**
     * Runs a task every 10s for checking the status of final object change request, and if it is in 'resolved' status then create/delete final policies
     */
    @Scheduled(fixedDelay = 10 * 1000L)
    public void scheduledObjectChangeCreationTask() {
        log.info("Running ObjectChangeProcessor::" + Thread.currentThread().getName() + ": scheduled1");
        try {
            objectChangeCompletionTracker.checkObjectChangeCompletion();
        } catch (Exception e) {
            log.error("Error processing object creation task", e);
        }
        log.info("Finished ObjectChangeProcessor::" + Thread.currentThread().getName() + ": scheduled1");
    }
}
