package com.ibm.sec.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.ibm.sec.util.IConstant;
import org.springframework.stereotype.Component;

@Component
public class ObjectsUtil {

    public boolean shouldProcessObjectChange(JsonNode objectChangeNode) {
        String objectType = objectChangeNode.get("object_type").asText();
        return IConstant.APPLICABLE_OBJECT_TYPES.contains(objectType);
    }
}
