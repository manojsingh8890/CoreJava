package com.ibm.sec.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Represents an error in response returned by the API when an error occurs.
 */
@Getter
@Setter
@NoArgsConstructor
public class Error {

    private String code;
    private String message;
}
