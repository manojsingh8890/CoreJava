package com.ibm.sec.model.algosec;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FireFlowAPIAuthResponse {
    private String sessionId;
    private String faSessionId;
    private String phpSessionId;
    private Date algosecSessionCreationTime;
}
