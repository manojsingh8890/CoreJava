package com.ibm.sec.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import io.micrometer.core.instrument.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.error.ErrorConfig;
import com.ibm.sec.model.Devices;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.util.IConstant;
import com.ibm.sec.util.JsonUtil;

import reactor.core.publisher.Mono;

/**
 * Holds data of the devices passed in as input. Also, provides various information/validation on these devices.
 */
@Component
public class DeviceService {

    @Autowired
    private ApplicationService applicationService;
    @Autowired
    private ErrorConfig errorConfig;
    @Autowired
    private JsonUtil jsonUtil;
    @Autowired
    private ObjectsUtil objectsUtil;

    /**
     * Does the following:
     * 1. Validates if devices are algosec enabled.
     * 2. Gets and keeps algosec device names for the given remedy device names.
     * @param firewallChanges input firewall changes json
     * @throws JsonProcessingException If any error in parsing JSON response from services called from this method
     */
    public Devices fetchDeviceInfo(JsonNode firewallChanges, UserSession session, boolean callAsAdmin, IConstant.AlgosecChangeRententionType changeRententionType) throws JsonProcessingException {
        if (changeRententionType == IConstant.AlgosecChangeRententionType.TEMPORARY) {
            boolean tempChangesValid = checkIfTemporaryChangesRequired(firewallChanges);
            if (!tempChangesValid) {
                throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), IConstant.NOT_TEMP_ACTIONABLE_WORK);
            }
        } else {
            checkIfAlgosecActionableWork(firewallChanges);
        }
        Devices devices = new Devices();
        Set<String> remedyDeviceNamesSet = new LinkedHashSet<>();
        if (firewallChanges.has(IConstant.POLICY_UPDATE_CHANGES)) {
            JsonNode policyUpdateNode = firewallChanges.get(IConstant.POLICY_UPDATE_CHANGES);
            String policyUpdateString = jsonUtil.toString(policyUpdateNode);
            remedyDeviceNamesSet.addAll(jsonUtil.getFieldValuesAsText(policyUpdateString, "$.[*].firewall_policy"));
        }
        if (firewallChanges.has(IConstant.OBJECT_UPDATE_CHANGES)) {
            JsonNode objectUpdateNode = firewallChanges.get(IConstant.OBJECT_UPDATE_CHANGES);
            String objectUpdateString = jsonUtil.toString(objectUpdateNode);
            remedyDeviceNamesSet.addAll(jsonUtil.getFieldValuesAsText(objectUpdateString, "$.[*].firewall_policy"));
        }
        devices.getRemedyDeviceNames().addAll(remedyDeviceNamesSet);
        String devicesNames = prepareDeviceNamesInput(List.copyOf(remedyDeviceNamesSet));
        String devicesResponse = applicationService.getDevicesWithHostName(session, devicesNames, callAsAdmin).block();
        String deviceIdsString = validateDeviceResponse(devicesNames, devicesResponse);
        devices.getRemedyDeviceIds().addAll(Arrays.asList(deviceIdsString.split(",")));
        JsonNode deviceResponseNode = jsonUtil.parse(devicesResponse);
        Map<String, String> remedyDeviceNameAlgosecNameMap = new HashMap<>();
        for (JsonNode valueNode : deviceResponseNode) {
            String hostName = valueNode.get("hostName").asText();
            if (!valueNode.has("algoSecUniqueName") || StringUtils.isEmpty(valueNode.get("algoSecUniqueName").asText())) {
                throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), errorConfig.getMessage().getNoAlgosecEnabledDeviceFound());
            }
            String algoSecUniqueName = valueNode.get("algoSecUniqueName").asText();
            remedyDeviceNameAlgosecNameMap.put(hostName, algoSecUniqueName);
        }
        devices.getRemedyDeviceNameAlgosecNameMap().putAll(remedyDeviceNameAlgosecNameMap);
        return devices;
    }

    /**
     * This method is used to get host name by supply algosec unique ids to device ms
     * @param map of change ids and algosec unique id, user session
     * @throws JsonProcessingException If any error in parsing JSON response from services called from this method
     */
    public Map<String, String> fetchDeviceInfo(Map<String, String> changeIdsalgosecUniqueNames, UserSession session) throws JsonProcessingException {
    	List<Mono<String>> monos = new ArrayList<>();
        List<String> changeIds = new ArrayList<>();
        Map<String, String> resultMap = new HashMap<>();
        changeIdsalgosecUniqueNames.entrySet().forEach(changeIdalgosecUniqueName -> {
        	changeIds.add(changeIdalgosecUniqueName.getKey());
        	monos.add(applicationService.getDevicesWithalgoSecUniqueName(session, changeIdalgosecUniqueName.getValue(), true));
		});

        Object[] allResults = Mono.zip(monos, values -> {
            return values;
        }).block();

        resultMap = IntStream.range(0, changeIds.size()).boxed()
        		.collect(Collectors.toMap(i -> changeIds.get(i), i -> {
        			String devicesResponse = (String) allResults[i];
        			String hostName = "";
					try {
						ArrayNode deviceResponseNode = (ArrayNode) jsonUtil.parse((String)devicesResponse);
						hostName =  deviceResponseNode.get(0).get("hostName").asText();
					} catch (JsonProcessingException e) {
						throw new BusinessLogicException(errorConfig.getHttpStatus().getInternalError(),errorConfig.getCode().getInternalError(), errorConfig.getMessage().getInternalError());
					}
        			return hostName;
        		}));

        return resultMap;
    }

//    /**
//     * Returns remedy names of the input devices.
//     * @return Remedy names of devices
//     */
//    public List<String> getRemedyDeviceNames() {
//        return remedyDeviceNames;
//    }
//
//    /**
//     * Returns algosec names of the input devices.
//     * @return Algosec names of devices
//     */
//    public Map<String, String> getAlgosecDeviceNames() {
//        return algosecDeviceNames;
//    }
//
//    /**
//     * Returns remedy ID of input devices.
//     * @return
//     */
//    public List<String> getRemedyDeviceIds() {
//        return remedyDeviceIds;
//    }

    /**
     * Returned a comma separated concatenated string from the given list of device names.
     * This string is used as input for calling device service to fetch details of the devices.
     * @param devicesNames Remedy names of input devices
     * @return Comma separated string of remedy device names
     */
    private String prepareDeviceNamesInput(List<String> devicesNames) {
        return String.join(",", devicesNames);
    }

    /**
     * Returns a comma separated string of remedy device ids for the given remedy device names from the device service response.
     * @param devicesNames Remedy names of input devices
     * @param devicesResponse Response from device service for the given input devices
     * @return Comma separated string of device ids
     */
    private String validateDeviceResponse(String devicesNames, String devicesResponse) {
        List<String> deviceIds = jsonUtil.getFieldValuesAsText(devicesResponse, "$.[*].id");
        if (deviceIds.isEmpty()) {
            throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), errorConfig.getMessage().getNoDeviceFound());
        }
        if (devicesNames.split(",").length != deviceIds.size()) { //requested device count does not match with actual device count
            throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), errorConfig.getMessage().getIncorrectDeviceCount());
        }
        return String.join(",", deviceIds);
    }


    /**
     * Checks if the json payload is valid to make final change requests
     *
     * @param firewallChangesNode
     */
    private void checkIfAlgosecActionableWork(JsonNode firewallChangesNode) {
        Boolean algosecActionable = false;
        if ((firewallChangesNode.has(IConstant.POLICY_UPDATE_CHANGES) && firewallChangesNode.get(IConstant.POLICY_UPDATE_CHANGES).size() > 0)) {
            JsonNode policyUpdateNode = firewallChangesNode.get(IConstant.POLICY_UPDATE_CHANGES);
            for (int i = 0; i < policyUpdateNode.size(); i++) {
                JsonNode policyUpdateRequestNode = policyUpdateNode.get(i);
                if ((policyUpdateRequestNode.has("action")) &&
                        (IConstant.CHANGE_ACTION_TYPE_CREATE.equals(policyUpdateRequestNode.get("action").asText()) ||
                        IConstant.ALGOSEC_ACTION_TYPE_DELETE.equals(policyUpdateRequestNode.get("action").asText()))) {
                    algosecActionable = true;
                    break;
                }
            }
        }
        if (!algosecActionable) {
            if ((firewallChangesNode.has(IConstant.OBJECT_UPDATE_CHANGES) && firewallChangesNode.get(IConstant.OBJECT_UPDATE_CHANGES).size() > 0)) {
                JsonNode objectUpdateNode = firewallChangesNode.get(IConstant.OBJECT_UPDATE_CHANGES);
                for (int i = 0; i < objectUpdateNode.size(); i++) {
                    JsonNode objectUpdateRequestNode = objectUpdateNode.get(i);
                    if((objectUpdateRequestNode.has("object_type")) && (objectsUtil.shouldProcessObjectChange(objectUpdateRequestNode))) {
                        algosecActionable = true;
                        break;
                    }
                }
            }
        }

        if(!algosecActionable){
            throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), errorConfig.getMessage().getNoAlgosecActionableWorkFound());
        }

    }

    /**
     * If atleast one Create action is present in Policy Update tab then temporary change is valid
     * @param firewallChangesNode
     * @return
     */
    private boolean checkIfTemporaryChangesRequired(JsonNode firewallChangesNode) {
        if ((firewallChangesNode.has(IConstant.POLICY_UPDATE_CHANGES) && firewallChangesNode.get(IConstant.POLICY_UPDATE_CHANGES).size() > 0)) {
            JsonNode policyUpdateNode = firewallChangesNode.get(IConstant.POLICY_UPDATE_CHANGES);
            for (int i = 0; i < policyUpdateNode.size(); i++) {
                JsonNode policyUpdateRequestNode = policyUpdateNode.get(i);
                if ((policyUpdateRequestNode.has("action")) &&
                        (IConstant.CHANGE_ACTION_TYPE_CREATE.equals(policyUpdateRequestNode.get("action").asText()))) {
                    return true;
                }
            }
        }
        return false;
    }
}