package com.ibm.sec.repository;

import com.ibm.sec.model.FirewallChangeSessionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FirewallChangeSessionRepository extends JpaRepository<FirewallChangeSessionEntity, Integer> {
    FirewallChangeSessionEntity findBySessionId(String sessionId);
}