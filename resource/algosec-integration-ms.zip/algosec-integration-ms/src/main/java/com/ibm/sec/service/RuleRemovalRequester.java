package com.ibm.sec.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.error.ErrorConfig;
import com.ibm.sec.model.AlgosecChangeId;
import com.ibm.sec.model.Devices;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.model.algosec.RuleRemovalChangeRequest;
import com.ibm.sec.model.algosec.Field;
import com.ibm.sec.model.algosec.RequestAction;
import com.ibm.sec.util.IConstant;
import com.ibm.sec.util.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;

import java.util.*;
import java.util.stream.Collectors;

import static com.ibm.sec.util.IConstant.ALGOSEC_ACTION_TYPE_DELETE;
import static com.ibm.sec.util.IConstant.ALGOSEC_ACTION_REMOVE;
/**
 * This class takes Policy Update section of PCR Firewall template, generates the Rule Removal request and calls the algosec APIs
 * to generate a change ID.
 */
@Component
@Slf4j
public class RuleRemovalRequester implements ChangeRequester {

    @Autowired
    private AlgosecService service;
    @Value("${policy_rule_removal_request_template}")
    private String ruleRemovalRequsetTemplateName;
    @Autowired
    private JsonUtil jsonUtil;
    @Autowired
    private ErrorConfig errorConfig;
    /**
     * This method creates Rule Removal Requests in Algosec
     * @param firewallChanges Input Json for traffic change
     * @param devices
     * @param changeRententionType TEMPORARY / FINAL*/
    @Override
    public List<AlgosecChangeId> createChangeRequest(JsonNode firewallChanges, Devices devices, IConstant.AlgosecChangeRententionType changeRententionType, ObjectsData objectsData, UserSession session) throws JsonProcessingException {
        List<AlgosecChangeId> changeIds = new ArrayList<>();
        if (firewallChanges.has(IConstant.POLICY_UPDATE_CHANGES)) {
            JsonNode policyUpdateNode = firewallChanges.get(IConstant.POLICY_UPDATE_CHANGES);
            Map<String, List<JsonNode>> remedyDeviceNameDeleteChangeMap = new HashMap<String, List<JsonNode>>();

            for (int i = 0; i < policyUpdateNode.size(); i++) {
                JsonNode policyUpdateRequestNode = policyUpdateNode.get(i);
                if (ALGOSEC_ACTION_TYPE_DELETE.equals(policyUpdateRequestNode.get("action").asText())) {
                    String firewallPolicy = policyUpdateRequestNode.get("firewall_policy").asText();
                    if (!remedyDeviceNameDeleteChangeMap.containsKey(firewallPolicy)) {
                        remedyDeviceNameDeleteChangeMap.put(firewallPolicy, new ArrayList<JsonNode>());
                    }
                    remedyDeviceNameDeleteChangeMap.get(firewallPolicy).add(policyUpdateRequestNode);
                }
            }
//            if (!remedyDeviceNameDeleteChangeMap.isEmpty()) {
//                //map remedy device names to algosec device names
//                // ... some other Stream processings
//                for (Map.Entry<String, List<JsonNode>> createRequest : remedyDeviceNameDeleteChangeMap.entrySet()) {
//                    toAlgosecRuleRemovalRequestForPolicyUpdate(createRequest.getValue(), algosecDeviceNames, createRequest.getKey()));
////                    log.info("Change request::" + jsonUtil.toString(changeReqNumberToAlgosecTrafficChangeReqMapping.getRequest()));
////                    String sessionId = session.getSessionId();
////                    log.debug("SessionId: " + sessionId);
////                    changeId.setChangeId(String.valueOf(service.createChangeRequest(changeReqNumberToAlgosecTrafficChangeReqMapping.getRequest())));
////                    changeId.setSourceRequestNumbers(changeReqNumberToAlgosecTrafficChangeReqMapping.getSourceRequestNumbers());
//
//                }
//            }
            if (!remedyDeviceNameDeleteChangeMap.isEmpty()) { //if there are rules to delete
                //fetch existing rules from devices first
                List<String> algosecDeviceNames = remedyDeviceNameDeleteChangeMap.keySet().stream().map(remedyDeviceName -> devices.getRemedyDeviceNameAlgosecNameMap().get(remedyDeviceName)).collect(Collectors.toList());
                Object[] ruleDetailsByDevices = service.getRuleInformation(algosecDeviceNames, session);
                Map<String, List<String>> algosecDeviceNameRuleListMap = new HashMap<>();
                for(int i = 0; i < ruleDetailsByDevices.length; i++) {
                    List<String> ruleIdsByDevice = jsonUtil.getFieldValuesAsText((String) ruleDetailsByDevices[i], "$.*.ruleId");
                    algosecDeviceNameRuleListMap.put(algosecDeviceNames.get(i), ruleIdsByDevice);
                }

                List<RuleRemovalChangeRequest> algosecRuleRemovalChangeRequestObjects = createAlgosecRuleRemovalChangeRequestObjects(remedyDeviceNameDeleteChangeMap, algosecDeviceNameRuleListMap, devices);
                if (!algosecRuleRemovalChangeRequestObjects.isEmpty()) {
                    Object[] responses = service.createRuleRemovalRequest(algosecRuleRemovalChangeRequestObjects, session);
                    for (int r = 0; r < responses.length; r++) {
                        ClientResponse response = (ClientResponse) responses[r];
                        ResponseEntity<String> responseEntity = response.toEntity(String.class).block();
                        String responseBody = responseEntity.getBody();
                        if (response.rawStatusCode() != 200) {
                            log.error("SessionId: " + session.getSessionId() + " traffic change request: " + jsonUtil.toString(algosecRuleRemovalChangeRequestObjects.get(r)) + ", response: " + responseBody + ", IsError? TRUE http code: " + response.rawStatusCode());
                            //log.error("Algosec rule removal change request API call failed with http status code:" + response.rawStatusCode() + " and error response is:" + responseBody);
                            throw new BusinessLogicException(errorConfig.getHttpStatus().getInternalError(), errorConfig.getCode().getInternalError(), errorConfig.getMessage().getInternalError());
                        } else {
                            log.info("SessionId: " + session.getSessionId() + " traffic change request: " + jsonUtil.toString(algosecRuleRemovalChangeRequestObjects.get(r)) + ", response: " + responseBody + ", IsError? FALSE");
                            AlgosecChangeId changeId = new AlgosecChangeId();
                            changeId.setChangeId(String.valueOf(jsonUtil.getFieldValueAsInt(responseBody, "$.data.changeRequestId")));
                            changeId.setChangeType(IConstant.AlgosecChangeType.POLICY_DELETE);
                            changeIds.add(changeId);
                        }
                    }
                }
            }
        }
        return changeIds;
    }

    private List<RuleRemovalChangeRequest> createAlgosecRuleRemovalChangeRequestObjects(Map<String, List<JsonNode>> remedyDeviceNamePolicyCreateChangeNodesMap, Map<String, List<String>> algosecDeviceNameRuleListMap, Devices devices) throws JsonProcessingException {
        List<RuleRemovalChangeRequest> changeRequestObjects = new ArrayList<>();
        Set<Map.Entry<String, List<JsonNode>>> set = remedyDeviceNamePolicyCreateChangeNodesMap.entrySet();
        for(Map.Entry<String, List<JsonNode>> entry : set) {
            String remedyDeviceName = entry.getKey();
            List<JsonNode> deleteActionNodes = entry.getValue();

            RuleRemovalChangeRequest request = new RuleRemovalChangeRequest();
            request.setTemplate(ruleRemovalRequsetTemplateName);

            Field devicesField = new Field();
            devicesField.setName("devices");
            String algosecDeviceName = devices.getRemedyDeviceNameAlgosecNameMap().get(remedyDeviceName);
            devicesField.setValues(Arrays.asList(algosecDeviceName));
            request.setFields(Arrays.asList(devicesField));
            List<RequestAction> requestActions = new ArrayList<>(deleteActionNodes.size());

            for (int i = 0; i < deleteActionNodes.size(); i++) {
                JsonNode deleteNode = deleteActionNodes.get(i);
                RequestAction requestAction = new RequestAction();
                requestAction.setAction(ALGOSEC_ACTION_REMOVE);
                String ruleId = deleteNode.has("rule_id") ? deleteNode.get("rule_id").asText() : "";
                if(algosecDeviceNameRuleListMap.containsKey(algosecDeviceName) && algosecDeviceNameRuleListMap.get(algosecDeviceName).contains(ruleId)) {
                    requestAction.setRuleId(ruleId);
                    requestActions.add(requestAction);
                }
            }
            if (!requestActions.isEmpty()) {
                request.setRequestActions(requestActions);
                changeRequestObjects.add(request);
            }
        }
        return changeRequestObjects;
    }
}
