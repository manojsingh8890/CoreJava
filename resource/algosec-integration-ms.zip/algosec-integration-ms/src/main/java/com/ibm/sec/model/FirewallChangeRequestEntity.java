package com.ibm.sec.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@EqualsAndHashCode
@Entity
@Table(name = "firewall_change_request")
public class FirewallChangeRequestEntity implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;

    @Column(name = "SESSION_ID")
    private String sessionId;

    @Column(name = "CHANGE_REQUEST")
    private String changeRequest;
}
