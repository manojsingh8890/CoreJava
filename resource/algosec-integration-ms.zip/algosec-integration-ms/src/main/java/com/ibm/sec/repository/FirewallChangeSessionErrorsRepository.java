package com.ibm.sec.repository;

import com.ibm.sec.model.FirewallChangeSessionErrorsEntity;
import com.ibm.sec.util.IConstant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FirewallChangeSessionErrorsRepository extends JpaRepository<FirewallChangeSessionErrorsEntity, Integer> {
    List<FirewallChangeSessionErrorsEntity> findBySessionIdAndFunctionality(String sessionId, IConstant.Functionality functionality);
}