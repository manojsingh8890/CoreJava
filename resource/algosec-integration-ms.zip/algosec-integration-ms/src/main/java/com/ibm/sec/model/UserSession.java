package com.ibm.sec.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

/**
 * Represents the calling user's session for the duration of processing of a request. If used as spring bean it must be request scoped.
 */
@Getter
@Setter
@NoArgsConstructor
public class UserSession {

    private String authHeaderValue;
    private Claims claims;
    private String threadUuid;

    public String getUserName() { return claims == null ? "" : claims.getUserName(); }
    public String getCustomerId() { return claims == null ? "": claims.getCustomerId(); }
    public String getThreadUuid() { return threadUuid == null ? "" : threadUuid; }
    public String getAuthHeaderValue() { return authHeaderValue; }

    private String algoSecSessionId;
    private String algoSecFaSessionId;
    private String algoSecPhpSessionId;
    private Date algosecSessionCreationTime;
    private String sessionId;
}