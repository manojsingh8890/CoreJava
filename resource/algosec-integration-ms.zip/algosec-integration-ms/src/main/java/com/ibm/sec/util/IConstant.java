package com.ibm.sec.util;

import java.util.Arrays;
import java.util.List;

public interface IConstant {
	public static final String USER_SESSION_REQ_ATTR_KEY = "USER_SESSION";
//	public static final String CHANGE_TYPE_POLICY_CREATE = "POLICY_CREATE";
//	public static final String CHANGE_TYPE_POLICY_DELETE = "POLICY_DELETE";
//	public static final String CHANGE_TYPE_OBJECT = "OBJECT";
	public static final String POLICY_UPDATE_CHANGES = "Policy Update";
	public static final String OBJECT_UPDATE_CHANGES = "Object Update";
	public static final String CHANGE_ACTION_TYPE_CREATE = "Create";
	public static final String ALGOSEC_CHANGE_ACTION_TYPE_ALLOW = "Allow";
	public static final String ALGOSEC_ACTION_TYPE_DELETE = "Delete";
	public static final String ALGOSEC_ACTION_TYPE_ADD_TO = "Add To";
	public static final String ALGOSEC_ACTION_TYPE_REMOVE_FROM = "Remove From";
	public static final String ALGOSEC_ACTION_REMOVE = "remove";
	public static final String OBJECT_CHANGE_REQUEST_COMPLETION_STATUS = "resolved";
	public static final String MSS_TOKEN = "MSSToken";

	//types of objects
	public static final String OBJECT_GROUP_TYPE_GROUP_OBJECT = "Group Object";
	public static final String OBJECT_GROUP_TYPE_HOST = "Host";
	public static final String OBJECT_GROUP_TYPE_NETWORK = "Network";
	public static final String OBJECT_GROUP_TYPE_SERVICE = "Service";
	public static final String OBJECT_GROUP_TYPE_SERVICE_GROUP = "Service Group";
	public static final String OBJECT_GROUP_TYPE_NETWORK_GROUP = "Network Group";
	public static final List<String> APPLICABLE_OBJECT_TYPES = Arrays.asList(OBJECT_GROUP_TYPE_NETWORK, OBJECT_GROUP_TYPE_HOST,OBJECT_GROUP_TYPE_SERVICE,OBJECT_GROUP_TYPE_SERVICE_GROUP,OBJECT_GROUP_TYPE_NETWORK_GROUP);

	public static final String CHANGE_ID_STATUS_UPDATED = "statusUpdated";
	public static final String CHANGE_ID_STATUS_NOT_UPDATED = "statusNotUpdated";
	public static final String NO_RISK_FOUND = "No risks were found";
	public static final String RISK_NOT_YET_GENERATED = "Risk report not yet generated";
	public static final String UNABLE_TO_GENERATED_RISK = "Unable to generate risk report";
	public static final String NOT_TEMP_ACTIONABLE_WORK = "No temporary actionable work found";

	public static final String ANY = "ANY";

	public static final int MIN_PORT_NUMBER = 1;
	public static final int MAX_PORT_NUMBER = 65535;

	public static final String POLICY_MGMT_TICKET_ID = "policyManagementTicketId";
	public static final String WORKLOG_TEXT = "worklogText";

	public enum Functionality {
		TEMPORAY_CHANGE_CREATION, RISK_INFO_FETCH, CHANGE_NEEDED_INFO_FETCH, FINAL_OBJECT_CHANGE;
	}

	public enum AlgosecChangeType {
		POLICY_CREATE, POLICY_DELETE, OBJECT;
	}

	public enum AlgosecTaskStatus {
		PENDING, COMPLETE_WITH_SUCCESS, COMPLETE_WITH_ERROR, TEMPORARY_CHANGE_NOT_APPLICABLE
	}

	public enum AlgosecObjectType {
		NETWORK, SERVICE
	}

	public enum AlgosecChangeStatus {
		PENDING("PENDING"), COMPLETED("COMPLETED"), NOT_APPLICABLE("NOT_APPLICABLE"), DISCARDED("DISCARDED");
		private String status;
		AlgosecChangeStatus(String status) {
			this.status = status;
		}
		public String getValue() {
			return status;
		}
	}
	
	public enum AlgosecChangeRententionType {
		TEMPORARY("TEMPORARY"), FINAL("FINAL");
		private String retentionType;
		AlgosecChangeRententionType(String retentionType) { this.retentionType = retentionType; }
		public String getValue() { return retentionType; }
	}
}
