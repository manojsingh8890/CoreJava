package com.ibm.sec.service;

import java.util.concurrent.Executor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ibm.sec.dao.FirewallChangeDAO;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.util.IConstant;

import lombok.extern.slf4j.Slf4j;

/**
 * This method used to retry to fetch risk report from algosec API after a time interval when risk report will available
 * @return Risk report when available 
 */
@Slf4j
public class RetryFetchRisk implements Runnable {

    public Executor taskExecutor;
    
    public UserSession session;
   
    private ServiceFacade businessLogic;
    
    private FirewallChangeDAO firewallChangeDAO;

    public RetryFetchRisk(Executor taskExecutor, UserSession userSession, FirewallChangeDAO firewallChangeDAO, ServiceFacade businessLogic) {
        this.taskExecutor = taskExecutor;
        this.session = userSession;
        this.businessLogic = businessLogic;
        this.firewallChangeDAO = firewallChangeDAO;
        businessLogic.addAlgosecSessionIdsToUserSession(session);
    }

    @Override
    public void run() {
        taskExecutor.execute(new Runnable() {
        	String riskStatus = null;
                 @Override
                 public void run() {
                     try {
                         riskStatus = businessLogic.getAndSaveRiskInfo(session);
                         if (IConstant.RISK_NOT_YET_GENERATED.equals(riskStatus)) {
                             taskExecutor.execute(this);
                         }
                     } catch (Exception e) {
                         log.error("Error occurred for sessonId " + session.getSessionId(), e);
                         firewallChangeDAO.saveError(e.getMessage(), IConstant.Functionality.RISK_INFO_FETCH, session.getSessionId());
                         riskStatus = null;
                     } finally {
                    	 if(!IConstant.RISK_NOT_YET_GENERATED.equals(riskStatus)) {
                    		 firewallChangeDAO.markCompleteRiskInfoFetch(session.getSessionId());
                    	 }
                     }
                 }
             }
        );
    }
}
