package com.ibm.sec.model.algosec;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

import java.util.*;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ObjectChangeRequest {
    private String template;
    private String subject;
    private List<String> devices = new ArrayList<>();
    private String objectContainerLevel;
    private List<RequestedAction> requestedActions = new ArrayList<>(); //must have unique and sorted actions
}
