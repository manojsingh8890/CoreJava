package com.ibm.sec.error;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * A repository of all possible errors returned by the API.
 */
@Getter
@Setter
@NoArgsConstructor
@Component
@ConfigurationProperties(prefix = "error")
public class ErrorConfig {

    private Code code;
    private Message message;
    private HttpStatus httpStatus;

    @Getter
    @Setter
    @NoArgsConstructor
    public static class Code {
        private String unauthorized;
        private String forbidden;
        private String internalError;
        private String badRequest;
        //private String noDeviceFound;
        //private String incorrectDeviceCount;
        //private String noAlgosecEnabledDeviceFound;
        //private String noAlgosecActionableWorkFound;
        //private String noAlgosecTicketDetailsFound;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    public static class Message {
        private String unauthorized;
        private String forbidden;
        private String internalError;
        private String badRequest;
        private String invalidPcrChangeRequestDetails;
        private String noDeviceFound;
        private String incorrectDeviceCount;
        private String noAlgosecEnabledDeviceFound;
        private String noAlgosecActionableWorkFound;
        private String invalidPolicyUpdateSource;
        private String invalidPolicyUpdateDestination;
        private String invalidPort;
        private String invalidProtocol;
        //private String noAlgosecTicketDetailsFound;
        private String invalidIpAddress;
        private String invalidObjectDefinition;
        private String duplicateObjectNameForSameDevice;
        private String objectNotFoundOnDeviceForRule;
        private String couldNotResolveObject;
        private String invalidRuleIdDoesNotExist;
        private String fetchedTicketDetailsInvalidOrIncomplete;
        private String ticketNotInitializedYet;
        private String noTempPolicyChangesFound;
        private String tempCreateChangesIncomplete;
        private String invalidService;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    public static class HttpStatus {
        private String unauthorized;
        private String forbidden;
        private String internalError;
        private String badRequest;
//        private String noDeviceFound;
//        private String incorrectDeviceCount;
//        private String noAlgosecEnabledDeviceFound;
//        private String noAlgosecActionableWorkFound;
//        private String noAlgosecTicketDetailsFound;
    }
}
