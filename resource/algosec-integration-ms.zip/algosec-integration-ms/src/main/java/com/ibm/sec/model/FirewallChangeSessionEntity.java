package com.ibm.sec.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;

@Table(name = "firewall_change_session")
@Entity
@Getter
@Setter
@EqualsAndHashCode
public class FirewallChangeSessionEntity implements java.io.Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;

    @Column(name="SESSION_ID")
    private String sessionId;

    @Column(name="TEMPORARY_REQUESTS_COMPLETE")
    private boolean temporaryRequestsComplete;

    @Column(name="FINAL_REQUESTS_COMPLETE")
    private boolean finalRequestsComplete;

    @Column(name="CHANGE_NEEDED_INFO_FETCH_COMPLETE")
    private boolean changeNeededInfoFetchComplete;

    @Column(name="RISK_FETCH_COMPLETE")
    private boolean riskFetchComplete;

    @Column(name="RISK_INFO")
    private String riskInfo;

    @Column(name="CHANGE_NEEDED_INFO")
    private String changeNeededInfo;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(name="TIMESTAMP")
    private Date timeStamp;
}