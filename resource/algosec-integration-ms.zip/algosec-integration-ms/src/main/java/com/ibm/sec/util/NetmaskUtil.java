package com.ibm.sec.util;

import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.error.ErrorConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Component
public class NetmaskUtil {
    @Autowired
    private ErrorConfig errorConfig;

    private Map<String, String> netmaskMap = new HashMap<>();

    @PostConstruct
    private void init() {
        netmaskMap.put("255.255.255.255","/32");
        netmaskMap.put("255.255.255.254","/31");
        netmaskMap.put("255.255.255.252","/30");
        netmaskMap.put("255.255.255.248","/29");
        netmaskMap.put("255.255.255.240","/28");
        netmaskMap.put("255.255.255.224","/27");
        netmaskMap.put("255.255.255.192","/26");
        netmaskMap.put("255.255.255.128","/25");
        netmaskMap.put("255.255.255.0","/24");
        netmaskMap.put("255.255.254.0","/23");
        netmaskMap.put("255.255.252.0","/22");
        netmaskMap.put("255.255.248.0","/21");
        netmaskMap.put("255.255.240.0","/20");
        netmaskMap.put("255.255.224.0","/19");
        netmaskMap.put("255.255.192.0","/18");
        netmaskMap.put("255.255.128.0","/17");
        netmaskMap.put("255.255.0.0","/16");
        netmaskMap.put("255.254.0.0","/15");
        netmaskMap.put("255.252.0.0","/14");
        netmaskMap.put("255.248.0.0","/13");
        netmaskMap.put("255.240.0.0","/12");
        netmaskMap.put("255.224.0.0","/11");
        netmaskMap.put("255.192.0.0","/10");
        netmaskMap.put("255.128.0.0","/9");
        netmaskMap.put("255.0.0.0","/8");
        netmaskMap.put("254.0.0.0","/7");
        netmaskMap.put("252.0.0.0","/6");
        netmaskMap.put("248.0.0.0","/5");
        netmaskMap.put("240.0.0.0","/4");
        netmaskMap.put("224.0.0.0","/3");
        netmaskMap.put("192.0.0.0","/2");
        netmaskMap.put("128.0.0.0","/1");
        netmaskMap.put("0.0.0.0","/0");
    }

//    public boolean isNetmask(String netmask) {
//        return netmaskMap.containsKey(netmask);
//    }

    /**
     * Returns the ip address in CIDR notation if network mask is mentioned after the IP address. If no network
     * mask is mentioned then returns the IP address as is. If the argument has spaces in it then it may have a network mask.
     * However, in that case, there must be only two parts of the text separated by spaces. If there are more parts than two then the method
     * throws an exception. If there are two parts only then the second part must be a network mask. If not that's
     * also not a valid input and an exception is thrown. If there are no spaces in the text then it is considered an IP address candidate.
     * Note: This method does not validate the resulting IP address (the return value of this method). Must use Util.isIpValid method
     * to validate the resulting IP address.
     * @param netmaskCandidate A possible IP address with network mask
     * @return An IP adress candidate
     */
    public String santizeIPAddress(String netmaskCandidate) {
        String[] netmaskElements = netmaskCandidate.split("\\s+");
        if(netmaskElements.length == 1) {
            return netmaskCandidate;
        }
        if(netmaskElements.length == 0 || netmaskElements.length> 2) {
            throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), String.format(errorConfig.getMessage().getInvalidIpAddress(), netmaskCandidate));
        }
        if(netmaskMap.containsKey(netmaskElements[1])) {
            return netmaskElements[0] + netmaskMap.get(netmaskElements[1]);
        } else {
            throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), String.format(errorConfig.getMessage().getInvalidIpAddress(), netmaskCandidate));
        }
    }

}
