package com.ibm.sec.filter;

import com.ibm.sec.model.UserSession;
import com.ibm.sec.model.algosec.FireFlowAPIAuthResponse;
import com.ibm.sec.service.AlgosecService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SpringBootTest
public class ClaimsFilterTest {

    @Autowired
    private ClaimsFilter claimsFilter;
    @MockBean
    private AlgosecService service;

    @Test
    public void testDoFilterWhenTokenIsMissing() throws IOException, ServletException {
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        FilterChain filterChain = mock(FilterChain.class);
        FireFlowAPIAuthResponse authResponse = new FireFlowAPIAuthResponse();
        authResponse.setPhpSessionId("abc");
        authResponse.setFaSessionId("xyz");
        authResponse.setSessionId("123");
        when(service.authenticate(any())).thenReturn(authResponse);
        when(httpServletRequest.getHeader("Authorization")).thenReturn("Bearer AIhou3f2.2fcn023f.f32vo3j");
        claimsFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
    }
}
