package com.ibm.sec.service;

import com.ibm.sec.model.UserSession;
import com.ibm.sec.util.RestUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import reactor.core.publisher.Mono;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.when;

@SpringBootTest
public class ApplicationServiceTest {

    @Autowired
    private ApplicationService service;
    @MockBean
    private RestUtil restUtil;
    //@MockBean
    private UserSession session;

    @Test
    public void testServices() {
        when(restUtil.makeGetCallToMSSAPIs(any(), anyBoolean(), anyString(), any(Class.class), anyString())).thenReturn(Mono.just("ABC"));
        assertEquals("ABC", service.getDevicesWithHostName(session, "", false).block());
    }

    @Test
    public void testUpdateSocTicket(){
        UserSession s = new UserSession();
        s.setSessionId("001");
        when(restUtil.makePutCallToMSSAPIs(any(), anyBoolean(), anyString(), any(Object.class), any(Class.class), anyString())).thenReturn(Mono.just("ABC"));
        assertEquals("ABC", service.updateSocTicket(s, "", "", false).block());
    }

    @Test
    public void testGetSocTicket(){
        UserSession s = new UserSession();
        s.setSessionId("001");
        when(restUtil.makeGetCallToMSSAPIs(any(), anyBoolean(), anyString(), any(Class.class), anyString())).thenReturn(Mono.just("ABC"));
        assertEquals("ABC", service.getSocTicket(s, "", false).block());
    }

    @Test
    public void testgetDevicesWithAlgoSecUniqueName(){
        UserSession s = new UserSession();
        s.setSessionId("001");
        when(restUtil.makeGetCallToMSSAPIs(any(), anyBoolean(),  anyString(), any(Class.class), anyString())).thenReturn(Mono.just("ABC"));
        assertEquals("ABC", service.getDevicesWithalgoSecUniqueName(s, "", false).block());
    }
}