package com.ibm.sec.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.model.AlgosecObject;
import com.ibm.sec.util.IConstant;
import com.ibm.sec.util.JsonUtil;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class ObjectsResolverTest {

    @Autowired
    private JsonUtil jsonUtil;
    @Autowired
    private ObjectsResolver objectsResolver;

    private static ObjectsData objectsData = new ObjectsData();
    private static Map<String, Map<String, String>> deviceNameNetworkObjectDetailsMapAsInAlgosec = new HashMap<>();
    private static Map<String, Map<String, List<String>>> deviceNameServiceObjectDetailsMap = new HashMap<>();

    @BeforeAll
    public static void setUp() {
        Map<String, String> networkObjectNameValueMap = new HashMap<>();
        networkObjectNameValueMap.put("networkObjectInAlgosec1", "5.5.5.5");
        networkObjectNameValueMap.put("networkObjectInAlgosec2", "6.6.6.6");
        networkObjectNameValueMap.put("networkObjectInAlgosec3", "5.5.5.5,networkObjectInAlgosec2");
        deviceNameNetworkObjectDetailsMapAsInAlgosec.put("atl_msslab_R8040_fw", networkObjectNameValueMap);
        objectsData.setDeviceNameNetworkObjectDetailsMapAsInAlgosec(deviceNameNetworkObjectDetailsMapAsInAlgosec);

        Map<String, List<String>> serviceObjectNameValueMap = new HashMap<>();
        serviceObjectNameValueMap.put("serviceObjectInAlgosec1", Arrays.asList("tcp/443"));
        serviceObjectNameValueMap.put("serviceObjectInAlgosec2", Arrays.asList("udp/333"));
        serviceObjectNameValueMap.put("serviceObjectInAlgosec3", Arrays.asList("tcp/443","serviceObjectInAlgosec2"));
        deviceNameServiceObjectDetailsMap.put("atl_msslab_R8040_fw", serviceObjectNameValueMap);
        objectsData.setDeviceNameServiceObjectDetailsMap(deviceNameServiceObjectDetailsMap);

        Map<String, List<AlgosecObject>> algosecObjectNameObjectMap = new HashMap<>();
        //Network objects
        AlgosecObject algosecObject1 = new AlgosecObject();
        algosecObject1.setObjectName("H_10.1.1.1");
        algosecObject1.setValues(Arrays.asList("10.1.1.1"));
        algosecObject1.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("H_10.1.1.1", Arrays.asList(algosecObject1));

        AlgosecObject algosecObject2 = new AlgosecObject();
        algosecObject2.setObjectName("H_10.1.1.2");
        algosecObject2.setValues(Arrays.asList("10.1.1.2"));
        algosecObject2.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("H_10.1.1.2", Arrays.asList(algosecObject2));

        AlgosecObject algosecObject3 = new AlgosecObject();
        algosecObject3.setObjectName("H_10.1.1.3");
        algosecObject3.setValues(Arrays.asList("10.1.1.3"));
        algosecObject3.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("H_10.1.1.3", Arrays.asList(algosecObject3));

        AlgosecObject algosecObject4 = new AlgosecObject();
        algosecObject4.setObjectName("N_11.1.1.0");
        algosecObject4.setValues(Arrays.asList("11.1.1.0 255.255.255.0"));
        algosecObject4.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("N_11.1.1.0", Arrays.asList(algosecObject4));

        AlgosecObject algosecObject5 = new AlgosecObject();
        algosecObject5.setObjectName("Paid_host");
        algosecObject5.setValues(Arrays.asList("H_10.1.1.1","H_10.1.1.2","H_10.1.1.3","N_11.1.1.0"));
        algosecObject5.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("Paid_host", Arrays.asList(algosecObject5));

        AlgosecObject algosecObject6 = new AlgosecObject();
        algosecObject6.setObjectName("DuplicateObject");
        algosecObject6.setAlgosecDeviceName("atl_msslab_R8040_fw");

        AlgosecObject algosecObject7 = new AlgosecObject();
        algosecObject7.setObjectName("DuplicateObject");
        algosecObject7.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("DuplicateObject", Arrays.asList(algosecObject6, algosecObject7));

        AlgosecObject algosecObject8 = new AlgosecObject();
        algosecObject8.setObjectName("InvalidIpAddressObject");
        algosecObject8.setValues(Arrays.asList("1.1.1")); //invalid ip
        algosecObject8.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("InvalidIpAddressObject", Arrays.asList(algosecObject8));

        //Service Objects
        AlgosecObject algosecObject9 = new AlgosecObject();
        algosecObject9.setObjectName("tcp_1000");
        algosecObject9.setValues(Arrays.asList("tcp/1000"));
        algosecObject9.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("tcp_1000", Arrays.asList(algosecObject9));

        AlgosecObject algosecObject10 = new AlgosecObject();
        algosecObject10.setObjectName("udp_3000");
        algosecObject10.setValues(Arrays.asList("udp_3000"));
        algosecObject10.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("udp_3000", Arrays.asList(algosecObject10));

        AlgosecObject algosecObject11 = new AlgosecObject();
        algosecObject11.setObjectName("algosec_service_object_multi_values");
        algosecObject11.setValues(Arrays.asList("tcp_1000", "udp_3000"));
        algosecObject11.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("algosec_service_object_multi_values", Arrays.asList(algosecObject11));

        AlgosecObject algosecObject12 = new AlgosecObject();
        algosecObject12.setObjectName("invalid_algosec_service_object");
        algosecObject12.setValues(Arrays.asList("tcp1000")); //invalid protocol port combination
        algosecObject12.setAlgosecDeviceName("atl_msslab_R8040_fw");
        algosecObjectNameObjectMap.put("invalid_algosec_service_object", Arrays.asList(algosecObject12));

        objectsData.setAlgosecObjectNameObjectMap(algosecObjectNameObjectMap);
    }

    @Test
    public void testInitSuccess() throws IOException {
        JsonNode firewallChanges = jsonUtil.parse(new String(ObjectsResolverTest.class.getClassLoader().getResourceAsStream("test_input.json").readAllBytes()));
        String disallowedObjectNodeAsString = "{\n" +
                "      \"request_item\": \"100\",\n" +
                "      \"action\": \"Create\",\n" +
                "      \"object_type\": \"TypeNotAllowed\",\n" +
                "      \"object_name\": \"ObjectThatWeWontUse\",\n" +
                "      \"action_items\": \"8.8.8.8\",\n" +
                "      \"comments\": \"Create host with IP 8.8.8.8\",\n" +
                "      \"firewall_policy\": \"atl_msslab_R8040_fw\"\n" +
                "    }";
        JsonNode disallowedObjectNode = jsonUtil.parse(disallowedObjectNodeAsString);
        ArrayNode objectNodes = (ArrayNode) firewallChanges.get(IConstant.OBJECT_UPDATE_CHANGES);
        objectNodes.add(disallowedObjectNode);

        Map<String, String> deviceToAlgosecUniqueNameMap = new HashMap<>();
        deviceToAlgosecUniqueNameMap.put("A", "B");
        deviceToAlgosecUniqueNameMap.put("C", "D");


        ObjectsData objectsData = objectsResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap, deviceToAlgosecUniqueNameMap);
        Optional<AlgosecObject> object1 = objectsData.getAlgosecObjectNameObjectMap().values().stream().flatMap(List::stream).filter(algosecObject -> algosecObject.getObjectName().equals("H_10.1.1.1")).findAny();
        assertTrue(object1.isPresent());
        assertEquals("10.1.1.1", object1.get().getValues().get(0));
        Optional<AlgosecObject> object2 = objectsData.getAlgosecObjectNameObjectMap().values().stream().flatMap(List::stream).filter(algosecObject -> algosecObject.getObjectName().equals("Paid_host")).findAny();
        assertTrue(object2.isPresent());
        List<String> expectedValues = Arrays.asList("H_10.1.1.1,H_10.1.1.2,H_10.1.1.3,N_11.1.1.0".split(","));
        assertEquals(expectedValues, object2.get().getValues());
        Optional<AlgosecObject> object3 = objectsData.getAlgosecObjectNameObjectMap().values().stream().flatMap(List::stream).filter(algosecObject -> algosecObject.getObjectName().equals("ObjectThatWeWontUse")).findAny();
        assertTrue(object3.isEmpty()); //ObjectThatWeWontUse is not put into the data map
    }

    /*
    * Single valued network object
     */
    @Test
    public void testSimpleNetworkObjectResolutionSuccess() {
        List<String> values = objectsResolver.resolveIfObject("H_10.1.1.1", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.NETWORK, objectsData);
        assertEquals("10.1.1.1", values.get(0));
    }

    @Test
    public void testObjectResolutionErrorWhenObjectDeviceNameDoesNotMatchWithInputDeviceName() {
        BusinessLogicException ex = assertThrows(BusinessLogicException.class, () -> {
            objectsResolver.resolveIfObject("H_10.1.1.1", "some_device_name_that_wont_match", IConstant.AlgosecObjectType.NETWORK, objectsData);
        });
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getHttpStatus()));
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getCode()));
        assertEquals("object 'H_10.1.1.1' does not exist on device 'some_device_name_that_wont_match'", ex.getMessage());
    }

    @Test
    public void testObjectResolutionErrorWhenDuplicateObjectsInInputForTheGivenDevice() {
        BusinessLogicException ex = assertThrows(BusinessLogicException.class, () -> {
            objectsResolver.resolveIfObject("DuplicateObject", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.NETWORK, objectsData);
        });
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getHttpStatus()));
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getCode()));
        assertEquals("Duplicate object names for same device. Object name: 'DuplicateObject'.", ex.getMessage());
    }

    @Test
    public void testNetworkObjectResolutionSuccessForGroupObject() {
        List<String> values = objectsResolver.resolveIfObject("Paid_host", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.NETWORK, objectsData);
        assertEquals(4, values.size());
        List<String> expectedResults = Arrays.asList("10.1.1.1", "10.1.1.2", "10.1.1.3", "11.1.1.0/24");
        assertEquals(expectedResults, values);
    }

    @Test
    public void testInvalidNetworkObjectDefinition() {
        BusinessLogicException ex = assertThrows(BusinessLogicException.class, () -> {
            objectsResolver.resolveIfObject("InvalidIpAddressObject", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.NETWORK, objectsData);
        });
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getHttpStatus()));
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getCode()));
        assertEquals("Invalid Object definition for 'InvalidIpAddressObject'", ex.getMessage());
    }

    @Test
    public void testNetworkObjectResolutionSuccessForGroupObjectHavingPlainAndOtherGroupObjectsAsValues() {
        List<String> values = objectsResolver.resolveIfObject("networkObjectInAlgosec3", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.NETWORK, objectsData);
        assertEquals(2, values.size());
        List<String> expectedResults = Arrays.asList("5.5.5.5", "6.6.6.6");
        assertEquals(expectedResults, values);
    }

    /*
     * Single valued Service object
     */
    @Test
    public void testSimpleServiceObjectResolutionSuccess() {
        List<String> values = objectsResolver.resolveIfObject("tcp_1000", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.SERVICE, objectsData);
        assertEquals("tcp/1000", values.get(0));
    }

    @Test
    public void testServiceGroupObjectResolutionSuccess() {
        List<String> values = objectsResolver.resolveIfObject("algosec_service_object_multi_values", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.SERVICE, objectsData);
        List<String> expectedValues = Arrays.asList("tcp/1000", "udp/3000");
        assertEquals(2, values.size());
        assertEquals(expectedValues, values);
    }

    @Test
    public void testInvalidServiceObjectDefinition() {
        BusinessLogicException ex = assertThrows(BusinessLogicException.class, () -> {
            objectsResolver.resolveIfObject("invalid_algosec_service_object", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.SERVICE, objectsData);
        });
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getHttpStatus()));
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getCode()));
        assertEquals("Invalid Object definition for 'invalid_algosec_service_object'", ex.getMessage());
    }

    @Test
    public void testNetworkObjectExistsInAlgosecSuccess() {
        List<String> values = objectsResolver.resolveIfObject("networkObjectInAlgosec1", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.NETWORK, objectsData);
        assertEquals("5.5.5.5", values.get(0));
    }

    @Test
    public void testServiceObjectExistsInAlgosecSuccess() {
        List<String> values = objectsResolver.resolveIfObject("serviceObjectInAlgosec1", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.SERVICE, objectsData);
        assertEquals("tcp/443", values.get(0));
    }

    @Test
    public void testNetworkObjectDoesNotExistsInAlgosec() {
        BusinessLogicException ex = assertThrows(BusinessLogicException.class, () -> {
            objectsResolver.resolveIfObject("networkObjectInAlgosec_does_not_exist", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.NETWORK, objectsData);
        });
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getHttpStatus()));
        assertEquals(HttpStatus.BAD_REQUEST.value(), Integer.parseInt(ex.getCode()));
        assertEquals("Could not resolve 'networkObjectInAlgosec_does_not_exist' as object", ex.getMessage());
    }

    @Test
    public void testServiceObjectDoesNotExistsInAlgosec() {
        List<String> values = objectsResolver.resolveIfObject("serviceObjectInAlgosec_does_not_exist", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.SERVICE, objectsData);
        assertTrue(values.isEmpty());
    }

    @Test
    public void testServiceGroupObjectResolutionSuccessWith() {
        List<String> values = objectsResolver.resolveIfObject("algosec_service_object_multi_values", "atl_msslab_R8040_fw", IConstant.AlgosecObjectType.SERVICE, objectsData);
        List<String> expectedValues = Arrays.asList("tcp/1000", "udp/3000");
        assertEquals(2, values.size());
        assertEquals(expectedValues, values);
    }
}
