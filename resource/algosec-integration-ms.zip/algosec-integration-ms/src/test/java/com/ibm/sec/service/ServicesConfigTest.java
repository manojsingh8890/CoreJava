package com.ibm.sec.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class ServicesConfigTest {

    @Autowired
    private ServicesConfig servicesConfig;

    @Test
    public void testConfig() {
        assertEquals("test_url1", servicesConfig.getAlgosecFireflowAuthenticationUrl());
        assertEquals("test_url2", servicesConfig.getAlgosecFireflowChangeRequestUrl());
        assertEquals("test_url4", servicesConfig.getDeviceUrlWithHostname());
    }
}
