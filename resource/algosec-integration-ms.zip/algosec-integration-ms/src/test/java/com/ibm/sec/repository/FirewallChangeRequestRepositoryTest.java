package com.ibm.sec.repository;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.ibm.sec.model.FirewallChangeRequestEntity;

@DataJpaTest
public class FirewallChangeRequestRepositoryTest {
	
	@Autowired
	private FirewallChangeRequestRepository firewallChangeRequestRepository;
	
	FirewallChangeRequestEntity firewallChangeRequestEntity;

	@Test
	public void findByChangeId() {
		firewallChangeRequestEntity = new FirewallChangeRequestEntity();
		firewallChangeRequestEntity.setSessionId("sessionId001");
		firewallChangeRequestEntity.setId(1);
		firewallChangeRequestEntity.setChangeRequest("001");
		firewallChangeRequestRepository.save(firewallChangeRequestEntity);
		FirewallChangeRequestEntity firewallChangeRequestEntity = firewallChangeRequestRepository.findBySessionId("sessionId001");
		Assert.assertEquals("sessionId001", firewallChangeRequestEntity.getSessionId());
	}

}
