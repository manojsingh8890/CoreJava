package com.ibm.sec.error;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class ErrorConfigTest {

    @Autowired
    private ErrorConfig errorConfig;

    @Test
    public void testConfig() {
        assertEquals("401", errorConfig.getCode().getUnauthorized());
        assertEquals("403", errorConfig.getCode().getForbidden());
        assertEquals("500", errorConfig.getCode().getInternalError());
        assertEquals("400", errorConfig.getCode().getBadRequest());

        assertEquals("No device found", errorConfig.getMessage().getNoDeviceFound());
        assertEquals("Incorrect device count", errorConfig.getMessage().getIncorrectDeviceCount());
        assertEquals("No algosec enabled device found", errorConfig.getMessage().getNoAlgosecEnabledDeviceFound());
        assertEquals("No algosec work found", errorConfig.getMessage().getNoAlgosecActionableWorkFound());
        assertEquals("Bad Request", errorConfig.getMessage().getBadRequest());
        assertEquals("Unauthorised", errorConfig.getMessage().getUnauthorized());
        assertEquals("Forbidden", errorConfig.getMessage().getForbidden());
        assertEquals("Internal Error", errorConfig.getMessage().getInternalError());
        assertEquals("Invalid JSON Input", errorConfig.getMessage().getInvalidPcrChangeRequestDetails());
        assertEquals("Could not resolve '%s' as Source {IP, Network, ID or Object Name} in Policy Update tab", errorConfig.getMessage().getInvalidPolicyUpdateSource());
        assertEquals("Could not resolve '%s' as Destination {IP, Network, ID or Object Name} in Policy Update tab", errorConfig.getMessage().getInvalidPolicyUpdateDestination());
        assertEquals("Not a valid port '%s' specified in service '%s'", errorConfig.getMessage().getInvalidPort());
        assertEquals("Not a valid protocol '%s' specified in service '%s'", errorConfig.getMessage().getInvalidProtocol());
        //assertEquals("Invalid Ip Address", errorConfig.getMessage().getInvalidIpAddress());
        assertEquals("Invalid Object definition for '%s'", errorConfig.getMessage().getInvalidObjectDefinition());
        assertEquals("Duplicate object names for same device. Object name: '%s'.", errorConfig.getMessage().getDuplicateObjectNameForSameDevice());
        assertEquals("object '%s' does not exist on device '%s'", errorConfig.getMessage().getObjectNotFoundOnDeviceForRule());
        assertEquals("Could not resolve '%s' as object", errorConfig.getMessage().getCouldNotResolveObject());
        assertEquals("Rule id '%s' does not exist on device '%s'", errorConfig.getMessage().getInvalidRuleIdDoesNotExist());
        assertEquals("Fetched Ticket Details Invalid Or Incomplete", errorConfig.getMessage().getFetchedTicketDetailsInvalidOrIncomplete());

        assertEquals("401", errorConfig.getHttpStatus().getUnauthorized());
        assertEquals("403", errorConfig.getHttpStatus().getForbidden());
        assertEquals("500", errorConfig.getHttpStatus().getInternalError());
        assertEquals("400", errorConfig.getHttpStatus().getBadRequest());

    }
}
