package com.ibm.sec.dao;

import org.junit.jupiter.api.Test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.ibm.sec.TestData;
import com.ibm.sec.model.FirewallChangeEntity;
import com.ibm.sec.model.FirewallChangeRequestEntity;
import com.ibm.sec.model.FirewallChangeSessionEntity;
import com.ibm.sec.model.FirewallChangeSessionErrorsEntity;
import com.ibm.sec.repository.FirewallChangeRepository;
import com.ibm.sec.repository.FirewallChangeRequestRepository;
import com.ibm.sec.repository.FirewallChangeSessionErrorsRepository;
import com.ibm.sec.repository.FirewallChangeSessionRepository;
import com.ibm.sec.util.IConstant;

@SpringBootTest
public class FirewallChangeServiceDAOImplTest {
	
	@Autowired
	FirewallChangeServiceDAOImpl firewallChangeServiceDAOImpl;
	
	@MockBean
	private FirewallChangeRequestRepository firewallChangeRequestRepository;

	@MockBean
	private FirewallChangeRepository firewallChangeRepository;

	@MockBean
	private FirewallChangeSessionRepository firewallChangeSessionRepository;

	@MockBean
	private FirewallChangeSessionErrorsRepository firewallChangeSessionErrorsRepository;
	
	public FirewallChangeRequestEntity getFirewallChangeRequestEntity() {
		FirewallChangeRequestEntity FirewallChangeRequestEntity = new FirewallChangeRequestEntity();
		FirewallChangeRequestEntity.setId(2);
		FirewallChangeRequestEntity.setSessionId("sessionId001");
		FirewallChangeRequestEntity.setChangeRequest("ChangeRequest");
		return FirewallChangeRequestEntity;
	}
	
	public FirewallChangeEntity getFirewallChangeEntity() {
		Date date = new Date();
		FirewallChangeEntity fwChange = new FirewallChangeEntity();
		fwChange.setChangeId("changeId");
		fwChange.setItsmId("001");
		fwChange.setId(2);
		fwChange.setSessionId("sessionId001");
		fwChange.setAlgoSecChangeRetentionType(IConstant.AlgosecChangeRententionType.TEMPORARY);
		fwChange.setChangeType(IConstant.AlgosecChangeType.POLICY_CREATE);
		fwChange.setTimeStamp(date);
		return fwChange;
	}
	
	public FirewallChangeSessionEntity getFirewallChangeSessionEntity() {
		Date date = new Date();
		FirewallChangeSessionEntity firewallChangeSessionEntity = new FirewallChangeSessionEntity();
		firewallChangeSessionEntity.setId(1);
		firewallChangeSessionEntity.setSessionId("sessionId001");
		firewallChangeSessionEntity.setTimeStamp(date);
		firewallChangeSessionEntity.setTemporaryRequestsComplete(true);
		firewallChangeSessionEntity.setFinalRequestsComplete(true);
		firewallChangeSessionEntity.setRiskFetchComplete(true);
		firewallChangeSessionEntity.setChangeNeededInfoFetchComplete(true);
		firewallChangeSessionEntity.setChangeNeededInfo(TestData.getChangeNeededData());
		firewallChangeSessionEntity.setRiskInfo(TestData.getRiskReportData());
		return firewallChangeSessionEntity;
	}
	
	public FirewallChangeSessionErrorsEntity getFirewallChangeSessionErrorsEntity() {
		FirewallChangeSessionErrorsEntity firewallChangeSessionErrorsEntity = new FirewallChangeSessionErrorsEntity();
		firewallChangeSessionErrorsEntity.setId(1);
		firewallChangeSessionErrorsEntity.setError("Error");
		firewallChangeSessionErrorsEntity.setFunctionality(IConstant.Functionality.RISK_INFO_FETCH);
		firewallChangeSessionErrorsEntity.setSessionId("sessionId001");
		return firewallChangeSessionErrorsEntity;
	}
	
	
	@Test
	public void saveRequestTest() {
		when(firewallChangeRequestRepository.save(any())).thenReturn(getFirewallChangeRequestEntity());
		FirewallChangeRequestEntity firewallChangeRequestEntity = firewallChangeServiceDAOImpl.saveRequest("Request001", "SessionId001");
	    Assert.assertEquals("sessionId001", firewallChangeRequestEntity.getSessionId());
	}
	
	@Test
	public void saveFirewallChangeRequestTest() {
		when(firewallChangeRequestRepository.save(any())).thenReturn(getFirewallChangeRequestEntity());
		FirewallChangeRequestEntity firewallChangeRequestEntity = firewallChangeServiceDAOImpl.saveFirewallChangeRequest(getFirewallChangeRequestEntity());
	    Assert.assertEquals("sessionId001", firewallChangeRequestEntity.getSessionId());
	}
	
	@Test
	public void getChangeRequestBySessionIdTest() {
		when(firewallChangeRequestRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeRequestEntity());
		FirewallChangeRequestEntity firewallChangeRequestEntity = firewallChangeServiceDAOImpl.getChangeRequestBySessionId(anyString());
	    Assert.assertEquals("sessionId001", firewallChangeRequestEntity.getSessionId());
	}

	@Test
	public void getAllTemporaryPolicyChangeRequestsBySessionIdTest() {
		List<FirewallChangeEntity> list = new ArrayList<FirewallChangeEntity>();
		list.add(getFirewallChangeEntity());
		when(firewallChangeRepository.findBySessionIdAndAlgoSecChangeRetentionTypeAndChangeTypeIn(anyString(), any(), anyList())).thenReturn(list);
		List<FirewallChangeEntity> FirewallChangeEntityList = firewallChangeServiceDAOImpl.getAllTemporaryPolicyChangeRequestsBySessionId("SessionId001");
		Assert.assertEquals("sessionId001", FirewallChangeEntityList.get(0).getSessionId());
	}
	
	@Test
	public void saveAllTest(){
		List<FirewallChangeEntity> list = new ArrayList<FirewallChangeEntity>();
		list.add(getFirewallChangeEntity());
		when(firewallChangeRepository.saveAll(anyList())).thenReturn(list);
		List<FirewallChangeEntity> FirewallChangeEntityList = firewallChangeServiceDAOImpl.saveAll(list);
		Assert.assertEquals("sessionId001", FirewallChangeEntityList.get(0).getSessionId());
	}

	@Test
	public void areTemporaryChangeRequestsCompleteTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		boolean areTemporaryChangeRequest = firewallChangeServiceDAOImpl.areTemporaryChangeRequestsComplete("sessionId001");
		Assert.assertEquals(areTemporaryChangeRequest, true);
	}

	@Test
	public void areFinalChangeRequestsCompleteTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		boolean isFinalRequestsComplete = firewallChangeServiceDAOImpl.areFinalChangeRequestsComplete("sessionId001");
		Assert.assertEquals(isFinalRequestsComplete, true);
	}

	@Test
	public void isRisksFetchCompleteTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		boolean isRisksFetchComplete = firewallChangeServiceDAOImpl.isRisksFetchComplete("sessionId001");
		Assert.assertEquals(isRisksFetchComplete, true);
	}

	@Test
	public void isChangeNeededInfoFetchCompleteTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		boolean isChangeNeededInfoFetchComplete = firewallChangeServiceDAOImpl.isChangeNeededInfoFetchComplete("sessionId001");
		Assert.assertEquals(isChangeNeededInfoFetchComplete, true);
	}

	@Test
	public void initiateFirewallChangeSessionTest() {
		when(firewallChangeSessionRepository.save(any())).thenReturn(getFirewallChangeSessionEntity());
		firewallChangeServiceDAOImpl.initiateFirewallChangeSession("sessionId001");
	}

	@Test
	public void markCompleteTemporaryRequestsTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		when(firewallChangeSessionRepository.save(any())).thenReturn(getFirewallChangeSessionEntity());
		firewallChangeServiceDAOImpl.markCompleteTemporaryRequests("sessionId001");
	}

	@Test
	public void markCompleteFinalRequestsTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		when(firewallChangeSessionRepository.save(any())).thenReturn(getFirewallChangeSessionEntity());
		firewallChangeServiceDAOImpl.markCompleteFinalRequests("sessionId001");
	}

	@Test
	public void saveChangeNeededInfoTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		when(firewallChangeSessionRepository.save(any())).thenReturn(getFirewallChangeSessionEntity());
		firewallChangeServiceDAOImpl.saveChangeNeededInfo(TestData.getChangeNeededData(), "sessionId001");
	}

	@Test
	public void saveRiskInfoTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		when(firewallChangeSessionRepository.save(any())).thenReturn(getFirewallChangeSessionEntity());
		firewallChangeServiceDAOImpl.saveRiskInfo(TestData.getRiskReportData(), "sessionId001");
	}

	@Test
	public void saveErrorTest() {
		when(firewallChangeSessionErrorsRepository.save(any())).thenReturn(getFirewallChangeSessionErrorsEntity());
		FirewallChangeSessionErrorsEntity firewallChangeSessionErrorsEntity = firewallChangeServiceDAOImpl.saveError("Error", IConstant.Functionality.CHANGE_NEEDED_INFO_FETCH, "sessionId001");
		Assert.assertEquals("sessionId001", firewallChangeSessionErrorsEntity.getSessionId());
	}

	@Test
	public void getErrorsBySessionIdAndFunctionalityTest() {
		List<FirewallChangeSessionErrorsEntity> firewallChangeSessionErrorsEntityList= new ArrayList<FirewallChangeSessionErrorsEntity>();
		firewallChangeSessionErrorsEntityList.add(getFirewallChangeSessionErrorsEntity());
		when(firewallChangeSessionErrorsRepository.findBySessionIdAndFunctionality(anyString(), any())).thenReturn(firewallChangeSessionErrorsEntityList);
		List<String> errorList = firewallChangeServiceDAOImpl.getErrorsBySessionIdAndFunctionality("sessionId001", IConstant.Functionality.CHANGE_NEEDED_INFO_FETCH);
		Assert.assertEquals("Error", errorList.get(0));
	}

	@Test
	 public void getTemporaryPolicyCreateChangesBySessionIdTest() {
		 List<FirewallChangeEntity> list = new ArrayList<FirewallChangeEntity>();
		 list.add(getFirewallChangeEntity());
		 when(firewallChangeRepository.findBySessionIdAndAlgoSecChangeRetentionTypeAndChangeTypeIn(anyString(),any(), anyList())).thenReturn(list);
		 List<String> changeList = firewallChangeServiceDAOImpl.getTemporaryPolicyCreateChangesBySessionId("sessionId001");
		 Assert.assertEquals("changeId", changeList.get(0));
	 }

	@Test
	 public void getChangeNeededInfoBySessionIdTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		String ChangeNeededInfo = firewallChangeServiceDAOImpl.getChangeNeededInfoBySessionId("sessionId001");
		Assert.assertEquals(ChangeNeededInfo, TestData.getChangeNeededData());
	 }
	
	 @Test
	 public void getChangeNeededInfoBySessionIdNullTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(null);
		String ChangeNeededInfo = firewallChangeServiceDAOImpl.getChangeNeededInfoBySessionId("sessionId001");
		Assert.assertEquals(ChangeNeededInfo, null);
	  }

	 @Test
     public void getRiskInfoBySessionIdTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		String ChangeNeededInfo = firewallChangeServiceDAOImpl.getRiskInfoBySessionId("sessionId001");
		Assert.assertEquals(ChangeNeededInfo, TestData.getRiskReportData());
	 }
	 
	 @Test
     public void getRiskInfoBySessionIdNullTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(null);
		String ChangeNeededInfo = firewallChangeServiceDAOImpl.getRiskInfoBySessionId("sessionId001");
		Assert.assertEquals(ChangeNeededInfo, null);
	 }
	 
	 @Test
	public void markCompleteChangeNeededInfoFetchTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		when(firewallChangeSessionRepository.save(any())).thenReturn(getFirewallChangeSessionEntity());
		firewallChangeServiceDAOImpl.markCompleteChangeNeededInfoFetch("sessionId001");
	}

	 @Test
	 public void markCompleteRiskInfoFetchTest() {
		when(firewallChangeSessionRepository.findBySessionId(anyString())).thenReturn(getFirewallChangeSessionEntity());
		when(firewallChangeSessionRepository.save(any())).thenReturn(getFirewallChangeSessionEntity());
		firewallChangeServiceDAOImpl.markCompleteRiskInfoFetch("sessionId001");
	 }

	 @Test
	 public void updateStatusTest() {
		List<FirewallChangeEntity> list = new ArrayList<FirewallChangeEntity>();
		FirewallChangeEntity firewallChangeEntity= getFirewallChangeEntity();
		firewallChangeEntity.setAlgoSecChangeStatus(IConstant.AlgosecChangeStatus.COMPLETED);
		list.add(firewallChangeEntity);
		when(firewallChangeRepository.saveAll(any())).thenReturn(list);
		List<FirewallChangeEntity> FirewallChangeEntityList = firewallChangeServiceDAOImpl.updateStatus(list, IConstant.AlgosecChangeStatus.COMPLETED);
		Assert.assertEquals(IConstant.AlgosecChangeStatus.COMPLETED, FirewallChangeEntityList.get(0).getAlgoSecChangeStatus());
	 } 
	 
	 @Test
	 public void getTemporaryChangeEntityForPolicyCreateChangesBySessionIdTest() {
		List<FirewallChangeEntity> list = new ArrayList<FirewallChangeEntity>();
		list.add(getFirewallChangeEntity());
		when(firewallChangeRepository.findBySessionIdAndAlgoSecChangeRetentionTypeAndChangeTypeIn(anyString(), any(), anyList())).thenReturn(list);
		List<FirewallChangeEntity> FirewallChangeEntityList = firewallChangeServiceDAOImpl.getTemporaryChangeEntityForPolicyCreateChangesBySessionId("SessionId001");
		Assert.assertEquals("sessionId001", FirewallChangeEntityList.get(0).getSessionId());
	 }
}
