### Elastic Search Microservice
This module is a micro-service that simply fetches data from elastic-search.  The user (another microservice) will specify which index they need data from (ie ticket), along with any special query paramters (limit, includes, excludes, range, sort, etc) and expect the appropriate data to be returned.  

NOTE: If you are using this microservice to search for String values that contain commans, you need to escape them in order to not have them split into separate search arguments.  

For example: 
 * Searching for "Resolved, Pending Closure" on a Ticket will ultimately be split into two separate searche
   * One for "Resolved"
   * One for "Pending Closure"

Instead, your query to this microservice should replace the literal comma with \*\*COMMA\*\*, and this microservice will then treat it as  a literal in the search.

For example:
 * Searching for "Resovled\*\*COMMA\*\* Pending Closure" on a Ticket will be treated as a single search
 
This module provide facility to bulk fatch data from elastic search via post call. The user (another microservice) will specify which index they need data along with any special query paramters (limit, includes, excludes, range, sort, etc) with request body payload. You should provide bulk search value in request body.

For example:
 * Searching list of device Ids given in request body along with active devices filter given query paramters.
 
   Request body json payload for device Ids:
   
      {
      "id":["deviceId1", "deviceId2", "deviceId3", ...]
      }


### Running locally
1. Create an Application launcher in IDEA or your favorite java editor.  
  * Main class: io.vertx.core.Launcher
  * Program arguments: run com.ibm.sec.mss.SearchVerticle
  * Java 8
2. Be sure you have the appropriate keystores from /opt/mssdev/cert in order to reach the elastic search cluster.  

### ITPO Security Spec

The word ‘secured’ below typically means strongly encrypted, SSL enabled by default, limited to only those who require access with strong authentication and authorization mechanisms.
For each of the following questions about your application, indicate YES, NO or N/A and include a detailed explanation:

Client owned data is segregated such that client A cannot see client B's data


YES, managed by microservice and gateway.


Client owned, confidential and regulated data is secured at rest, in transit and in use 


YES, elastic search at rest, https in transit


Public internet traffic is secured and ingress policy is manageable by the network operations team


YES, we don't have any dependencies on internet resources.  Incoming requests will be https.



Operating system resources are secured 


N/A. This application runs as a micro-service, OS resource security is managed by the ITPO team.



Defended against systemic attacks such as brute force login


YES, should not be accessible to outside world.  Will rely on JWT as authentication method.  



Login, access and administrative/privileged authority events are logged and retained for at least 90 days


NA. Login, access and administrative/privileged authority events are logged via the gateway, not this microservice.  


Defended against insider attacks such as rogue developers deploying malicious code to production


NO, depends on ITPO locking down production k8s so developers cannot deploy.


Authentication uses strong passwords, tokens or other highly secure mechanism 


JWT will be the main authentication source for this micro-service, this type of token is tamper resistant by way of public key verification. 
Also, the token is short-lived, 30-45 seconds.


Security related configuration options are validated to be in place in production on at least a quarterly schedule


N/A, microservices are inherently secure and do not have security related configuration options. 
Also, this will be an internal only service (used by other microservices)  


Security vulnerabilities and threats in source code, to dependent libraries and software are closely monitored and addressed


YES, both developers and Sonar review source code.  Dependent libraries are scanned for COO/Wicked issues.



Releases are managed through organizational change control procedures


YES, they will follow standard MSS procedures.


Data is backed up daily and retained for at least seven days


N/A, only processes data.


Integrated into organizational disaster recovery procedures


NO, kubernetes is not available for DR yet. Requires Gateway support for all DR endpoints.  Microservice support for it's datasource endpoints.  ITPO support for new cloud in DR environment.



Availability is >99.9%


YES, that is our target.