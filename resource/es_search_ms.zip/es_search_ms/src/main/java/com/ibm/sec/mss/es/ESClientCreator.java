package com.ibm.sec.mss.es;

import com.ibm.sec.mss.ElasticSearchConfiguration;
import com.ibm.sec.mss.LogFormatter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;

import java.util.ArrayList;
import java.util.List;

public class ESClientCreator {

    private String clusterName;
    private String keyStorePath;
    private String keyStorePassword;
    private String trustStore;
    private String trustStorePassword;
    private String sslProtocol;
    private String nativeEnabled;
    private String restEnabled;
    private String forceNativeClientAuth;
    private String forceRestClientAuth;
    private String pingTimeout;
    private Integer port;
    private List<String> serverList = new ArrayList<>();
    private Logger logger = LogManager.getLogger(getClass());


    public ESClientCreator() {
        ElasticSearchConfiguration config = ElasticSearchConfiguration.getInstance();

        clusterName = config.getClusterName();
        keyStorePath = config.getSslServerKeyStorePath();
        keyStorePassword = config.getSslServerKeyStorePassword();
        trustStore = config.getSslServerTrustStorePath();
        trustStorePassword = config.getSslServerTrustStorePassword();
        sslProtocol = config.getSslProtocol();
        nativeEnabled = config.getSslNativeEnabled();
        restEnabled = config.getSslRestEnabled();
        forceNativeClientAuth = config.getForceNativeClientAuth();
        forceRestClientAuth = config.getForceRestClientAuth();
        pingTimeout = config.getPingTimeout();
        port = Integer.valueOf(config.getPort());
        String hostList = config.getClientTransportHosts();
        String[] hostAry = hostList.split(",");
        for (String hostName : hostAry) {
            serverList.add(StringUtils.trim(hostName));
        }
    }

    public Client getTransportConnection() {
        Settings settings = ImmutableSettings.settingsBuilder()
                .put("cluster.name", clusterName)
                .put("mss.ssl.server.keyStore", keyStorePath)
                .put("mss.ssl.server.keyStorePassword", keyStorePassword)
                .put("mss.ssl.server.trustStore", trustStore)
                .put("mss.ssl.server.trustStorePassword", trustStorePassword)
                .put("mss.ssl.protocol", sslProtocol)
                .put("mss.ssl.native.enabled", nativeEnabled)
                .put("mss.ssl.rest.enabled", restEnabled)
                .put("mss.ssl.forceNativeClientAuth", forceNativeClientAuth)
                .put("mss.ssl.forceRestClientAuth", forceRestClientAuth)
                .put("client.transport.ping_timeout", pingTimeout)
                .build();

        TransportClient client = new TransportClient(settings);

        for (String server : serverList) {
            client = client.addTransportAddresses(new InetSocketTransportAddress(server, port));
            logger.info(LogFormatter.getLog(getClass(),"getTransportConnection", String.format("Added server to connection list:  %s", server)));
        }
        return client;
    }

}
