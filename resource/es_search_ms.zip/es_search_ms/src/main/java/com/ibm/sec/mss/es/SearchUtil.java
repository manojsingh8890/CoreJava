package com.ibm.sec.mss.es;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.base.Strings;
import org.elasticsearch.index.query.FilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;


public class SearchUtil {
  private Client client;
  private final Logger logger = LogManager.getLogger(this.getClass());

  public SearchHits find(String indexName, String docType, String userId, Map<String, String> permissionKeyMap, String queryString,
                         int from, int size, LinkedHashMap<String, String> sortMap, Map<String, List<Object>> includeTermsMap,
                         Map<String, List<Object>> excludeTermsMap, Map<String, Object[]> includeRangeMap, List<String> sourceInclude,
                         List<String> sourceExclude, Map<String, String> regexSearchParamMap) throws Exception {
    long startTime = System.currentTimeMillis();

    try {
      FilterBuilder includeFilter = null;
      if (includeTermsMap != null || includeRangeMap != null) {

        List<FilterBuilder> filterList = new ArrayList<>();
        if (includeTermsMap != null) {
          for (Map.Entry<String, List<Object>> entry : includeTermsMap.entrySet()) {
            List<Object> termList = entry.getValue();
            if (!termList.isEmpty()) {
              FilterBuilder fb = FilterBuilders.inFilter(entry.getKey(), termList.toArray());
              filterList.add(fb);
            }
          }
        }

        if (includeRangeMap != null) {
          for (Map.Entry<String, Object[]> entry : includeRangeMap.entrySet())
          {
            FilterBuilder fb = FilterBuilders.rangeFilter(entry.getKey()).includeLower(true).includeUpper(false).from(entry.getValue()[0]).to(entry.getValue()[1]);
            filterList.add(fb);
          }
        }

        if (!Strings.isNullOrEmpty(userId)) {
          if (permissionKeyMap != null) {
            for (Map.Entry<String, String> entry : permissionKeyMap.entrySet()) {
              FilterBuilder permissionFilter = FilterBuilders.termsLookupFilter(entry.getValue()).lookupIndex("datapermissionindex").lookupType("datapermission").lookupId(userId).lookupPath(entry.getKey());
              filterList.add(permissionFilter);
            }
          }
        }

        if (filterList.size() > 1) {
          includeFilter = FilterBuilders.andFilter(filterList.toArray(new FilterBuilder[filterList.size()]));
        }
        else if (filterList.size() == 1) {
          includeFilter = filterList.get(0);
        }
      }

      FilterBuilder excludeFilter = null;
      if (excludeTermsMap != null && !excludeTermsMap.isEmpty()) {

        List<FilterBuilder> filterList = new ArrayList<>();
        for (Map.Entry<String, List<Object>> entry : excludeTermsMap.entrySet())
        {
          List<Object> termList = entry.getValue();
          if (!termList.isEmpty()) {
            FilterBuilder fb = FilterBuilders.inFilter(entry.getKey(), termList.toArray());
            filterList.add(fb);
          }
        }
        if (filterList.size() > 1) {
          excludeFilter = FilterBuilders.notFilter(FilterBuilders.orFilter(filterList.toArray(new FilterBuilder[filterList.size()])));
        }
        else if (filterList.size() == 1) {
          excludeFilter = FilterBuilders.notFilter(filterList.get(0));
        }
      }

      QueryBuilder finalQueryBuilder = QueryBuilders.queryString(queryString);

      // The below part is added for XPS-96266
      List<FilterBuilder> regexSearchFilterList = new ArrayList<>();
      if (regexSearchParamMap != null && !regexSearchParamMap.isEmpty()) {
        regexSearchParamMap.entrySet().stream().forEach(
                regexStringParam -> {
                  if (regexStringParam.getValue() != null && isValidRegex(regexStringParam.getValue())) {
                    FilterBuilder regexpFilter = FilterBuilders.regexpFilter(regexStringParam.getKey(),
                            regexStringParam.getValue());
                    regexSearchFilterList.add(regexpFilter);
                  }
                }
        );
      }

      List<FilterBuilder> finalFilterList = new ArrayList<>();
      if (includeFilter != null) {
        finalFilterList.add(includeFilter);
      }
      if (excludeFilter != null) {
        finalFilterList.add(excludeFilter);
      }
      if (!regexSearchFilterList.isEmpty()) {
        finalFilterList.addAll(regexSearchFilterList);
      }

      if (finalFilterList.size() == 1) {
        FilterBuilder combinedFilter = finalFilterList.get(0);
        finalQueryBuilder = QueryBuilders.filteredQuery(finalQueryBuilder, combinedFilter);
      }
      else if (finalFilterList.size() > 1) {
        FilterBuilder combinedFilter = FilterBuilders.andFilter(finalFilterList.toArray(new FilterBuilder[finalFilterList.size()]));
        finalQueryBuilder = QueryBuilders.filteredQuery(finalQueryBuilder, combinedFilter);
      }
      SearchRequestBuilder srb = client.prepareSearch(indexName).setTypes(docType).setQuery(finalQueryBuilder);

      if (!sortMap.isEmpty()) {
        for (Map.Entry<String, String> entry : sortMap.entrySet())
        {
          String sortOrder = entry.getValue();
          if (sortOrder.equalsIgnoreCase(SortOrder.DESC.name())) {
            srb.addSort(SortBuilders.fieldSort(entry.getKey()).order(SortOrder.DESC).missing("_last"));
          }
          else if (sortOrder.equalsIgnoreCase(SortOrder.ASC.name())) {
            srb.addSort(SortBuilders.fieldSort(entry.getKey()).order(SortOrder.ASC).missing("_last"));
          }
          else {
            logger.warn("Expected asc or desc for sort order, found : " + sortOrder);
          }
        }
      }
      else {
        srb.addSort(SortBuilders.fieldSort("remedyAppsTime").order(SortOrder.DESC).missing("_last"));
      }

      srb.setFrom(from);
      srb.setSize(size);

      String[] incSource = sourceInclude.stream().toArray(String[]::new);
      String[] exSource = sourceExclude.stream().toArray(String[]::new);
      if (incSource.length < 1) incSource = null;
      if (exSource.length < 1) exSource = null;
      srb.setFetchSource(incSource, exSource);

      SearchResponse searchResponse = srb.get();

      SearchHits hits = searchResponse.getHits();
      logger.info("Total hits = " + hits.getTotalHits());
      long finishTime = System.currentTimeMillis();
      logger.info("es search time: " + (finishTime - startTime));
      return hits;
    }

    catch (Exception e) {
      logger.error(e);
      throw e;
    }
  }

  public void setClient(Client client) {
    this.client = client;
  }

  public boolean isValidRegex(String userInputPattern) {
    try {
      if (userInputPattern == null || userInputPattern.trim().isEmpty()) {
        return false;
      }
      Pattern.compile(userInputPattern);
    } catch (PatternSyntaxException exception) {
      logger.error(exception.getDescription());
      return false;
    }
    return true;
  }
}
