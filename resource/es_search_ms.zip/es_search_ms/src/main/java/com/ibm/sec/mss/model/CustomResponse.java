package com.ibm.sec.mss.model;

import io.vertx.core.json.JsonArray;

public class CustomResponse {

    private JsonArray items;
    private long totalCount;

    public JsonArray getItems() {

        return items;
    }

    public void setItems(JsonArray items) {
        this.items = items;
    }

    public long getTotalCount() {

        return totalCount;
    }

    public void setTotalCount(long totalCount) {

        this.totalCount = totalCount;
    }
}



