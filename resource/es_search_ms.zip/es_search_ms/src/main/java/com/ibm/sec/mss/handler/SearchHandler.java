/*
 * IBM Confidential - OCO Source Materials
 * Copyright (c) IBM Corp. 1992, 2008
 * Copyright (c) Internet Security Systems, Inc. 1992-2006
 * The source code for this program is not published or otherwise divested of its trade secrets,
 * irrespective of what has been deposited with the U.S. Copyright Office.
 */
package com.ibm.sec.mss.handler;

import com.google.common.collect.Multimap;
import com.ibm.sec.mss.LogFormatter;
import com.ibm.sec.mss.error.ErrorResponse;
import com.ibm.sec.mss.es.ESClientCreator;
import com.ibm.sec.mss.es.SearchUtil;
import com.ibm.sec.mss.model.CustomResponse;
import io.vertx.core.MultiMap;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.HttpStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;

import java.util.*;

import static com.ibm.sec.mss.handler.UuidHandler.HANDLER_THREAD_UUID;

public class SearchHandler extends BaseRoutingHandler {

  private final static Logger logger = LogManager.getLogger(SearchHandler.class);

  private org.elasticsearch.client.Client client;
  private final String HANDLE = "handle";
  private final String REGEX_SEARCH_STRING ="regexSearch";
  private final static String regex = "(?=([^\"]*\"[^\"]*\")*[^\"]*$)"; // split unless its surrounded double quote

  SearchUtil searchUtil;

  public SearchHandler() {
    ESClientCreator creator = new ESClientCreator();
    client = creator.getTransportConnection();
    searchUtil = new SearchUtil();
    searchUtil.setClient(client);
  }

  @Override
  public void handle(RoutingContext routingContext) {
    String threadUuid = routingContext.get(HANDLER_THREAD_UUID);
    logger.info(LogFormatter.getLog(threadUuid, getClass(),HANDLE, String.format("Received GET: query params: %s", routingContext.request().query())));
    if (routingContext.request().params().contains(REGEX_SEARCH_STRING)) {
      validateRegexParams(routingContext);
    }

    try {
            if(null != routingContext.request().params().get("includeTotalCount")&& routingContext.request().params().get("includeTotalCount").equals("true")){
                routingContext.request().params().remove("includeTotalCount");
              CustomResponse customResponse = customsearchForDataWParams(threadUuid, routingContext.request().params(), routingContext.request());
              logger.info(LogFormatter.getLog(threadUuid, getClass(), HANDLE, String.format("Returning results to user, json array size: %s", customResponse.getTotalCount())));
              content(routingContext, customResponse);

            }
            else{
              JsonArray jsonarray = searchForDataWParams(threadUuid, routingContext.request().params(), routingContext.request());
              logger.info(LogFormatter.getLog(threadUuid, getClass(), HANDLE, String.format("Returning results to user, json array size: %s", jsonarray)));
              content(routingContext, jsonarray);
            }


    }
    catch (Exception ex) {
      logger.error(LogFormatter.getLog(threadUuid, getClass(), HANDLE, "Error encountered when communicating with the Elastic Search Cluster.", ex));
      error(routingContext.response(), HttpStatus.SC_INTERNAL_SERVER_ERROR, new ErrorResponse((com.google.common.collect.Multimap<java.lang.String,java.lang.String>)null, HttpStatus.SC_INTERNAL_SERVER_ERROR, "Error encountered when communicating with the Elastic Search Cluster."));
    }
  }

  /**
   * Call the Elastic Search Util to query the Elastic-Search database
   *
   * @param threadUuid
   * @param params
   * @param request
   * @return
   * @throws Exception
   */
  private SearchHits searchForData(String threadUuid, MultiMap params, HttpServerRequest request) throws Exception {

    String indexName = params.get("indexName");
    String indexType = params.get("indexType");
    String userId = StringUtils.isNotEmpty(params.get("userId")) ? params.get("userId") : request.getHeader("x-userid");

    Map<String, String> permissionKeyMap = buildPermissionKeyMapForIndex(indexName);

    String textToSearch = StringUtils.defaultString(params.get("textToSearch"), "*");
    Integer start = NumberUtils.toInt(params.get("start"), 0);
    Integer limit = NumberUtils.toInt(params.get("limit"), 100);

    //build sort map
    LinkedHashMap<String, String> sortMap = buildSortMap(params.get("sort"));

    //include and exclude terms
    Map<String, List<Object>> includeParams = convertIncludeExcludeParmsToMap(params.getAll("include"), threadUuid);
    Map<String, List<Object>> excludeParams = convertIncludeExcludeParmsToMap(params.getAll("exclude"), threadUuid);

    //finally, ranges.
    Map<String, Object[]> rangeParams = convertRangeParamsToMap(params.getAll("range"));
    List<String> sourceInclude = params.getAll("sourceInclude");
    List<String> sourceExclude = params.getAll("sourceExclude");

    Map<String, String> regexSearchParamMap = new HashMap<>();
    if (params.contains(REGEX_SEARCH_STRING)) {
      regexSearchParamMap = buildRegexMap(params.get(REGEX_SEARCH_STRING));
    }

    SearchHits searchHits = null;
    try {
      logger.info(LogFormatter.getLog(threadUuid, getClass(), "searchForDataWParams",
              String.format("Calling Search Util With Params: indexName[%s], indexType[%s], userId[%s], permissionKeyMap[%s], " +
                              "textToSearch[%s], start[%s], limit[%s], sortMap[%s], includeParams[%s], excludeParams[%s], rangeParams[%s], " +
                              "sourceInclude[%s], sourceExclude[%s], subStringSearchParamMap[%s]",
                      indexName, indexType, userId, permissionKeyMap, textToSearch, start, limit, sortMap, includeParams,
                      excludeParams, rangeParams, sourceInclude, sourceExclude, regexSearchParamMap)
      ));

      searchHits = searchUtil.find(indexName, indexType, userId, permissionKeyMap, textToSearch,
              start, limit, sortMap, includeParams, excludeParams, rangeParams, sourceInclude, sourceExclude, regexSearchParamMap);
    } catch (Exception e) {
      throw e;
    }
    return searchHits;
  }

  /**
   * In case the request does not ask for includeTotalCount, return the JsonArray
   * @param threadUuid
   * @param params
   * @param request
   * @return
   * @throws Exception
   */
  public JsonArray searchForDataWParams(String threadUuid, MultiMap params, HttpServerRequest request) throws Exception {
    SearchHits searchHits = searchForData(threadUuid, params, request);
    return parseSearchHits(searchHits);
  }

  /**
   * In case the request contains the param includeTotalCount,we need to add the count of the result in the response
   * @param threadUuid
   * @param params
   * @param request
   * @return
   * @throws Exception
   */
  public CustomResponse customsearchForDataWParams(String threadUuid, MultiMap params, HttpServerRequest request) throws Exception {
    CustomResponse customResponse = new CustomResponse();

    SearchHits searchHits = searchForData(threadUuid, params, request);
    JsonArray jsonArray = parseSearchHits(searchHits);
    customResponse.setTotalCount(searchHits.getTotalHits());

    customResponse.setItems(jsonArray);
    return customResponse;
  }

    protected LinkedHashMap<String, String> buildSortMap(String sortStr) {
    LinkedHashMap<String, String> sortMap = new LinkedHashMap<>();
    if (StringUtils.isEmpty(sortStr)) {
      return sortMap;
    }

    String[] sortAry = sortStr.split(",");
    for (String sort : sortAry) {
      String[] fieldAndSortDirectionPair = sort.split("\\.");
      sortMap.put(fieldAndSortDirectionPair[0], fieldAndSortDirectionPair[1]);
    }
    return sortMap;

  }

  protected Map<String, String> buildPermissionKeyMapForIndex(String indexName) {
    Map<String, String> permMap = new HashMap<>();
    ResourceBundle configProps = ResourceBundle.getBundle("permissionMapping");
    Enumeration<String> keys = configProps.getKeys();
    while (keys.hasMoreElements()) {
      String key = keys.nextElement();
      String[] indexToPropName = key.split("\\.");
      if (indexName.equalsIgnoreCase(indexToPropName[0])) {
        permMap.put(indexToPropName[1], configProps.getString(key));
      }
    }

    return permMap;
  }

  /**
   * extracting the regex map from the regex String provided in param
   * regexSearch=internalTicketId:.*"ITSM\-ID\-12345678".*,id:.*"OCY007020690".*
   * to be converted to {("internalTicketId","*."ITSM\-ID\-12345678".*"),("id",".*"OCY007020690".*")}
   * @param regexStringSearch
   * @return
   */
  protected Map<String, String> buildRegexMap(String regexStringSearch) {


    Map<String, String> regexStringHashMap = new HashMap<>();

    String[] paramValuePairArr = regexStringSearch.split("," + regex);
    for (String paramValuePair : paramValuePairArr) {
      try {
        String[] paramsArr = paramValuePair.split(":" + regex);
        regexStringHashMap.put(paramsArr[0], paramsArr[1].replace("**COMMA**", ","));

      } catch (Exception ex) {
        logger.error(LogFormatter.getLog(getClass(), HANDLE,
                "Error encountered while regex param extraction", ex));
      }
    }
    logger.info(LogFormatter.getLog(getClass(), "buildSubStringMap", String.format("Regex Map contains [%s]", regexStringHashMap)));
    return regexStringHashMap;
  }

  protected Map<String, Object[]> convertRangeParamsToMap(List<String> params) {
    Map<String, Object[]> rangeMap = new HashMap<>();

    if (params == null) {
      return rangeMap;
    }

    for (String param : params) {
      String name = param.substring(0, param.indexOf("("));
      String values = param.substring(param.indexOf("(") + 1, param.indexOf(")"));
      String[] valueAry = values.split(",");
      rangeMap.put(name, new Object[]{valueAry[0], valueAry[1]});
    }

    return rangeMap;
  }

  protected Map<String, List<Object>> convertIncludeExcludeParmsToMap(List<String> params, String threadUuid) {
    Map<String, List<Object>> termsMap = new HashMap<>();

    if (params == null) {
      return termsMap;
    }

    for (String param : params) {

      String name = param.substring(0, param.indexOf("["));
      String values = param.substring(param.indexOf("[") + 1, param.indexOf("]"));
      String[] valueAry = values.split(",");
      List<Object> valuesList = new ArrayList<>();
      for (String s : valueAry) {
        s = s.replace("**COMMA**", ",");
        valuesList.add(s.trim().toUpperCase());
      }
      termsMap.put(name, valuesList);

      logger.info(LogFormatter.getLog(threadUuid, getClass(), "convertIncludeExcludeParmsToMap",
              String.format("Param being split out: [%s]:\tinto [%s] parts\tsplit: [%s]", param, values.split(",").length, valuesList)));

    }

    return termsMap;
  }

  protected JsonArray parseSearchHits(SearchHits searchHits) {
    logger.debug("Parsing the search hits now, length: " + searchHits.getHits().length);

    JsonArray jsonAry = new JsonArray();
    SearchHit[] hits = searchHits.getHits();
    for (SearchHit hit : hits) {
      JsonObject obj = new JsonObject(hit.getSourceAsString());
      jsonAry.add(obj);
    }

    return jsonAry;
  }

  public void closeClient() {
    client.close();
  }

  public void setSearchUtil(SearchUtil searchUtil) {
    this.searchUtil = searchUtil;
  }


  /**
   * Check for input param validation
   *
   * @param routingContext
   * @return
   */
  private boolean validateRegexParams(RoutingContext routingContext) {

    MultiMap params = routingContext.request().params();

    String regexString = params.get(REGEX_SEARCH_STRING);
    // if regexSearch key is found then we need to validate the string
    try {
      if (regexString.isEmpty() || !regexString.contains(":")) {
        throw new Exception("Invalid regexSearch found");
      } else {
        String regex = "(?=([^\"]*\"[^\"]*\")*[^\"]*$)"; // split unless its surrounded double quote
        String[] paramValuePairArr = regexString.split("," + regex);
        for (String paramValuePair : paramValuePairArr) {
          String[] paramsArr = paramValuePair.split(":" + regex);
          if (paramsArr.length < 2) {
            throw new Exception(String.format("field %s", paramValuePair));
          }
        }
      }
    } catch (Exception e) {
      ErrorResponse errorResponse = new ErrorResponse((Multimap<String, String>) null, HttpStatus.SC_BAD_REQUEST, String.format("No valid regexSearch String found for %s", e.getMessage()));
      error(routingContext.response(), HttpStatus.SC_BAD_REQUEST, errorResponse);
      return false;
    }
    return true;
  }

}
