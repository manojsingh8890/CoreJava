package com.ibm.sec.mss;

import io.vertx.core.Launcher;

public class LocalLauncher {

    public static void main(String[] args) {
        Launcher.main(new String[] {"run", SearchVerticle.class.getName()});
    }
}
