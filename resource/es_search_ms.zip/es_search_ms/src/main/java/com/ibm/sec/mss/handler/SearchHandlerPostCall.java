package com.ibm.sec.mss.handler;

import static com.ibm.sec.mss.handler.UuidHandler.HANDLER_THREAD_UUID;

import com.google.common.collect.ArrayListMultimap;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.HttpStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ibm.sec.mss.ElasticSearchConfiguration;

/*
 * IBM Confidential - OCO Source Materials
 * Copyright (c) IBM Corp. 1992, 2008
 * Copyright (c) Internet Security Systems, Inc. 1992-2006
 * The source code for this program is not published or otherwise divested of its trade secrets,
 * irrespective of what has been deposited with the U.S. Copyright Office.
 */


import com.ibm.sec.mss.LogFormatter;
import com.ibm.sec.mss.error.ErrorResponse;
import com.ibm.sec.mss.es.ESClientCreator;
import com.ibm.sec.mss.es.SearchUtil;

import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;

public class SearchHandlerPostCall extends BaseRoutingHandler {

 private final static Logger logger = LogManager.getLogger(SearchHandlerPostCall.class);

  private org.elasticsearch.client.Client client;
  private final String HANDLE = "handle";
  SearchUtil searchUtil;
  SearchHandler searchHandler;
  private String limit;

  public SearchHandlerPostCall() {
    ESClientCreator creator = new ESClientCreator();
    ElasticSearchConfiguration config = ElasticSearchConfiguration.getInstance();
    client = creator.getTransportConnection();
    limit = config.getBulkFetchSearchLimit();
    searchUtil = new SearchUtil();
    searchUtil.setClient(client);
    searchHandler = new SearchHandler();
    searchHandler.setSearchUtil(searchUtil);
  }
  

 @Override
  public void handle(RoutingContext routingContext) {
    String threadUuid = routingContext.get(HANDLER_THREAD_UUID);
    logger.info(LogFormatter.getLog(threadUuid, getClass(),HANDLE, String.format("Received Post: query params: %s, request body: %s", routingContext.request().query(), routingContext.getBodyAsString())));
    try {
	 /*
	  * Adding include parameter by iterating JSON body 
	  * Converting JSON to include params format
	  * e.g. "id": ["x","y", "z"] to id[x,y,z]
	 */
      JsonObject bulkFetchReqObject= routingContext.getBodyAsJson();
      if(bulkFetchReqObject != null) {
    	  bulkFetchReqObject.forEach( property -> {
	      routingContext.request().params().add("include", property.getKey()+property.getValue().toString().replaceAll("\"", ""));
	    });
      }
      if(routingContext.request().params().get("limit") == null || ("").equals(routingContext.request().params().get("limit").trim())
    		  || NumberUtils.toInt(routingContext.request().params().get("limit")) > NumberUtils.toInt(limit)){
    	  routingContext.request().params().remove("limit");
    	  routingContext.request().params().set("limit", limit);
      }
      searchHandler.handle(routingContext);
    }
    catch (Exception ex) {
      logger.error(LogFormatter.getLog(threadUuid, getClass(), HANDLE, "Error encountered when communicating with the Elastic Search Cluster.", ex));
      error(routingContext.response(), HttpStatus.SC_INTERNAL_SERVER_ERROR, new ErrorResponse(ArrayListMultimap.create(), HttpStatus.SC_INTERNAL_SERVER_ERROR, "Error encountered when communicating with the Elastic Search Cluster."));
    }
  } 
 
  public void setSearchHandler(SearchHandler searchHandler) {
	this.searchHandler = searchHandler;
  }
  
  public void closeClient() {
	client.close();
  }
} 
