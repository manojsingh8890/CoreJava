package com.ibm.sec.mss;

import com.ibm.sec.mss.config.ApplicationConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ResourceBundle;

public class ElasticSearchConfiguration extends ApplicationConfiguration {
    private static final Logger logger = LogManager.getLogger(ElasticSearchConfiguration.class);
    private static ElasticSearchConfiguration _instance;

    private String port;
    private String pingTimeout;
    private String sslProtocol;
    private String sslNativeEnabled;
    private String sslRestEnabled;
    private String forceNativeClientAuth;
    private String forceRestClientAuth;
    private String clientTransportHosts;
    private String clusterName;
    private String sslServerKeyStorePath;
    private String sslServerKeyStorePassword;
    private String sslServerTrustStorePath;
    private String sslServerTrustStorePassword;
    private String bulkFetchSearchLimit;

    private ElasticSearchConfiguration() {
        try {
            ResourceBundle properties = ResourceBundle.getBundle("application");
            port = getProperty("elastic_search.port", "9300", properties);
            pingTimeout = getProperty("elastic_search.client.transport.ping_timeout", "60s", properties);
            sslProtocol = getProperty("elastic_search.mss.ssl.protocol", "TLSv1.2", properties);
            sslNativeEnabled = getProperty("elastic_search.mss.ssl.native.enabled", "true", properties);
            sslRestEnabled = getProperty("elastic_search.mss.ssl.rest.enabled", "false", properties);
            forceNativeClientAuth = getProperty("elastic_search.mss.ssl.forceNativeClientAuth", "true", properties);
            forceRestClientAuth = getProperty("elastic_search.mss.ssl.forceRestClientAuth", "false", properties);
            clientTransportHosts = getProperty("elastic_search_client_transport_hosts", "dal09-dev-solr-01a.sec.ibm.com,dal09-dev-solr-01b.sec.ibm.com,dal09-dev-solr-01c.sec.ibm", properties);
            clusterName = getProperty("elastic_search_cluster_name", "elastic_dal09dev", properties);
            sslServerKeyStorePath = getProperty("elastic_search_mss_ssl_server_keyStore", "/opt/mssdev/es_search_ms/conf/esclientkeystore", properties);
            sslServerKeyStorePassword = getProperty("secret.modules.es_search_ms.keystore.PASSWORD", "cl0219Cert", properties);
            sslServerTrustStorePath = getProperty("elastic_search_mss_ssl_server_trustStore", "/opt/mssdev/es_search_ms/conf/esclienttruststore", properties);
            sslServerTrustStorePassword = getProperty("secret.modules.es_search_ms.truststore.PASSWORD", "cl0219Cert", properties);
            bulkFetchSearchLimit = getProperty("elastic_search_bulk_fetch_limit", "1000", properties);
        }
        catch (Exception e) {
            logger.error(LogFormatter.getLog(getClass(), "constructor", "Failed get properties.", e));
        }
    }

    public static synchronized ElasticSearchConfiguration getInstance() {
        if (_instance == null) {
            _instance = new ElasticSearchConfiguration();
        }
        return _instance;
    }

    public String getPort() {
        return port;
    }


    public String getPingTimeout() {
        return pingTimeout;
    }


    public String getSslProtocol() {
        return sslProtocol;
    }


    public String getSslNativeEnabled() {
        return sslNativeEnabled;
    }


    public String getSslRestEnabled() {
        return sslRestEnabled;
    }


    public String getForceNativeClientAuth() {
        return forceNativeClientAuth;
    }


    public String getForceRestClientAuth() {
        return forceRestClientAuth;
    }


    public String getClientTransportHosts() {
        return clientTransportHosts;
    }


    public String getClusterName() {
        return clusterName;
    }


    public String getSslServerKeyStorePath() {
        return sslServerKeyStorePath;
    }


    public String getSslServerKeyStorePassword() {
        return sslServerKeyStorePassword;
    }


    public String getSslServerTrustStorePath() {
        return sslServerTrustStorePath;
    }


    public String getSslServerTrustStorePassword() {
        return sslServerTrustStorePassword;
    }

	public String getBulkFetchSearchLimit() {
		return bulkFetchSearchLimit;
	}
}
