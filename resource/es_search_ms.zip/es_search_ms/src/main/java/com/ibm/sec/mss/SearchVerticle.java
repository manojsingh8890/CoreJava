package com.ibm.sec.mss;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ibm.sec.mss.handler.PreAuthorizationHandler;
import com.ibm.sec.mss.handler.SearchHandler;
import com.ibm.sec.mss.handler.SearchHandlerPostCall;
import com.ibm.sec.mss.handler.UuidHandler;
import com.ibm.sec.mss.verticle.ServiceVerticle;

import io.vertx.ext.web.Router;


public class SearchVerticle extends ServiceVerticle
{

	private static final transient Logger logger = LogManager.getLogger(SearchVerticle.class);

	private SearchHandler searchHandler = new SearchHandler();
	private SearchHandlerPostCall searchHandlerPostCall = new SearchHandlerPostCall();

	@Override
	protected void configureRouter(Router router)
	{
		logger.info(LogFormatter.getLog(getClass(), "configureRouter", "Configuring route GET /es_search*"));
		get(router, "/es_search*", new UuidHandler(new PreAuthorizationHandler(searchHandler)));
		post(router, "/es_search/fetch-all", new UuidHandler(new PreAuthorizationHandler(searchHandlerPostCall)));
		
	}

	@Override
	public void stop()
	{
		logger.info(LogFormatter.getLog(getClass(), "stop", "Shutdown issued, closing client and then stopping process."));
		searchHandler.closeClient();
		super.stop();
	}

	public void setSearchHandler(SearchHandler searchHandler) {
		this.searchHandler = searchHandler;
	}
	
	public void setSearchHandlerPostCall(SearchHandlerPostCall searchHandlerPostCall) {
		this.searchHandlerPostCall = searchHandlerPostCall;
	}
}