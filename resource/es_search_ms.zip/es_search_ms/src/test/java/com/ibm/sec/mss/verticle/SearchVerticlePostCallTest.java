package com.ibm.sec.mss.verticle;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.function.Consumer;

import io.vertx.core.http.HttpMethod;
import io.vertx.ext.web.client.WebClient;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;

import com.ibm.sec.mss.BaseServiceVerticleTest;
import com.ibm.sec.mss.ElasticSearchConfiguration;
import com.ibm.sec.mss.SearchVerticle;
import com.ibm.sec.mss.config.ApplicationConfiguration;
import com.ibm.sec.mss.es.ESClientCreator;
import com.ibm.sec.mss.es.SearchUtil;
import com.ibm.sec.mss.es.impls.CustomSearchHit;
import com.ibm.sec.mss.es.impls.CustomSearchHits;
import com.ibm.sec.mss.handler.SearchHandler;
import com.ibm.sec.mss.handler.SearchHandlerPostCall;

import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpHeaders;
import io.vertx.ext.unit.Async;
import io.vertx.ext.unit.TestContext;
import io.vertx.ext.unit.junit.VertxUnitRunner;

@RunWith(VertxUnitRunner.class)
public class SearchVerticlePostCallTest extends BaseServiceVerticleTest {
  private String verticleDeploymentId;
  private SearchHandlerPostCall postSearchHandler;
  private SearchUtil searchUtil;
  private SearchHandler searchHandler;
  org.elasticsearch.client.Client client;

  @BeforeClass
  public static void setUp() {
    ApplicationConfiguration.getInstance().setTestMode(true);
  }

  @Before
  public void before(TestContext context) {
    searchUtil = PowerMockito.mock(SearchUtil.class);
    SearchVerticle verticle = new SearchVerticle();
    ESClientCreator creator = new ESClientCreator();
    client = creator.getTransportConnection();
    searchHandler = new SearchHandler();
    searchHandler.setSearchUtil(searchUtil);
    searchUtil.setClient(client);
    postSearchHandler = new SearchHandlerPostCall();
    verticle.setSearchHandlerPostCall(postSearchHandler);
    postSearchHandler.setSearchHandler(searchHandler);
    vertx.deployVerticle(verticle, context.asyncAssertSuccess(deploymentId -> verticleDeploymentId = deploymentId));
  }

  @After
  public void after(TestContext context) {
    vertx.undeploy(verticleDeploymentId, context.asyncAssertSuccess(Void -> verticleDeploymentId = null));
    postSearchHandler.closeClient();
  }

  @Override
  protected void clientGet(String uri, Consumer<Buffer> consumer, TestContext context) {
      WebClient client = WebClient.create(vertx);
      Async async = context.async();
      client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost", uri)
              .send().onSuccess(successHandler -> {
                  context.assertTrue(true);
                  client.close();
                  async.complete();
              }).onFailure(failureHandler -> {
                  context.assertFalse(true);
                  client.close();
                  async.complete();
              });
  }

  @Test
  public void testPostSearchRequest(TestContext context) {
	  String requestData = "{\"id\":[\"P37\",\"P45\",\"P45\"]}";
    try {
     CustomSearchHit[] hitAry = new CustomSearchHit[1];
     hitAry[0] = new CustomSearchHit(requestData);
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),any()))
      .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    // Send a request and get a response
      WebClient client = WebClient.create(vertx);
      Async async = context.async();
      client.post(ApplicationConfiguration.getInstance().getServerPort(), "localhost", "/es_search/fetch-all?indexName=opsdevicedetails&indexType=indexType")
              .putHeader(HttpHeaders.CONTENT_TYPE.toString(), HttpHeaders.APPLICATION_X_WWW_FORM_URLENCODED.toString())
              .putHeader(HttpHeaders.CONTENT_LENGTH.toString(), String.valueOf(requestData.length()))
              .sendBuffer(Buffer.buffer(requestData))
              .onSuccess(successHandler -> {
                  context.assertEquals(200, successHandler.statusCode());
                  client.close();
                  async.complete();
              }).onFailure(failureHandler -> {
                  context.assertFalse(true);
                  client.close();
                  async.complete();
              });
  }
  
  @Test
  public void testPostSearchRequestForLimit(TestContext context) {
	  String requestData = "{\"id\":[\"P37\",\"P45\",\"P45\"]}";
    try {
     CustomSearchHit[] hitAry = new CustomSearchHit[1];
     hitAry[0] = new CustomSearchHit(requestData);
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),any()))
      .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    // Send a request and get a response
      WebClient client = WebClient.create(vertx);
      Async async = context.async();
      client.post(ApplicationConfiguration.getInstance().getServerPort(), "localhost", "/es_search/fetch-all?indexName=opsdevicedetails&indexType=indexType&limit= ")
              .putHeader(HttpHeaders.CONTENT_TYPE.toString(), HttpHeaders.APPLICATION_X_WWW_FORM_URLENCODED.toString())
              .putHeader(HttpHeaders.CONTENT_LENGTH.toString(), String.valueOf(requestData.length()))
              .sendBuffer(Buffer.buffer(requestData))
              .onSuccess(successHandler -> {
                  context.assertEquals(200, successHandler.statusCode());
                  client.close();
                  async.complete();
              }).onFailure(failureHandler -> {
                  context.assertFalse(true);
                  client.close();
                  async.complete();
              });
  }
  
  @Test
  public void postSearchRequestNegativeTest(TestContext context) {
	  String requestData = "{\"indexType\":\"device\",\"userId\": \"test\",\"include\":{\"id\":[\"P37\",\"P45\",\"P45\"]},\n"
	      		+ "\"exclude\":{\"customerId\": [\"CIDS\"]},\"range\": {\"createdDate\": [\"dt1\", \"dt2\"]},\n"
	      		+ "\"match\":{\"status\": [\"Active\"]},\"sourceInclude\": [\"test\"],\n"
	      		+ "\"sourceExclude\": [\"exclude\"],\"sort\": {\"sort\": \"city\"},";
    try {
     CustomSearchHit[] hitAry = new CustomSearchHit[1];
     hitAry[0] = new CustomSearchHit(requestData);
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),any()))
      .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    // Send a request and get a response
      WebClient client = WebClient.create(vertx);
      Async async = context.async();
      client.post(ApplicationConfiguration.getInstance().getServerPort(), "localhost", "/es_search/fetch-all?indexName=opsdevicedetails&indexType=indexType")
              .putHeader(HttpHeaders.CONTENT_TYPE.toString(), HttpHeaders.APPLICATION_X_WWW_FORM_URLENCODED.toString())
              .putHeader(HttpHeaders.CONTENT_LENGTH.toString(), String.valueOf(requestData.length()))
              .sendJson(requestData)
              .onSuccess(successHandler -> {
                  context.assertEquals(500, successHandler.statusCode());
                  client.close();
                  async.complete();
              }).onFailure(failureHandler -> {
                  context.assertFalse(true);
                  client.close();
                  async.complete();
              });

  }
}