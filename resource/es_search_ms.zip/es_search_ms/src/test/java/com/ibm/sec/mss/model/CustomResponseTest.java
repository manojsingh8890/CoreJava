package com.ibm.sec.mss.model;

import io.vertx.core.json.JsonArray;
import org.junit.Test;

import static org.testng.Assert.assertEquals;

public class CustomResponseTest {

    String s = "{\"id\": \"SOCY00702056623\",\"customerId\": \"P000000614\",\"severityVal\": \"SEV1\",\"nature\": \"Service Incident\",\"issueDescription\": \"Ticket created by automated tests\",\"partnerId\": \"P000000613\",\"securityAnalyst\": \"wobc\",\"ticketGuid\": \"IDGAA5V0FCRFIAQVK2XNQULL1SVZY4\",\"devices\":[{\"deviceId\": \"STG000008073943\", \"id\": \"DEV000006671600\"}]}";

    @Test
    public void customTestResponse(){

        JsonArray items = new JsonArray();
        items.add(s);
        Long totalCount = 12345678L;

        CustomResponse customResponse = new CustomResponse();
        customResponse.setItems(items);
        customResponse.setTotalCount(totalCount);

        assertEquals(12345678,customResponse.getTotalCount());
        assertEquals(items,customResponse.getItems());
    }

    @Test
    public void testSetTotalCount(){
        Long totalCount = 1234568L;
        CustomResponse customResponse = new CustomResponse();
        customResponse.setTotalCount(totalCount);
        assertEquals(1234568,customResponse.getTotalCount());

    }

    @Test
    public void testSetItems(){
        JsonArray item = new JsonArray();
        item.add(s);
        CustomResponse customResponse = new CustomResponse();
        customResponse.setItems(item);
        assertEquals(item,customResponse.getItems());

    }

    @Test
    public void testGetTotalCount() {
        Long tCount = 12345L;
        CustomResponse customResponse = new CustomResponse();
        customResponse.setTotalCount(12345L);
        Long totalCount = customResponse.getTotalCount();
        assertEquals(totalCount, tCount);
    }

}
