package com.ibm.sec.mss.es;

import com.ibm.sec.mss.es.impls.CustomSearchHit;
import com.ibm.sec.mss.es.impls.CustomSearchHits;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.SearchHits;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;

import java.util.*;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

class SearchRequestField {
    private LinkedHashMap<String, String> sortMap = new LinkedHashMap<>();
    private HashMap<String, List<Object>> includes = new HashMap<>();
    private HashMap<String, List<Object>> excludes = new HashMap<>();
    List<String> sourceInclude = new ArrayList<>();
    List<String> sourceExclude = new ArrayList<>();

    public LinkedHashMap<String, String> getSortMap() {
        sortMap.put("theatreVal", "desc");
        return sortMap;
    }

    public HashMap<String, List<Object>> getIncludes() {
        ArrayList includeVals = new ArrayList<>();
        includeVals.add("Mexico");
        includeVals.add("Canada");
        includes.put("country", includeVals);
        return includes;
    }

    public HashMap<String, List<Object>> getExcludes() {
        ArrayList excludeVals = new ArrayList<>();
        excludeVals.add("computer");
        excludes.put("industry", excludeVals);
        return excludes;
    }

    public List<String> getSourceInclude() {
        return sourceInclude;
    }

    public List<String> getSourceExclude() {
        return sourceExclude;
    }

}

public class SearchUtilTest {

    final SearchRequestField requestField = new SearchRequestField();

    public void populateMockData(SearchUtil util, CustomSearchHits hitsImpl) {

        Client clientMock = Mockito.mock(Client.class);
        SearchRequestBuilder newSrb = PowerMockito.mock(SearchRequestBuilder.class);
        SearchResponse searchResponse = PowerMockito.mock(SearchResponse.class);

        when(newSrb.setTypes(any())).thenReturn(newSrb);
        when(newSrb.setQuery(any(QueryBuilder.class))).thenReturn(newSrb);
        when(clientMock.prepareSearch(any())).thenReturn(newSrb);
        when(searchResponse.getHits()).thenReturn(hitsImpl);
        when(newSrb.get()).thenReturn(searchResponse);
        util.setClient(clientMock);
    }

    public CustomSearchHits populateCustomerSearch(int count) {
        CustomSearchHit[] hitAry = new CustomSearchHit[count];
        hitAry[0] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
        if (count > 1) {
            hitAry[1] = new CustomSearchHit("{\"id\":\"CID001696\",\"lastModifyDate\":\"Wed Jun 20 18:05:52 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Internal\",\"industry\":\"Oil & Gas Extraction\",\"portalURL\":\"testa14\",\"fromAddressEmail\":\"test\",\"emailSignature\":\"test\",\"country\":\"United States\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"8\",\"name\":\"Demo Customer\",\"partnerId\":\"CIDS705057\",\"partnerName\":\"Demo Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529517953650\"}");
        }
        CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
        return hitsImpl;
    }

    @Test
    public void find() {
        SearchUtil util = new SearchUtil();
        populateMockData(util, populateCustomerSearch(2));

        try {
            util.find("hdcustomerdetail", "customer", "", new HashMap<>(), "*",
                    0, 10, requestField.getSortMap(), requestField.getIncludes(), requestField.getExcludes(), null, new ArrayList<String>(), new ArrayList<String>(), null);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test
    public void findWithSingleValidRegex() {

        SearchUtil util = new SearchUtil();
        populateMockData(util, populateCustomerSearch(1));

        Map<String, String> regexMap = new HashMap<>();
        regexMap.put("id", ".*P000000614.*");

        try {
            SearchHits searchHit = util.find("hdcustomerdetail", "customer", "", new HashMap<>(), "*",
                    0, 10, requestField.getSortMap(), requestField.getIncludes(), requestField.getExcludes(), null, requestField.getSourceInclude(), requestField.getSourceExclude(), regexMap);
            Assert.assertNotNull(searchHit.getHits());
            Assert.assertEquals(1, searchHit.getHits().length);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void findWithSingleInValidRegex() {

        SearchUtil util = new SearchUtil();
        populateMockData(util, populateCustomerSearch(2));

        Map<String, String> regexMap = new HashMap<>();
        regexMap.put("id", ".*&.)((*(&&**(&^&*");

        try {
            SearchHits searchHit = util.find("hdcustomerdetail", "customer", "", new HashMap<>(), "*",
                    0, 10, requestField.getSortMap(), requestField.getIncludes(), requestField.getExcludes(), null, requestField.getSourceInclude(), requestField.getSourceExclude(), regexMap);
            Assert.assertNotNull(searchHit.getHits());
            Assert.assertEquals(2, searchHit.getHits().length);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void findWithSingleInNullValueRegex() {

        SearchUtil util = new SearchUtil();
        populateMockData(util, populateCustomerSearch(2));
        Map<String, String> regexMap = new HashMap<>();
        regexMap.put("id", null);

        try {
            SearchHits searchHit = util.find("hdcustomerdetail", "customer", "", new HashMap<>(), "*",
                    0, 10, requestField.getSortMap(), requestField.getIncludes(), requestField.getExcludes(), null, requestField.getSourceInclude(), requestField.getSourceExclude(), regexMap);
            Assert.assertNotNull(searchHit.getHits());
            Assert.assertEquals(2, searchHit.getHits().length);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void findWithSingleInNullRegex() {

        SearchUtil util = new SearchUtil();
        populateMockData(util, populateCustomerSearch(2));
        try {
            SearchHits searchHit = util.find("hdcustomerdetail", "customer", "", new HashMap<>(), "*",
                    0, 10, requestField.getSortMap(), requestField.getIncludes(), requestField.getExcludes(), null, requestField.getSourceInclude(), requestField.getSourceExclude(), null);
            Assert.assertNotNull(searchHit.getHits());
            Assert.assertEquals(2, searchHit.getHits().length);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testValidRegex() {
        String regexInput = ".*ABC.*";
        boolean isValid = new SearchUtil().isValidRegex(regexInput);
        Assert.assertTrue(isValid);
    }

    @Test
    public void testInValidRegex() {
        String regexInput = ".*ABC.()*^&^BSAD(*";
        boolean isValid = new SearchUtil().isValidRegex(regexInput);
        Assert.assertFalse(isValid);
    }


    @Test
    public void testValidStringRegex() {
        String regexInput = "ABCD";
        boolean isValid = new SearchUtil().isValidRegex(regexInput);
        Assert.assertTrue(isValid);

    }

    @Test
    public void testInValidEmptyRegex() {
        String regexInput = "";
        boolean isValid = new SearchUtil().isValidRegex(regexInput);
        Assert.assertFalse(isValid);
    }

    @Test
    public void testInValidNullRegex() {
        String regexInput = null;
        boolean isValid = new SearchUtil().isValidRegex(regexInput);
        Assert.assertFalse(isValid);
    }
}