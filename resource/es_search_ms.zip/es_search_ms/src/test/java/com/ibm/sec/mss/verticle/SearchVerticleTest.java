package com.ibm.sec.mss.verticle;

import com.ibm.sec.mss.BaseServiceVerticleTest;
import com.ibm.sec.mss.SearchVerticle;
import com.ibm.sec.mss.config.ApplicationConfiguration;
import com.ibm.sec.mss.es.SearchUtil;
import com.ibm.sec.mss.es.impls.CustomSearchHit;
import com.ibm.sec.mss.es.impls.CustomSearchHits;
import com.ibm.sec.mss.handler.SearchHandler;
import io.vertx.core.buffer.Buffer;
import io.vertx.ext.unit.Async;
import io.vertx.ext.unit.TestContext;
import io.vertx.ext.unit.junit.VertxUnitRunner;
import io.vertx.ext.web.client.WebClient;
import org.apache.commons.lang3.time.DateUtils;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.function.Consumer;

import static org.mockito.Matchers.*;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(VertxUnitRunner.class)
public class SearchVerticleTest extends BaseServiceVerticleTest {
  private String verticleDeploymentId;
  private SearchHandler searchHandler;
  private SearchUtil searchUtil;

  @BeforeClass
  public static void setUp() {
    ApplicationConfiguration.getInstance().setTestMode(true);
  }

  @Before
  public void before(TestContext context) {
    searchUtil = PowerMockito.mock(SearchUtil.class);

    SearchVerticle verticle = new SearchVerticle();
    searchHandler = new SearchHandler();
    searchHandler.setSearchUtil(searchUtil);
    verticle.setSearchHandler(searchHandler);
    vertx.deployVerticle(verticle, context.asyncAssertSuccess(deploymentId -> verticleDeploymentId = deploymentId));
  }

  @After
  public void after(TestContext context) {
    vertx.undeploy(verticleDeploymentId, context.asyncAssertSuccess(Void -> verticleDeploymentId = null));
  }

  @Override
  protected void clientGet(String uri, Consumer<Buffer> consumer, TestContext context) {
    WebClient client = WebClient.create(vertx);
    Async async = context.async();
    client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost", uri)
            .send()
            .onSuccess(successHandler -> {
              client.close();
              async.complete();
            }).onFailure(failureHandler -> {
              failureHandler.printStackTrace();
              client.close();
              async.complete();
            });
  }

  @Test
  public void testSortAndLimitParams(TestContext context) {

    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[2];
      hitAry[0] = new CustomSearchHit("{\"id\":\"CID001696\",\"lastModifyDate\":\"Wed Jun 20 18:05:52 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Internal\",\"industry\":\"Oil & Gas Extraction\",\"portalURL\":\"testa14\",\"fromAddressEmail\":\"test\",\"emailSignature\":\"test\",\"country\":\"United States\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"8\",\"name\":\"Demo Customer\",\"partnerId\":\"CIDS705057\",\"partnerName\":\"Demo Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529517953650\"}");
      hitAry[1] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
    WebClient client = WebClient.create(vertx);
    Async async = context.async();
    client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
            "/es_search?indexName=hdcustomerdetail&indexType=customer&start=0&limit=20&sort=country.asc\"")
		    .send()
		    .onSuccess(successHandler -> {
              client.close();
              async.complete();
            }).onFailure(failureHandler -> {
              failureHandler.printStackTrace();
              client.close();
              async.complete();
            });

  }

  @Test
  public void testIncludesExcludesParams(TestContext context) {

    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[2];
      hitAry[0] = new CustomSearchHit("{\"id\":\"CID001696\",\"lastModifyDate\":\"Wed Jun 20 18:05:52 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Internal\",\"industry\":\"Oil & Gas Extraction\",\"portalURL\":\"testa14\",\"fromAddressEmail\":\"test\",\"emailSignature\":\"test\",\"country\":\"United States\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"8\",\"name\":\"Demo Customer\",\"partnerId\":\"CIDS705057\",\"partnerName\":\"Demo Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529517953650\"}");
      hitAry[1] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      SearchResponse searchResponse = new SearchResponse();
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
    WebClient client = WebClient.create(vertx);
    Async async = context.async();
    client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
                    "/es_search?indexName=hdcustomerdetail&indexType=customer&include=industry[Automotive]&include=theatreVal[APAC]")
            .send()
            .onSuccess(successHandler -> {
              context.assertEquals(200, successHandler.statusCode());
              client.close();
              async.complete();
            }).onFailure(failureHandler -> {
              failureHandler.printStackTrace();
              client.close();
              async.complete();
            });

  }

  @Test
  public void testRangeParams(TestContext context) {

    try {
      String expectedPattern = "EEE MMM dd HH:mm:ss yyyy";
      SimpleDateFormat formatter = new SimpleDateFormat(expectedPattern);
      formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
      TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
      Date now = new Date();

      Date startDt = DateUtils.addMonths(now, -10);
      Date endDt = DateUtils.addMinutes(now, 20);

      String url = "/es_search?indexName=hdcustomerdetail&indexType=customer&range=lastModifyDate";
      String urlRangeParam = URLEncoder.encode("(" + startDt.toString() + "," + endDt.toString() + ")", "UTF-8");

      CustomSearchHit[] hitAry = new CustomSearchHit[2];
      hitAry[0] = new CustomSearchHit("{\"id\":\"CID001696\",\"lastModifyDate\":\"Wed Jun 20 18:05:52 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Internal\",\"industry\":\"Oil & Gas Extraction\",\"portalURL\":\"testa14\",\"fromAddressEmail\":\"test\",\"emailSignature\":\"test\",\"country\":\"United States\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"8\",\"name\":\"Demo Customer\",\"partnerId\":\"CIDS705057\",\"partnerName\":\"Demo Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529517953650\"}");
      hitAry[1] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);


      // Send a request and get a response
      WebClient client = WebClient.create(vertx);
      Async async = context.async();
      client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
                      url + urlRangeParam)
              .send()
              .onSuccess(successHandler -> {
                context.assertEquals(200, successHandler.statusCode());
                client.close();
                async.complete();
              }).onFailure(failureHandler -> {
                failureHandler.printStackTrace();
                client.close();
                async.complete();
              });
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }


  @Test
  public void testIncludeTotalCount(TestContext context) {
    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[2];
      hitAry[0] = new CustomSearchHit("{\"id\":\"CID001696\",\"lastModifyDate\":\"Wed Jun 20 18:05:52 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Internal\",\"industry\":\"Oil & Gas Extraction\",\"portalURL\":\"testa14\",\"fromAddressEmail\":\"test\",\"emailSignature\":\"test\",\"country\":\"United States\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"8\",\"name\":\"Demo Customer\",\"partnerId\":\"CIDS705057\",\"partnerName\":\"Demo Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529517953650\"}");
      hitAry[1] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      SearchResponse searchResponse = new SearchResponse();
      //SearchHandler searchHandler = mock(SearchHandler.class);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
    WebClient client = WebClient.create(vertx);
    Async async = context.async();
    client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
            "/es_search?indexName=hdcustomerdetail&indexType=customer&include=industry[Automotive]&include=theatreVal[APAC]&includeTotalCount=true")
    .send()
    .onSuccess(successHandler -> {
      System.out.println("Response code:" + successHandler.statusCode());
      context.assertEquals(200, successHandler.statusCode());
      client.close();
      async.complete();
    }).onFailure(failureHandler -> {
      failureHandler.printStackTrace();
      client.close();
      async.complete();
    });

  }

  @Test
  public void testWithValidRegexParam(TestContext context) {

    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[1];
      hitAry[0] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
    WebClient client = WebClient.create(vertx);
    Async async = context.async();
	client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
			"/es_search?indexName=hdcustomerdetail&indexType=customer&start=0&limit=20&sort=country.asc&regexSearch=id:.*000000614.*")
			.send().onSuccess(successHandler -> {
				context.assertEquals(200, successHandler.statusCode());
				client.close();
				async.complete();
			}).onFailure(failureHandler -> {
				failureHandler.printStackTrace();
				client.close();
				async.complete();
			});
  }

  @Test
  public void testWithINValidRegexParam(TestContext context) {

    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[1];
      hitAry[0] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
	WebClient client = WebClient.create(vertx);
	Async async = context.async();
	client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
			"/es_search?indexName=hdcustomerdetail&indexType=customer&start=0&limit=20&sort=country.asc&regexSearch=id:###")
			.send().onSuccess(successHandler -> {
				context.assertEquals(400, successHandler.statusCode());
				client.close();
				async.complete();
			}).onFailure(failureHandler -> {
				failureHandler.printStackTrace();
				client.close();
				async.complete();
			});

  }

  @Test
  public void testWithAsterixRegexParam(TestContext context) {

    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[1];
      hitAry[0] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
	WebClient client = WebClient.create(vertx);
	Async async = context.async();
	client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
			"/es_search?indexName=hdcustomerdetail&indexType=customer&start=0&limit=20&sort=country.asc&regexSearch=id:*")
			.send().onSuccess(successHandler -> {
				context.assertEquals(200, successHandler.statusCode());
				client.close();
				async.complete();
			}).onFailure(failureHandler -> {
				failureHandler.printStackTrace();
				client.close();
				async.complete();
			});

  }

  @Test
  public void testWithNullRegexParam(TestContext context) {

    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[1];
      hitAry[0] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
	WebClient client = WebClient.create(vertx);
	Async async = context.async();
	client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
			"/es_search?indexName=hdcustomerdetail&indexType=customer&start=0&limit=20&sort=country.asc&regexSearch=")
			.send().onSuccess(successHandler -> {
				context.assertEquals(400, successHandler.statusCode());
				client.close();
				async.complete();
			}).onFailure(failureHandler -> {
				failureHandler.printStackTrace();
				client.close();
				async.complete();
			});

  }

  @Test
  public void testWithInvalidRegexParam(TestContext context) {

    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[1];
      hitAry[0] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
    WebClient client = WebClient.create(vertx);
    Async async = context.async();
    client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
            "/es_search?indexName=hdcustomerdetail&indexType=customer&start=0&limit=20&sort=country.asc&regexSearch=id")
    		.send().onSuccess(successHandler -> {
              context.assertEquals(400, successHandler.statusCode());
              client.close();
              async.complete();
			}).onFailure(failureHandler -> {
				failureHandler.printStackTrace();
				client.close();
				async.complete();
			});
  }

  @Test
  public void testWithOneInvalidRegexParam(TestContext context) {

    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[1];
      hitAry[0] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
	WebClient client = WebClient.create(vertx);
	Async async = context.async();
	client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
			"/es_search?indexName=hdcustomerdetail&indexType=customer&start=0&limit=20&sort=country.asc&regexSearch=id:123,internalTicketId")
			.send().onSuccess(successHandler -> {
				context.assertEquals(400, successHandler.statusCode());
				client.close();
				async.complete();
			}).onFailure(failureHandler -> {
				failureHandler.printStackTrace();
				client.close();
				async.complete();
			});

  }

  @Test
  public void testWithvalidRegexParamWithSplChrAsSearch(TestContext context) {

    try {
      CustomSearchHit[] hitAry = new CustomSearchHit[1];
      hitAry[0] = new CustomSearchHit("{\"id\":\"P000000614\",\"lastModifyDate\":\"Wed Jun 20 15:18:36 GMT 2018\",\"mss_sort_statusVal\":0,\"statusVal\":\"Active\",\"category\":\"Test\",\"industry\":\"Food & Beverage Services\",\"mss_sort_suspended\":0,\"suspended\":\"No\",\"mss_sort_csmReport\":1,\"csmReport\":\"Yes\",\"pdrCount\":\"856\",\"name\":\"QA Customer\",\"partnerId\":\"P000000613\",\"partnerName\":\"QA Partner\",\"mss_sort_theatreVal\":0,\"theatreVal\":\"Americas\",\"subTheatreAmericas\":\"Latin America\",\"remedyAppsTime\":\"1529507917979\"}");
      CustomSearchHits hitsImpl = new CustomSearchHits(hitAry);
      when(searchUtil.find(any(), any(), any(), anyMap(), any(), anyInt(), anyInt(), anyObject(), anyMap(), anyMap(), anyMap(), anyList(), anyList(),anyMap()))
              .thenReturn(hitsImpl);
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    // Send a request and get a response
	WebClient client = WebClient.create(vertx);
	Async async = context.async();
	client.get(ApplicationConfiguration.getInstance().getServerPort(), "localhost",
			"/es_search?indexName=hdcustomerdetail&indexType=customer&start=0&limit=20&sort=country.asc&regexSearch=id:.*%22SOC::,070:,,27090%22.*")
			.send().onSuccess(successHandler -> {
				context.assertEquals(200, successHandler.statusCode());
				client.close();
				async.complete();
			}).onFailure(failureHandler -> {
				failureHandler.printStackTrace();
				client.close();
				async.complete();
			});

  }

}