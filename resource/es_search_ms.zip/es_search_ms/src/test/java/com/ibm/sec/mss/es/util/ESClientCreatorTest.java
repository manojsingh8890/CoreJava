package com.ibm.sec.mss.es.util;

import com.ibm.sec.mss.es.ESClientCreator;
import org.elasticsearch.client.Client;
import org.junit.Assert;
import org.junit.Test;

public class ESClientCreatorTest {
    @Test
    public void getTransportConnection() {
        ESClientCreator creator = new ESClientCreator();
        Client transportConnection = creator.getTransportConnection();
        //because of defaults we should get a client back.
        Assert.assertNotNull(transportConnection);
    }

}