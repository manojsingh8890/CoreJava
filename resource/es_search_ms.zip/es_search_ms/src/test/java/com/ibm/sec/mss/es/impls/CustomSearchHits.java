package com.ibm.sec.mss.es.impls;

import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.search.SearchHit;

import java.util.Arrays;
import java.util.Iterator;

public class CustomSearchHits implements org.elasticsearch.search.SearchHits {

    SearchHit[] hits;

    public CustomSearchHits(SearchHit[] ary) {
        hits = ary;
    }

    @Override
    public long totalHits() {
        return 0;
    }

    @Override
    public long getTotalHits() {
        return this.hits.length;
    }

    @Override
    public float maxScore() {
        return 0;
    }

    @Override
    public float getMaxScore() {
        return 0;
    }

    @Override
    public SearchHit[] hits() {
        return new SearchHit[0];
    }

    @Override
    public SearchHit getAt(int position) {
        return null;
    }

    @Override
    public SearchHit[] getHits() {
        return hits;
    }

    @Override
    public Iterator<SearchHit> iterator() {
        return null;
    }

    @Override
    public void readFrom(StreamInput in) {

    }

    @Override
    public void writeTo(StreamOutput out) {

    }

    @Override
    public XContentBuilder toXContent(XContentBuilder builder, Params params) {
        return null;
    }

    @Override
    public String toString() {
        return "SearchHitsImpl{" +
                "hits=" + Arrays.toString(hits) +
                '}';
    }
}
