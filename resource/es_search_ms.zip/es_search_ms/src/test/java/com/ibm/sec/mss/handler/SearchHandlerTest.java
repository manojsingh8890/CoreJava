package com.ibm.sec.mss.handler;

import com.ibm.sec.mss.es.SearchUtil;
import io.vertx.core.MultiMap;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.json.JsonArray;
import com.ibm.sec.mss.model.CustomResponse;
import io.vertx.core.json.JsonObject;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.junit.Test;
import org.testng.Assert;

import static org.mockito.Matchers.*;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
public class SearchHandlerTest {

    String s = "{\"id\": \"SOCY00702056623\",\"customerId\": \"P000000614\",\"severityVal\": \"SEV1\",\"nature\": \"Service Incident\",\"issueDescription\": \"Ticket created by automated tests\",\"partnerId\": \"P000000613\",\"securityAnalyst\": \"wobc\",\"ticketGuid\": \"IDGAA5V0FCRFIAQVK2XNQULL1SVZY4\",\"devices\":[{\"deviceId\": \"STG000008073943\", \"id\": \"DEV000006671600\"}]}";

    private JsonArray jsonArray=new JsonArray();
    private JsonObject jsonObject=new JsonObject();

    @Test
    public void testSearchForDataWParams() throws Exception {

        MultiMap params = MultiMap.caseInsensitiveMultiMap();
        params.add("indexName","abcd");
        params.add("indexType","efgh");
        params.add("userId","def");
        params.add("include","customerId[XYZ]");
        SearchUtil searchUtil = mock(SearchUtil.class);
        SearchHits searchHits = mock(org.elasticsearch.search.SearchHits.class);
        HttpServerRequest request = mock(HttpServerRequest.class);

        when(searchUtil.find(anyString(),anyString(),anyString(),any(),anyString(),anyInt(),anyInt(),any(),any(),any(),any(),any(),any(),any())).thenReturn(searchHits);
        when(searchHits.hits()).thenReturn(new SearchHit[0]);
        when(searchHits.getTotalHits()).thenReturn(2L);
        when(searchHits.getHits()).thenReturn(new SearchHit[0]);
        SearchHandler searchHandler = new SearchHandler();
        searchHandler.setSearchUtil(searchUtil);

        CustomResponse customResponse = searchHandler.customsearchForDataWParams("123",params,request);
        Assert.assertEquals(2L,customResponse.getTotalCount());
    }

    @Test
    public void testSearchForDataWParamsWithValidRegex() throws Exception {

        MultiMap params = MultiMap.caseInsensitiveMultiMap();
        params.add("indexName","abcd");
        params.add("indexType","efgh");
        params.add("userId","def");
        params.add("include","customerId[XYZ]");
        params.add("regexSearch","internalTicketId:\\-ID\\-12345678");
        SearchUtil searchUtil = mock(SearchUtil.class);
        SearchHits searchHits = mock(org.elasticsearch.search.SearchHits.class);
        HttpServerRequest request = mock(HttpServerRequest.class);

        when(searchUtil.find(anyString(),anyString(),anyString(),any(),anyString(),anyInt(),anyInt(),any(),any(),any(),any(),any(),any(),any())).thenReturn(searchHits);
        when(searchHits.hits()).thenReturn(new SearchHit[0]);
        when(searchHits.getTotalHits()).thenReturn(2L);
        when(searchHits.getHits()).thenReturn(new SearchHit[0]);
        SearchHandler searchHandler = new SearchHandler();
        searchHandler.setSearchUtil(searchUtil);

        CustomResponse customResponse = searchHandler.customsearchForDataWParams("123",params,request);
        Assert.assertEquals(2L,customResponse.getTotalCount());
    }

    @Test
    public void testSearchForDataWParamsWithInValidRegex() throws Exception {

        MultiMap params = MultiMap.caseInsensitiveMultiMap();
        params.add("indexName","abcd");
        params.add("indexType","efgh");
        params.add("userId","def");
        params.add("include","customerId[XYZ]");
        params.add("regexSearch","!@#$:\\-ID\\-$#@!");
        SearchUtil searchUtil = mock(SearchUtil.class);
        SearchHits searchHits = mock(org.elasticsearch.search.SearchHits.class);
        HttpServerRequest request = mock(HttpServerRequest.class);

        when(searchUtil.find(anyString(),anyString(),anyString(),any(),anyString(),anyInt(),anyInt(),any(),any(),any(),any(),any(),any(),any())).thenReturn(searchHits);
        when(searchHits.hits()).thenReturn(new SearchHit[0]);
        when(searchHits.getTotalHits()).thenReturn(2L);
        when(searchHits.getHits()).thenReturn(new SearchHit[0]);
        SearchHandler searchHandler = new SearchHandler();
        searchHandler.setSearchUtil(searchUtil);

        CustomResponse customResponse = searchHandler.customsearchForDataWParams("123",params,request);
        Assert.assertEquals(2L,customResponse.getTotalCount());
    }

    @Test
    public void testSearchForDataWParamsWithInCompleteRegex() throws Exception {

        MultiMap params = MultiMap.caseInsensitiveMultiMap();
        params.add("indexName","abcd");
        params.add("indexType","efgh");
        params.add("userId","def");
        params.add("include","customerId[XYZ]");
        params.add("regexSearch","id:1234,internalTicketId:");
        SearchUtil searchUtil = mock(SearchUtil.class);
        SearchHits searchHits = mock(org.elasticsearch.search.SearchHits.class);
        HttpServerRequest request = mock(HttpServerRequest.class);

        when(searchUtil.find(anyString(),anyString(),anyString(),any(),anyString(),anyInt(),anyInt(),any(),any(),any(),any(),any(),any(),any())).thenReturn(searchHits);
        when(searchHits.hits()).thenReturn(new SearchHit[0]);
        when(searchHits.getTotalHits()).thenReturn(2L);
        when(searchHits.getHits()).thenReturn(new SearchHit[0]);
        SearchHandler searchHandler = new SearchHandler();
        searchHandler.setSearchUtil(searchUtil);

        CustomResponse customResponse = searchHandler.customsearchForDataWParams("123",params,request);
        Assert.assertEquals(2L,customResponse.getTotalCount());
    }

    @Test
    public void testSearchForDataWParamsWithEmptyRegex() throws Exception {

        MultiMap params = MultiMap.caseInsensitiveMultiMap();
        params.add("indexName","abcd");
        params.add("indexType","efgh");
        params.add("userId","def");
        params.add("include","customerId[XYZ]");
        params.add("regexSearch","");
        SearchUtil searchUtil = mock(SearchUtil.class);
        SearchHits searchHits = mock(org.elasticsearch.search.SearchHits.class);
        HttpServerRequest request = mock(HttpServerRequest.class);

        when(searchUtil.find(anyString(),anyString(),anyString(),any(),anyString(),anyInt(),anyInt(),any(),any(),any(),any(),any(),any(),any())).thenReturn(searchHits);
        when(searchHits.hits()).thenReturn(new SearchHit[0]);
        when(searchHits.getTotalHits()).thenReturn(2L);
        when(searchHits.getHits()).thenReturn(new SearchHit[0]);
        SearchHandler searchHandler = new SearchHandler();
        searchHandler.setSearchUtil(searchUtil);

        CustomResponse customResponse = searchHandler.customsearchForDataWParams("123",params,request);
        Assert.assertEquals(2L,customResponse.getTotalCount());
    }

    @Test
    public void testSearchForDataWParamsWithNullStringRegex() throws Exception {

        MultiMap params = MultiMap.caseInsensitiveMultiMap();
        params.add("indexName","abcd");
        params.add("indexType","efgh");
        params.add("userId","def");
        params.add("include","customerId[XYZ]");
        params.add("regexSearch","null");
        SearchUtil searchUtil = mock(SearchUtil.class);
        SearchHits searchHits = mock(org.elasticsearch.search.SearchHits.class);
        HttpServerRequest request = mock(HttpServerRequest.class);

        when(searchUtil.find(anyString(),anyString(),anyString(),any(),anyString(),anyInt(),anyInt(),any(),any(),any(),any(),any(),any(),any())).thenReturn(searchHits);
        when(searchHits.hits()).thenReturn(new SearchHit[0]);
        when(searchHits.getTotalHits()).thenReturn(2L);
        when(searchHits.getHits()).thenReturn(new SearchHit[0]);
        SearchHandler searchHandler = new SearchHandler();
        searchHandler.setSearchUtil(searchUtil);

        CustomResponse customResponse = searchHandler.customsearchForDataWParams("123",params,request);
        Assert.assertEquals(2L,customResponse.getTotalCount());
    }
}















