package com.ibm.sec.repository;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.ibm.sec.model.FirewallChangeEntity;
import com.ibm.sec.model.FirewallChangeSessionErrorsEntity;
import com.ibm.sec.util.IConstant;

@DataJpaTest
public class FirewallChangeSessionErrorsRepositoryTest {
	
	@Autowired
	FirewallChangeSessionErrorsRepository firewallChangeSessionErrorsRepository;
	
	FirewallChangeSessionErrorsEntity firewallChangeSessionErrorsEntity;

	@Test
	public void findByChangeId() {
		firewallChangeSessionErrorsEntity = new FirewallChangeSessionErrorsEntity();
		firewallChangeSessionErrorsEntity.setId(1);
		firewallChangeSessionErrorsEntity.setError("Error");
		firewallChangeSessionErrorsEntity.setFunctionality(IConstant.Functionality.RISK_INFO_FETCH);
		firewallChangeSessionErrorsEntity.setSessionId("sessionId001");
		firewallChangeSessionErrorsRepository.save(firewallChangeSessionErrorsEntity);
		List<FirewallChangeSessionErrorsEntity>  firewallChange = firewallChangeSessionErrorsRepository.findBySessionIdAndFunctionality("sessionId001", IConstant.Functionality.RISK_INFO_FETCH);
		Assert.assertEquals("sessionId001", firewallChange.get(0).getSessionId());
	}

}
