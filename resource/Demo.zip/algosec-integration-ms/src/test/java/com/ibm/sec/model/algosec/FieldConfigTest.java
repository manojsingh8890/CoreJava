package com.ibm.sec.model.algosec;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

public class FieldConfigTest {
	

	@Test
	public void testStatusField() {
		FieldConfig fc = new FieldConfig();
		fc.setField("Automation_status");
		fc.setValue("reject");
		Assert.assertEquals("Automation_status", fc.getField());
		Assert.assertEquals("reject", fc.getValue());
	} 

}
