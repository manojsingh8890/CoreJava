package com.ibm.sec.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class JsonUtilTest {

    @Autowired
    private JsonUtil jsonUtil;

    private static final ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testParse() throws JsonProcessingException {
        String data = "[{\"a\": \"b\"}, {\"a\": \"c\"}]";
        ArrayNode arrayNode = mapper.createArrayNode();
        ObjectNode objectNode1 = mapper.createObjectNode();
        objectNode1.put("a", "b");
        ObjectNode objectNode2 = mapper.createObjectNode();
        objectNode2.put("a", "c");
        arrayNode.add(objectNode1).add(objectNode2);
        JsonNode actualResult = jsonUtil.parse(data);
        assertEquals(arrayNode, actualResult);
    }

    @Test
    public void testToStringJsonNode() throws JsonProcessingException {
        String expectedResult = "[{\"a\":\"b\"},{\"a\":\"c\"}]";
        ArrayNode rootNode = mapper.createArrayNode();
        ObjectNode node1 = mapper.createObjectNode();
        ObjectNode node2 = mapper.createObjectNode();
        node1.put("a", "b");
        node2.put("a", "c");
        rootNode.add(node1).add(node2);
        String actualResult = jsonUtil.toString(rootNode);
        assertEquals(expectedResult, actualResult);
    }

    @Test
    public void testToStringObject() throws JsonProcessingException {
        String expectedResult = "{\"a\":\"b\",\"c\":\"d\"}";
        class TestClass {
            private String a;
            private String c;

            public TestClass(String a, String c) {
                this.a = a;
                this.c = c;
            }

            public String getA() {
                return a;
            }

            public void setA(String a) {
                this.a = a;
            }

            public String getC() {
                return c;
            }

            public void setC(String c) {
                this.c = c;
            }
        }
        TestClass testClass = new TestClass("b", "d");
        String actualResult = jsonUtil.toString(testClass);
        assertEquals(expectedResult, actualResult);
    }

    @Test
    public void testGetFieldValuesAsText() {
        String data = "[{\"a\":\"b\"},{\"a\":\"c\"}]";
        List<String> values = jsonUtil.getFieldValuesAsText(data, "$.[*].a");
        assertTrue(values.contains("b"));
        assertTrue(values.contains("c"));
    }

    @Test
    public void testGetFieldValueAsText() {
        String data = "{\"a\":\"b\"}";
        String value = jsonUtil.getFieldValueAsText(data, "$.a");
        assertEquals("b", value);
    }

    @Test
    public void testGetFieldValueAsInt() {
        String data = "{\"a\":4}";
        int value = jsonUtil.getFieldValueAsInt(data, "$.a");
        assertEquals(4, value);
    }


    @Test
    public void testNewNode() {
        ObjectNode newNode = jsonUtil.newNode();
        assertNotNull(newNode);
    }

    @Test
    public void testGetFieldValueAsMaps(){
        String data = "[{\"a\":\"b\"},{\"a\":\"c\"}]";
        List<Map> values = jsonUtil.getFieldValuesAsMaps(data, "$.[*].a");
        assertTrue(values.contains("b"));
        assertTrue(values.contains("c"));
    }

    @Test
    public void testNewArrayNode() {
        ArrayNode newArrayNode = jsonUtil.newArrayNode();
        assertNotNull(newArrayNode);
    }

    @Test
    public void testGetValues() {
        ArrayList<String> expectedResult = new ArrayList<String>(Arrays.asList("a","b"));
        ArrayNode rootNode = mapper.createArrayNode();
        rootNode.add("a");
        rootNode.add("b");
        List<String> actualResult = jsonUtil.getValues(rootNode);
        assertTrue(actualResult.size()==2);
        assertNotNull(actualResult);
        assertEquals(expectedResult,actualResult);
    }
}


