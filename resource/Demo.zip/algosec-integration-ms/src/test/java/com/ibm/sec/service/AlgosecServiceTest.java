package com.ibm.sec.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.sec.model.Claims;
import com.ibm.sec.model.algosec.ObjectChangeRequest;
import com.ibm.sec.model.algosec.RuleRemovalChangeRequest;
import com.ibm.sec.model.algosec.TrafficChangeRequest;
import com.ibm.sec.util.JsonUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.ClientResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ibm.sec.TestData;
import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.error.ErrorConfig;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.model.algosec.FireFlowAPIAuthResponse;
import com.ibm.sec.util.IConstant;
import com.ibm.sec.util.RestUtil;

import reactor.core.publisher.Mono;

@SpringBootTest
public class AlgosecServiceTest {

    @Autowired
    private AlgosecService service;
    @MockBean
    private RestUtil restUtil;
    @Autowired
    private JsonUtil jsonUtil;

    private UserSession session;
    @Autowired
    private ErrorConfig errorConfig;

    @BeforeEach
    public void createUserSession() {
        session = new UserSession();
        session.setSessionId("abc");
        session.setAuthHeaderValue("def");
        session.setAlgoSecFaSessionId("ghi");
        session.setAlgoSecSessionId("jkl");
        session.setAlgoSecPhpSessionId("mno");
        session.setThreadUuid("pqr");
        Claims claims = new Claims();
        claims.setCustomerId("123");
        claims.setUserName("stu");
        session.setClaims(claims);
    }

    @Test
    public void testGetRiskReport() {
        Map<String, String> resultMap = new HashMap<String, String>();
        resultMap.put(null, TestData.getRiskReportData());
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200); //return  200 status
        when(mockResponseEntity.getBody()).thenReturn(TestData.getRiskReportData());
        Mono<ClientResponse> monoMockClientResponse = Mono.just(mockClientResponse);
        when(restUtil.makeGetCallToAlgosecAPIs(any(), any(), any(Class.class), any(Map.class), any())).thenReturn(Mono.just(TestData.getRiskReportData()));
        List<String> list = new ArrayList<>();
        list.add(null);
        assertEquals(resultMap, service.getRiskReport(list, new UserSession()));
    }

    @Test
    public void testAuthenticateSucces() {
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200);
        when(mockResponseEntity.getBody()).thenReturn("{\n" +
                "    \"status\": \"Success\",\n" +
                "    \"messages\": [],\n" +
                "    \"data\": {\n" +
                "        \"sessionId\": \"7e6cb8e6152b705e28dd37dfec929eff\",\n" +
                "        \"faSessionId\": \"5nduv0hhk23pkvi21j8e358fv7\",\n" +
                "        \"phpSessionId\": \"5nduv0hhk23pkvi21j8e358fv7\"\n" +
                "    }\n" +
                "}");
        Mono<ClientResponse> monoMockClientResponse = Mono.just(mockClientResponse);
        when(restUtil.makePostCallToAlgosecAPIs(any(), any(), eq(null), any())).thenReturn(monoMockClientResponse);
        FireFlowAPIAuthResponse authResponse = service.authenticate(new UserSession());
        assertEquals("7e6cb8e6152b705e28dd37dfec929eff", authResponse.getSessionId());
        assertEquals("5nduv0hhk23pkvi21j8e358fv7", authResponse.getFaSessionId());
        assertEquals("5nduv0hhk23pkvi21j8e358fv7", authResponse.getPhpSessionId());
    }

    @Test
    public void testAuthenticateFailure() {
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(401); //return non 200 status
        when(mockResponseEntity.getBody()).thenReturn(""); //response doesn't matter as per logic
        Mono<ClientResponse> monoMockClientResponse = Mono.just(mockClientResponse);
        when(restUtil.makePostCallToAlgosecAPIs(any(), any(), eq(null), any())).thenReturn(monoMockClientResponse);
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {
            service.authenticate(new UserSession());
        });
        assertEquals(errorConfig.getHttpStatus().getInternalError(), thrown.getHttpStatus());
        assertEquals(errorConfig.getCode().getInternalError(), thrown.getCode());
        assertEquals(errorConfig.getMessage().getInternalError(), thrown.getMessage());
    }

    @Test
    public void testGetNetworkObjectIPAddresesByDeviceNames() {
        when(restUtil.makeGetCallToAlgosecAPIs(any(), any(), any(Class.class), any(Map.class), any())).thenReturn(Mono.just("{\n" +
                "  \"content\": [\n" +
                "    {\n" +
                "      \"id\": 784,\n" +
                "      \"objectContainer\": {\n" +
                "        \"id\": 253,\n" +
                "        \"name\": \"10_239_15_75\",\n" +
                "        \"brand\": {\n" +
                "          \"id\": 50,\n" +
                "          \"name\": \"PIX\"\n" +
                "        }\n" +
                "      },\n" +
                "      \"originalName\": \"management-network/25\",\n" +
                "      \"canonizedName\": \"management-network_25\",\n" +
                "      \"ipaddress\": \"10.239.15.0-10.239.15.127\",\n" +
                "      \"zone\": \"\",\n" +
                "      \"ipCount\": 128,\n" +
                "      \"ipType\": \"IPv4\",\n" +
                "      \"objectInternalType\": {\n" +
                "        \"id\": 3,\n" +
                "        \"name\": \"Cisco_Interface\"\n" +
                "      },\n" +
                "      \"natType\": \"NONE\",\n" +
                "      \"invalidNamedObject\": false\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": 785,\n" +
                "      \"objectContainer\": {\n" +
                "        \"id\": 253,\n" +
                "        \"name\": \"10_239_15_75\",\n" +
                "        \"brand\": {\n" +
                "          \"id\": 50,\n" +
                "          \"name\": \"PIX\"\n" +
                "        }\n" +
                "      },\n" +
                "      \"originalName\": \"inside-network/24\",\n" +
                "      \"canonizedName\": \"inside-network_24\",\n" +
                "      \"ipaddress\": \"10.10.101.0-10.10.101.255\",\n" +
                "      \"zone\": \"\",\n" +
                "      \"ipCount\": 256,\n" +
                "      \"ipType\": \"IPv4\",\n" +
                "      \"objectInternalType\": {\n" +
                "        \"id\": 3,\n" +
                "        \"name\": \"Cisco_Interface\"\n" +
                "      },\n" +
                "      \"natType\": \"NONE\",\n" +
                "      \"invalidNamedObject\": false\n" +
                "    }\n" +
                "  ]\n" +
                "}"));
        Map<String, Map<String, String>> algoSecDeviceNameObjectDetailsMap = service.getNetworkObjectIPAddresesByDeviceNames(Arrays.asList("10_239_15_75"), session);
        assertTrue(algoSecDeviceNameObjectDetailsMap.get("10_239_15_75").size() == 2);
        assertEquals("10.239.15.0-10.239.15.127", algoSecDeviceNameObjectDetailsMap.get("10_239_15_75").get("management-network_25"));
        assertEquals("10.10.101.0-10.10.101.255", algoSecDeviceNameObjectDetailsMap.get("10_239_15_75").get("inside-network_24"));
    }

    @Test
    public void testGetServiceObjectValuesByDeviceNames() throws JsonProcessingException {
        when(restUtil.makeGetCallToAlgosecAPIs(any(), any(), any(Class.class), any(Map.class), any())).thenReturn(Mono.just("{\n" +
                "    \"totalPages\": 15,\n" +
                "    \"totalElements\": 142,\n" +
                "    \"currPageNumber\": 0,\n" +
                "    \"currPageElements\": 10,\n" +
                "    \"entitiesReponses\": [\n" +
                "        {\n" +
                "            \"name\": \"PR0000000001937\",\n" +
                "            \"display_name\": \"10_239_15_75\",\n" +
                "            \"devices\": [\n" +
                "                \"PR0000000001937\"\n" +
                "            ],\n" +
                "            \"values\": [\n" +
                "                {\n" +
                "                    \"id\": 11472,\n" +
                "                    \"name\": \"eigrp\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"88/*/*\"\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"id\": 11473,\n" +
                "                    \"name\": \"ident\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"tcp/113/*\"\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"id\": 11474,\n" +
                "                    \"name\": \"domain\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"tcp/53/*\"\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"id\": 11475,\n" +
                "                    \"name\": \"mobile-ip\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"udp/434/*\"\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"id\": 11476,\n" +
                "                    \"name\": \"echo\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"udp/7/*\"\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"id\": 11477,\n" +
                "                    \"name\": \"ssh\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"tcp/22/*\"\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"id\": 11478,\n" +
                "                    \"name\": \"snmp\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"udp/161/*\"\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"id\": 11479,\n" +
                "                    \"name\": \"sip\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"tcp/5060/*\",\n" +
                "                        \"udp/5060/*\"\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"id\": 11480,\n" +
                "                    \"name\": \"sip\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"tcp/5060/*\"\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"id\": 11481,\n" +
                "                    \"name\": \"timestamp-request\",\n" +
                "                    \"serviceDefinitions\": [\n" +
                "                        \"icmp/14/*\"\n" +
                "                    ]\n" +
                "                }\n" +
                "            ]\n" +
                "        }\n" +
                "    ]\n" +
                "}"));
        Map<String, Map<String, List<String>>> algoSecDeviceNameServiceObjectDetailsMap = service.getServiceObjectValuesByDeviceEntityName(Arrays.asList("PR0000000001937"), session);
        assertTrue(algoSecDeviceNameServiceObjectDetailsMap.get("PR0000000001937").size() == 9);
        assertEquals("[88/*/*]", algoSecDeviceNameServiceObjectDetailsMap.get("PR0000000001937").get("eigrp").toString());
        assertEquals("[tcp/113/*]", algoSecDeviceNameServiceObjectDetailsMap.get("PR0000000001937").get("ident").toString());
    }

    @Test
    public void testUpdateChangeStatusSuccess() {
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        when(mockClientResponse.rawStatusCode()).thenReturn(200);
        when(restUtil.makePutCallToAlgosecAPIs(any(), any(), anyMap(), any())).thenReturn(Mono.just(mockClientResponse));
        Map<String, List<String>> responseData = service.updateChangeStatus(Arrays.asList("1", "2"), session);
        assertTrue(responseData.get(IConstant.CHANGE_ID_STATUS_UPDATED).contains("1"));
        assertTrue(responseData.get(IConstant.CHANGE_ID_STATUS_UPDATED).contains("2"));
    }

    @Test
    public void testUpdateChangeStatusFailure() {
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(500); //non 200 status
        when(mockResponseEntity.getBody()).thenReturn(""); //response body doesn't matter in this case
        Mono<ClientResponse> monoMockClientResponse = Mono.just(mockClientResponse);
        when(restUtil.makePutCallToAlgosecAPIs(any(), any(), anyMap(), any())).thenReturn(monoMockClientResponse);
        Map<String, List<String>> responseData = service.updateChangeStatus(Arrays.asList("1", "2"), session);
        assertTrue(responseData.get(IConstant.CHANGE_ID_STATUS_NOT_UPDATED).contains("1"));
        assertTrue(responseData.get(IConstant.CHANGE_ID_STATUS_NOT_UPDATED).contains("2"));
    }

    @Test
    public void testIsChangeNeededInfo() {
        List<String> testDataList = new ArrayList<>();
        testDataList.add(TestData.getChangeNeededData());
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200); //return  200 status
        when(mockResponseEntity.getBody()).thenReturn(TestData.getChangeNeededData());
        Mono<ClientResponse> monoMockClientResponse = Mono.just(mockClientResponse);
        when(restUtil.makePostCallToAlgosecAPIs(any(), any(), anyMap(), any())).thenReturn(monoMockClientResponse);
        List<String> list = new ArrayList<>();
        list.add(null);

        assertEquals(testDataList, service.getChangeNeededInfo(list, session));

    }

    @Test
    public void testIsChangeNeededInfoFailure() {
        List<String> list = new ArrayList<>();
        list.add(null);
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(500); //non 200 status
        when(mockResponseEntity.getBody()).thenReturn("");  // returning empty in case of 500 error code
        Mono<ClientResponse> monoMockClientResponse = Mono.just(mockClientResponse);
        when(restUtil.makePostCallToAlgosecAPIs(any(), any(), anyMap(), any())).thenReturn(monoMockClientResponse);
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {
            service.getChangeNeededInfo(list, session);
        });
        assertEquals(errorConfig.getHttpStatus().getInternalError(), thrown.getHttpStatus());
        assertEquals(errorConfig.getCode().getInternalError(), thrown.getCode());
        assertEquals(errorConfig.getMessage().getInternalError(), thrown.getMessage());
    }

    @Test
    public void getTicketDetailsInfoTest() {
        when(restUtil.makeGetCallToAlgosecAPIs(any(), anyString(), any(), any())).thenReturn(Mono.just(TestData.getTicketDetailsData()));
        List<String> list = Arrays.asList("001");
        assertEquals(TestData.getTicketDetailsData(), service.getAlgosecChangeInfo(list, session).get("001"));
    }

    @Test
    public void testGetRuleInformation() throws JsonProcessingException {
        when(restUtil.makeGetCallToAlgosecAPIs(any(), any(), any(Class.class), any(Map.class), any())).thenReturn(Mono.just("[\n" +
                "    {\n" +
                "        \"deviceId\": 253,\n" +
                "        \"deviceDisplayName\": \"PR0000000001937\",\n" +
                "        \"ruleId\": \"0x6ed41760\",\n" +
                "        \"ruleNum\": \"191\",\n" +
                "        \"source\": [\n" +
                "            {\n" +
                "                \"id\": 787,\n" +
                "                \"objectContainer\": {\n" +
                "                    \"id\": 253,\n" +
                "                    \"name\": \"10_239_15_75\",\n" +
                "                    \"brand\": {\n" +
                "                        \"id\": 50,\n" +
                "                        \"name\": \"PIX\"\n" +
                "                    }\n" +
                "                },\n" +
                "                \"originalName\": \"any\",\n" +
                "                \"canonizedName\": \"any\",\n" +
                "                \"ipaddress\": \"0.0.0.0-255.255.255.255\",\n" +
                "                \"zone\": \"\",\n" +
                "                \"ipCount\": 4294967296,\n" +
                "                \"ipType\": \"IPv4\",\n" +
                "                \"objectInternalType\": {\n" +
                "                    \"id\": 0,\n" +
                "                    \"name\": \"Device\"\n" +
                "                },\n" +
                "                \"natType\": \"NONE\",\n" +
                "                \"invalidNamedObject\": false\n" +
                "            }\n" +
                "        ],\n" +
                "        \"isNegateSource\": false,\n" +
                "        \"users\": [\n" +
                "            {\n" +
                "                \"display\": \"any\"\n" +
                "            }\n" +
                "        ],\n" +
                "        \"destination\": [\n" +
                "            {\n" +
                "                \"id\": 787,\n" +
                "                \"objectContainer\": {\n" +
                "                    \"id\": 253,\n" +
                "                    \"name\": \"10_239_15_75\",\n" +
                "                    \"brand\": {\n" +
                "                        \"id\": 50,\n" +
                "                        \"name\": \"PIX\"\n" +
                "                    }\n" +
                "                },\n" +
                "                \"originalName\": \"any\",\n" +
                "                \"canonizedName\": \"any\",\n" +
                "                \"ipaddress\": \"0.0.0.0-255.255.255.255\",\n" +
                "                \"zone\": \"\",\n" +
                "                \"ipCount\": 4294967296,\n" +
                "                \"ipType\": \"IPv4\",\n" +
                "                \"objectInternalType\": {\n" +
                "                    \"id\": 0,\n" +
                "                    \"name\": \"Device\"\n" +
                "                },\n" +
                "                \"natType\": \"NONE\",\n" +
                "                \"invalidNamedObject\": false\n" +
                "            }\n" +
                "        ],\n" +
                "        \"urlCategories\": [\n" +
                "            {\n" +
                "                \"canonizedName\": \"\",\n" +
                "                \"invalidNamedObject\": true\n" +
                "            }\n" +
                "        ],\n" +
                "        \"isNegateDestination\": false,\n" +
                "        \"service\": [\n" +
                "            {\n" +
                "                \"id\": 13413,\n" +
                "                \"objectContainer\": {\n" +
                "                    \"id\": 253,\n" +
                "                    \"name\": \"10_239_15_75\",\n" +
                "                    \"brand\": {\n" +
                "                        \"id\": 50,\n" +
                "                        \"name\": \"PIX\"\n" +
                "                    }\n" +
                "                },\n" +
                "                \"canonizedName\": \"icmp/*/*\",\n" +
                "                \"servicedefinition\": \"icmp/*/*\",\n" +
                "                \"objectInternalType\": {\n" +
                "                    \"id\": 1,\n" +
                "                    \"name\": \"Cisco_Inline\"\n" +
                "                },\n" +
                "                \"invalidNamedObject\": false\n" +
                "            }\n" +
                "        ],\n" +
                "        \"isNegateService\": false,\n" +
                "        \"action\": \"permit\",\n" +
                "        \"comment\": [\n" +
                "            \"\"\n" +
                "        ],\n" +
                "        \"enable\": \"enabled\",\n" +
                "        \"log\": \"\",\n" +
                "        \"link\": \"line_191\",\n" +
                "        \"documentation\": {\n" +
                "            \"documentation\": \"\"\n" +
                "        },\n" +
                "        \"additionalData\": {\n" +
                "            \"line\": [\n" +
                "                {\n" +
                "                    \"value\": \"access-list Inbound extended permit icmp any any\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"rule\": [\n" +
                "                {\n" +
                "                    \"value\": \"acl(191)\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"acl\": [\n" +
                "                {\n" +
                "                    \"value\": \"Inbound\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"interface\": [\n" +
                "                {\n" +
                "                    \"value\": \"inside\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"name\": [\n" +
                "                {\n" +
                "                    \"value\": \"Inbound(1)\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"linenum\": [\n" +
                "                {\n" +
                "                    \"value\": \"191\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"time\": [\n" +
                "                {\n" +
                "                    \"value\": \"\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"user\": [\n" +
                "                {\n" +
                "                    \"value\": \"any\"\n" +
                "                }\n" +
                "            ]\n" +
                "        },\n" +
                "        \"isValidUserSourceModel\": true\n" +
                "    }]"));
        Object[] ruleInformation = service.getRuleInformation(Arrays.asList("PR0000000001937"), session);
        assertTrue(ruleInformation.length > 0);
        JsonNode ruleInfo = new ObjectMapper().readTree(ruleInformation[0].toString());
        assertEquals("\"191\"", ruleInfo.get(0).get("ruleNum").toString());
        assertEquals("\"0x6ed41760\"", ruleInfo.get(0).get("ruleId").toString());
    }

    @Test
    public void testRuleRemovalRequestSuccess() {
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200);
        when(mockResponseEntity.getBody()).thenReturn("{\n" +
                "    \"status\": \"Success\",\n" +
                "    \"messages\": [],\n" +
                "    \"data\": {\n" +
                "        \"changeRequestId\": 573,\n" +
                "        \"redirectUrl\": \"https://10.239.0.10/FireFlow/Ticket/Display.html?id=573\"\n" +
                "    }\n" +
                "}");
        Mono<ClientResponse> monoMockClientResponse = Mono.just(mockClientResponse);
        when(restUtil.makePostCallToAlgosecAPIs(any(), any(), anyMap(), any())).thenReturn(monoMockClientResponse);

        List<RuleRemovalChangeRequest> requests = new ArrayList<>();
        requests.add(new RuleRemovalChangeRequest());
        Object[] responses = service.createRuleRemovalRequest(requests, session);
        ClientResponse response = (ClientResponse) responses[0];
        ResponseEntity<String> responseEntity = response.toEntity(String.class).block();
        String responseBody = responseEntity.getBody();
        Integer changeId = jsonUtil.getFieldValueAsInt(responseBody, "$.data.changeRequestId");
        assertEquals(573, changeId);
    }

    @Test
    public void testCreateTrafficRequestSuccess() {
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200);
        when(mockResponseEntity.getBody()).thenReturn("{\n" +
                "    \"status\": \"Success\",\n" +
                "    \"messages\": [],\n" +
                "    \"data\": {\n" +
                "        \"changeRequestId\": 573,\n" +
                "        \"redirectUrl\": \"https://10.239.0.10/FireFlow/Ticket/Display.html?id=573\"\n" +
                "    }\n" +
                "}");
        Mono<ClientResponse> monoMockClientResponse = Mono.just(mockClientResponse);
        when(restUtil.makePostCallToAlgosecAPIs(any(), any(), anyMap(), any())).thenReturn(monoMockClientResponse);
        List<TrafficChangeRequest> requests = new ArrayList<>();
        requests.add(new TrafficChangeRequest());
        Object[] responses = service.createTrafficRequest(requests, session);
        ClientResponse response = (ClientResponse) responses[0];
        ResponseEntity<String> responseEntity = response.toEntity(String.class).block();
        String responseBody = responseEntity.getBody();
        Integer changeId = jsonUtil.getFieldValueAsInt(responseBody, "$.data.changeRequestId");
        assertEquals(573, changeId);

    }

    @Test
    public void testCreateObjectChangeRequest() {
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200);
        when(mockResponseEntity.getBody()).thenReturn("{\n" +
                "    \"status\": \"Success\",\n" +
                "    \"messages\": [],\n" +
                "    \"data\": {\n" +
                "        \"changeRequestId\": 573,\n" +
                "        \"redirectUrl\": \"https://10.239.0.10/FireFlow/Ticket/Display.html?id=573\"\n" +
                "    }\n" +
                "}");
        Mono<ClientResponse> monoMockClientResponse = Mono.just(mockClientResponse);
        when(restUtil.makePostCallToAlgosecAPIs(any(), any(), anyMap(), any())).thenReturn(monoMockClientResponse);
        List<ObjectChangeRequest> requests = new ArrayList<>();
        requests.add(new ObjectChangeRequest());
        Object[] responses = service.createObjectChangeRequest(requests, session);
        ClientResponse response = (ClientResponse) responses[0];
        ResponseEntity<String> responseEntity = response.toEntity(String.class).block();
        String responseBody = responseEntity.getBody();
        Integer changeId = jsonUtil.getFieldValueAsInt(responseBody, "$.data.changeRequestId");
        assertEquals(573, changeId);

    }
}
