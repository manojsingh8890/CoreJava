package com.ibm.sec.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

public class ReflectTool {

	public static <T extends Annotation> T getFieldAnnotation(Class<?> c, String fieldName, Class<T> annotation) {
		try {
			Field f = c.getDeclaredField(fieldName);
			return (T) f.getAnnotation(annotation);
		} catch (NoSuchFieldException nsme) {
			throw new RuntimeException(nsme);
		}
	}

	public static <T extends Annotation> T getClassAnnotation(Class<?> c, Class<T> annotation) {
		return (T) c.getAnnotation(annotation);
	}

}