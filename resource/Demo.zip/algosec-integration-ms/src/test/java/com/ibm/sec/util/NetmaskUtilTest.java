package com.ibm.sec.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.error.ErrorConfig;
import com.mysql.cj.protocol.Warning;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class NetmaskUtilTest {

    @Autowired
    private NetmaskUtil netMaskUtil;

    @Autowired
    private static final ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private ErrorConfig errorConfig;

    @Test
    public void testSantizeIPAddressReturnsIp(){
        String netmaskCandidate= "255.254.0.0";
        String netmaskip= netMaskUtil.santizeIPAddress(netmaskCandidate);
        assertEquals(netmaskCandidate,netmaskip);
    }

    @Test
    public void testSantizeIPAddressReturnsError(){
        String netmaskCandidate= "255.254.0.0 255.254.0.0 255.254.0.0";
        errorConfig.getHttpStatus().setBadRequest("400");
        errorConfig.getCode().setBadRequest("400");
        errorConfig.getMessage().setInvalidIpAddress("Invalid Address");
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {
            netMaskUtil.santizeIPAddress(netmaskCandidate);
        });
        assertEquals(errorConfig.getHttpStatus().getBadRequest(), thrown.getHttpStatus());
    assertEquals(errorConfig.getCode().getBadRequest(), thrown.getCode());
    assertEquals(errorConfig.getMessage().getInvalidIpAddress(), thrown.getMessage());

    }
    @Test
    public void testSantizeIPAddressInvalidLengthTwo(){
        String netmaskCandidate= "1.1.1.1 1.2.3.4";
        errorConfig.getHttpStatus().setBadRequest("400");
        errorConfig.getCode().setBadRequest("400");
        errorConfig.getMessage().setInvalidIpAddress("Invalid Address");
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {
            netMaskUtil.santizeIPAddress(netmaskCandidate);
        });
        assertEquals(errorConfig.getHttpStatus().getBadRequest(), thrown.getHttpStatus());
        assertEquals(errorConfig.getCode().getBadRequest(), thrown.getCode());
        assertEquals(errorConfig.getMessage().getInvalidIpAddress(), thrown.getMessage());

    }

    @Test
    public void testSantizeIPAddressReturnsMaskedIp(){
        String netmaskCandidate= "1.1.1.1 255.255.255.0";
        String netmaskip= netMaskUtil.santizeIPAddress(netmaskCandidate);
        assertEquals(netmaskip,"1.1.1.1/24");
    }



}
