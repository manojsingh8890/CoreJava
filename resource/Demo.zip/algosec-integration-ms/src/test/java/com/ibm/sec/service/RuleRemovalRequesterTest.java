package com.ibm.sec.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ibm.sec.TestData;
import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.error.ErrorConfig;
import com.ibm.sec.model.AlgosecChangeId;
import com.ibm.sec.model.Devices;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.model.algosec.RuleRemovalChangeRequest;
import com.ibm.sec.util.IConstant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SpringBootTest
public class RuleRemovalRequesterTest {

    // @MockBean
    @Autowired
    private RuleRemovalRequester requester;
    @MockBean
    private UserSession session;
    @MockBean
    private AlgosecService service;

    @Test
    public void testCreateChangeRequest() throws IOException {
        Devices devices = Mockito.mock(Devices.class);
        Map<String,String> remedyDeviceNameAlgosecNameMap = new HashMap<>();
        remedyDeviceNameAlgosecNameMap.put("atl_msslab_R8040_fw","atl_msslab_R8040_f");
        ObjectsData objectsData = new ObjectsData();
        String test = "[{ \"ruleId\" : \"CF9B1CA6-E509-4AF3-949F-927A342B2232\" , \"ruleNum\" : \"191\" }]";
        Object[] ruleInformation = new Object[1];
        ruleInformation[0] = test;
        Object[] ruleRemovalResponse = new Object[1];

        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200);
        when(mockResponseEntity.getBody()).thenReturn("{\n" +
                "    \"status\": \"Success\",\n" +
                "    \"messages\": [],\n" +
                "    \"data\": {\n" +
                "        \"changeRequestId\": 573,\n" +
                "        \"redirectUrl\": \"https://10.239.0.10/FireFlow/Ticket/Display.html?id=573\"\n" +
                "    }\n" +
                "}");
        ruleRemovalResponse[0] = mockClientResponse;
        JsonNode firewallChanges = new ObjectMapper().readTree(TestData.ruleRemovalInputJson());
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        when(service.getRuleInformation(any(List.class),eq(session))).thenReturn(ruleInformation);
        when(service.createRuleRemovalRequest(any(List.class),eq(session))).thenReturn(ruleRemovalResponse);
        List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY,objectsData, session);
        assertEquals(changeId.get(0).getChangeId(),"573");
        assertEquals(changeId.get(0).getChangeType().toString().trim(),"POLICY_DELETE");
    }


    @Test
    public void testCreateChangeRequestFail() throws IOException{
        Devices devices = Mockito.mock(Devices.class);
        Map<String,String> remedyDeviceNameAlgosecNameMap = new HashMap<>();
        remedyDeviceNameAlgosecNameMap.put("atl_msslab_R8040_fw","atl_msslab_R8040_f");
        ObjectsData objectsData = new ObjectsData();
        String test = "[{ \"ruleId\" : \"CF9B1CA6-E509-4AF3-949F-927A342B2232\" , \"ruleNum\" : \"191\" }]";
        Object[] ruleInformation = new Object[1];
        ruleInformation[0] = test;
        Object[] ruleRemovalResponse = new Object[1];

        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(500);
        ruleRemovalResponse[0] = mockClientResponse;
        JsonNode firewallChanges = new ObjectMapper().readTree(TestData.ruleRemovalInputJson());
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        when(service.getRuleInformation(any(List.class),eq(session))).thenReturn(ruleInformation);
        when(service.createRuleRemovalRequest(any(List.class),eq(session))).thenReturn(ruleRemovalResponse);
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {
            List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY, objectsData, session);
        });
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(),Integer.parseInt((thrown.getCode())));
    }
}