package com.ibm.sec.service;

import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.MINUTES;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.ibm.sec.TestData;
import com.ibm.sec.dao.FirewallChangeDAO;
import com.ibm.sec.model.FirewallChangeEntity;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.model.algosec.FireFlowAPIAuthResponse;
import com.ibm.sec.util.IConstant;
import com.ibm.sec.util.JsonUtil;

@SpringBootTest
public class RetryFetchRiskTest {

	@Autowired
    private ServiceFacade facade;
    @MockBean
    private AlgosecService algosecService;
	@MockBean
	private FirewallChangeDAO firewallChangeDAO;
	@MockBean
	private RuleRemovalRequester ruleRemovalRequester;
    @MockBean
    private TrafficChangeRequester trafficChangeRequester;
    @MockBean
    private DeviceService deviceService;
    @Autowired
    private JsonUtil jsonUtil;
    
    private static UserSession session;
	@BeforeAll
	public static void setup() throws IOException {
        session = new UserSession();
        session.setSessionId("some_random_session_id");
	}

	
	@Test
    public void testGetAndSaveRiskInfoSuccess() throws Exception {
        Map<String,String> serviceResponse = new HashMap<String, String>();
        Map<String,String> deviceResponse = new HashMap<String, String>();
        Map<String,String> changeDetails = new HashMap<String, String>();
        serviceResponse.put("001", TestData.getAlgosecApiResponseForRiskReport());
        changeDetails.put("001", TestData.getTicketDetailsData());
        deviceResponse.put("001", "host001");
        
        List<String> changeIds = new ArrayList<String>();
        changeIds.add("ch001");
        
        List<FirewallChangeEntity> FirewallChangeEntities = new ArrayList<FirewallChangeEntity>();
        FirewallChangeEntity changeEntity = new FirewallChangeEntity();
        changeEntity.setChangeId("ch001");
        Date timespamp = new Date();
        long waitTimeInMinutes = MILLISECONDS.convert(7, MINUTES);
        timespamp.setTime(timespamp.getTime() - waitTimeInMinutes);
        changeEntity.setTimeStamp(timespamp);
        FirewallChangeEntities.add(changeEntity); 
        
        when(firewallChangeDAO.areTemporaryChangeRequestsComplete(anyString())).thenReturn(true);
        when(firewallChangeDAO.getTemporaryChangeEntityForPolicyCreateChangesBySessionId(eq(session.getSessionId()))).thenReturn(FirewallChangeEntities);
        when(algosecService.getAlgosecChangeInfo(anyList(), any(UserSession.class))).thenReturn(changeDetails);
        when(deviceService.fetchDeviceInfo(anyMap(), any(UserSession.class))).thenReturn(deviceResponse);
        
        FireFlowAPIAuthResponse authResponse = new FireFlowAPIAuthResponse();
        authResponse.setPhpSessionId("phpsession");
        authResponse.setSessionId("session");
        authResponse.setFaSessionId("phf");
        when(algosecService.authenticate(session)).thenReturn(authResponse);
        ExecutorService service = Executors.newFixedThreadPool(10);
        service.execute(new RetryFetchRisk(service, session, firewallChangeDAO, facade));
        
        when(firewallChangeDAO.isRisksFetchComplete(anyString())).thenReturn(true);
        when(firewallChangeDAO.getErrorsBySessionIdAndFunctionality(eq(session.getSessionId()), eq(IConstant.Functionality.RISK_INFO_FETCH))).thenReturn(Collections.emptyList());
        String response = facade.getStatusOfFetchRiskInfo(session.getSessionId());
        assertEquals(IConstant.AlgosecTaskStatus.COMPLETE_WITH_SUCCESS.toString(), jsonUtil.parse(response).get("status").asText());
        assertEquals(session.getSessionId(), jsonUtil.parse(response).get("SESSION_ID").asText());
    }

}
