package com.ibm.sec.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.sec.TestData;
import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.error.ErrorConfig;
import com.ibm.sec.model.AlgosecChangeId;
import com.ibm.sec.model.Devices;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.util.IConstant;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SpringBootTest
public class TrafficChangeRequesterTest {

    @MockBean
    private AlgosecService service;
    @Autowired
    private TrafficChangeRequester requester;
    @MockBean
    private UserSession session;
    @Autowired
    private ErrorConfig errorConfig;
//    @Autowired
//    ObjectsResolver objectsResolver;
    private static ObjectsResolver objectsResolver;
    private static Devices devices;

    private static Map<String, Map<String, String>> deviceNameNetworkObjectDetailsMapAsInAlgosec = new HashMap<>();
    private static Map<String, Map<String, List<String>>> deviceNameServiceObjectDetailsMap = new HashMap<>();
    private static Map<String,String> remedyDeviceNameAlgosecNameMap = new HashMap<>();

    @BeforeAll
    public static void createUserSession() throws NoSuchFieldException, IllegalAccessException {
        devices = Mockito.mock(Devices.class);

        Map<String, String> networkObjectNameValueMap = new HashMap<>();
        networkObjectNameValueMap.put("networkObjectInAlgosec1", "5.5.5.5");
        networkObjectNameValueMap.put("networkObjectInAlgosec2", "6.6.6.6");
        networkObjectNameValueMap.put("networkObjectInAlgosec3", "5.5.5.5,networkObjectInAlgosec2");
        deviceNameNetworkObjectDetailsMapAsInAlgosec.put("atl_msslab_R8040_fw", networkObjectNameValueMap);

        Map<String, List<String>> serviceObjectNameValueMap = new HashMap<>();
        serviceObjectNameValueMap.put("serviceObjectInAlgosec1", Arrays.asList("tcp/443"));
        serviceObjectNameValueMap.put("serviceObjectInAlgosec2", Arrays.asList("udp/333"));
        serviceObjectNameValueMap.put("serviceObjectInAlgosec3", Arrays.asList("tcp/443","serviceObjectInAlgosec2"));
        deviceNameServiceObjectDetailsMap.put("atl_msslab_R8040_fw", serviceObjectNameValueMap);

        remedyDeviceNameAlgosecNameMap.put("atl_msslab_R8040_fw","atl_msslab_R8040_fw");

        objectsResolver = new ObjectsResolver();
        Field objectsUtilField = ObjectsResolver.class.getDeclaredField("objectsUtil");
        objectsUtilField.setAccessible(true);
        objectsUtilField.set(objectsResolver, new ObjectsUtil());
    }
    @Test
    public void testCreateChangeRequest() throws IOException,NoSuchFieldException,IllegalAccessException,SecurityException {
        Object[] trafficChangeResponse = new Object[1];
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200);
        when(mockResponseEntity.getBody()).thenReturn("{\n" +
                "    \"status\": \"Success\",\n" +
                "    \"messages\": [],\n" +
                "    \"data\": {\n" +
                "        \"changeRequestId\": 757,\n" +
                "        \"redirectUrl\": \"https://10.239.0.10/FireFlow/Ticket/Display.html?id=757\"\n" +
                "    }\n" +
                "}");
        trafficChangeResponse[0] = mockClientResponse;
        JsonNode firewallChanges = new ObjectMapper().readTree(Thread.currentThread().getContextClassLoader().getResource("test_input.json"));
        ObjectsData objectsData = objectsResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap, remedyDeviceNameAlgosecNameMap);
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        when(service.createTrafficRequest(any(List.class),eq(session))).thenReturn(trafficChangeResponse);
        List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY,objectsData, session);
        assertEquals(changeId.get(0).getChangeId(),"757");
        assertEquals(changeId.get(0).getChangeType().toString().trim(),"POLICY_CREATE");
    }
    @Test
    public void testCreateChangeRequestFailure() throws IOException{
        Object[] trafficChangeResponse = new Object[1];
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(500);
        trafficChangeResponse[0] = mockClientResponse;
        JsonNode firewallChanges = new ObjectMapper().readTree(Thread.currentThread().getContextClassLoader().getResource("test_input.json"));
        ObjectsData objectsData = objectsResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap, remedyDeviceNameAlgosecNameMap);
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        when(service.createTrafficRequest(any(List.class),eq(session))).thenReturn(trafficChangeResponse);
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {

            List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY, objectsData, session);
        });
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(),Integer.parseInt((thrown.getCode())));
    }

    @Test
    public void testInvalidPort() throws IOException{
        JsonNode firewallChanges = new ObjectMapper().readTree(TestData.getInvalidPortTrafficRequestJson());
        ObjectsData objectsData = objectsResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap, remedyDeviceNameAlgosecNameMap);
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {

            List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY, objectsData, session);
        });
        assertEquals(HttpStatus.BAD_REQUEST.value(),Integer.parseInt((thrown.getCode())));
        assertEquals("Not a valid port 'INVALID' specified in service 'TCP_INVALID'", thrown.getMessage());
    }

    @Test
    public void testInvalidProtocol() throws IOException{
        JsonNode firewallChanges = new ObjectMapper().readTree(TestData.getInvaliProtocolTrafficRequestJson());
        ObjectsData objectsData = objectsResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap, remedyDeviceNameAlgosecNameMap);
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {

            List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY, objectsData, session);
        });
        assertEquals(HttpStatus.BAD_REQUEST.value(),Integer.parseInt((thrown.getCode())));
        assertEquals("Not a valid protocol 'TEST2' specified in service 'TEST2_40'", thrown.getMessage());
    }

    @Test
    public void testInvalidService() throws IOException{
        JsonNode firewallChanges = new ObjectMapper().readTree(TestData.getInvalidServiceTrafficRequestJson());
        ObjectsData objectsData = objectsResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap, remedyDeviceNameAlgosecNameMap);
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {

            List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY, objectsData, session);
        });
        assertEquals(HttpStatus.BAD_REQUEST.value(),Integer.parseInt((thrown.getCode())));
        assertEquals("Service 'tcp/' is invalid or does not exist", thrown.getMessage());
    }

    @Test
    public void testServiceObjectNoInAlgosec() throws IOException{
        JsonNode firewallChanges = new ObjectMapper().readTree(TestData.getNonExistentServiceObjectTrafficRequestJson());
        ObjectsData objectsData = objectsResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap, remedyDeviceNameAlgosecNameMap);
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {

            List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY, objectsData, session);
        });
        assertEquals(HttpStatus.BAD_REQUEST.value(),Integer.parseInt((thrown.getCode())));
        assertEquals("Service 'service_object_does_not_exist_in_algosec' is invalid or does not exist", thrown.getMessage());
    }

    @Test
    public void testIpRangeinCreateSourceObjects() throws IOException,NoSuchFieldException,IllegalAccessException,SecurityException{

        Object[] trafficChangeResponse = new Object[1];
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200);
        when(mockResponseEntity.getBody()).thenReturn("{\n" +
                "    \"status\": \"Success\",\n" +
                "    \"messages\": [],\n" +
                "    \"data\": {\n" +
                "        \"changeRequestId\": 757,\n" +
                "        \"redirectUrl\": \"https://10.239.0.10/FireFlow/Ticket/Display.html?id=757\"\n" +
                "    }\n" +
                "}");
        trafficChangeResponse[0] = mockClientResponse;
        JsonNode firewallChanges = new ObjectMapper().readTree(Thread.currentThread().getContextClassLoader().getResource("test_input1.json"));
        ObjectsData objectsData = objectsResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap, remedyDeviceNameAlgosecNameMap);
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        when(service.createTrafficRequest(any(List.class),eq(session))).thenReturn(trafficChangeResponse);
        List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY,objectsData, session);
        assertEquals(changeId.get(0).getChangeId(),"757");
        assertEquals(changeId.get(0).getChangeType().toString().trim(),"POLICY_CREATE");

    }

    @Test
    public void testIpRangeinCreateDestinationObjects() throws IOException,NoSuchFieldException,IllegalAccessException,SecurityException{
        Object[] trafficChangeResponse = new Object[1];
        ClientResponse mockClientResponse = mock(ClientResponse.class);
        ResponseEntity mockResponseEntity = mock(ResponseEntity.class);
        Mono<ResponseEntity> mockMonoResponseEntity = Mono.just(mockResponseEntity);
        when(mockClientResponse.toEntity(any(Class.class))).thenReturn(mockMonoResponseEntity);
        when(mockClientResponse.rawStatusCode()).thenReturn(200);
        when(mockResponseEntity.getBody()).thenReturn("{\n" +
                "    \"status\": \"Success\",\n" +
                "    \"messages\": [],\n" +
                "    \"data\": {\n" +
                "        \"changeRequestId\": 757,\n" +
                "        \"redirectUrl\": \"https://10.239.0.10/FireFlow/Ticket/Display.html?id=757\"\n" +
                "    }\n" +
                "}");
        trafficChangeResponse[0] = mockClientResponse;
        JsonNode firewallChanges = new ObjectMapper().readTree(Thread.currentThread().getContextClassLoader().getResource("test_input1.json"));
        ObjectsData objectsData = objectsResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap, remedyDeviceNameAlgosecNameMap);
        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
        when(service.createTrafficRequest(any(List.class),eq(session))).thenReturn(trafficChangeResponse);
        List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY,objectsData, session);
        assertEquals(changeId.get(0).getChangeId(),"757");
        assertEquals(changeId.get(0).getChangeType().toString().trim(),"POLICY_CREATE");


    }
    // @Test
//    public void testInvalidPolicyUpdateSource() throws  IOException{
//        ObjectsResolver objectsResolver = Mockito.mock(ObjectsResolver.class);
//
//        Map<String,String> remedyDeviceNameAlgosecNameMap = new HashMap<>();
//        remedyDeviceNameAlgosecNameMap.put("atl_msslab_R8040_fw","atl_msslab_R8040_fw");
//
//        Map<String, String> networkObjectNameValueMap = new HashMap<>();
//        networkObjectNameValueMap.put("networkObjectInAlgosec1", "5.5.5.5");
//        networkObjectNameValueMap.put("networkObjectInAlgosec2", "6.6.6.6");
//        networkObjectNameValueMap.put("networkObjectInAlgosec3", "5.5.5.5,networkObjectInAlgosec2");
//        deviceNameNetworkObjectDetailsMapAsInAlgosec.put("atl_msslab_R8040_fw", networkObjectNameValueMap);
//
//        Map<String, List<String>> serviceObjectNameValueMap = new HashMap<>();
//        serviceObjectNameValueMap.put("serviceObjectInAlgosec1", Arrays.asList("tcp/443"));
//        serviceObjectNameValueMap.put("serviceObjectInAlgosec2", Arrays.asList("udp/333"));
//        serviceObjectNameValueMap.put("serviceObjectInAlgosec3", Arrays.asList("tcp/443","serviceObjectInAlgosec2"));
//        deviceNameServiceObjectDetailsMap.put("atl_msslab_R8040_fw", serviceObjectNameValueMap);
//        List<String> resolvedObjectList = new ArrayList<>();
//        resolvedObjectList.add("10.1.1.0");
//        resolvedObjectList.add("10.1.1.1");
//        resolvedObjectList.add("10.1.1.2");
//        resolvedObjectList.add("10.1.1.3");
//        resolvedObjectList.add("10.1.1.4");
//
//        JsonNode firewallChanges = new ObjectMapper().readTree(Thread.currentThread().getContextClassLoader().getResource("test_input.json"));
//        ObjectsData objectsData = tempObjectResolver.init(firewallChanges, deviceNameNetworkObjectDetailsMapAsInAlgosec, deviceNameServiceObjectDetailsMap);
//        when(devices.getRemedyDeviceNameAlgosecNameMap()).thenReturn(remedyDeviceNameAlgosecNameMap);
//        when(objectsResolver.resolveIfObject(eq("object"),eq("algosecdevice"),eq(IConstant.AlgosecObjectType.NETWORK),any(ObjectsData.class))).thenReturn(new ArrayList<>());
//        BusinessLogicException thrown = assertThrows(BusinessLogicException.class, () -> {
//
//            List<AlgosecChangeId> changeId = requester.createChangeRequest(firewallChanges, devices, IConstant.AlgosecChangeRententionType.TEMPORARY, objectsData, session);
//        });
//        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(),Integer.parseInt((thrown.getCode())));
//    }
}

