package com.ibm.sec.repository;


import com.ibm.sec.model.FirewallChangeEntity;
import com.ibm.sec.util.IConstant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Assert;

@DataJpaTest
public class FirewallChangeRepositoryTest {
	@Autowired
	FirewallChangeRepository firewallRepository;
	
	FirewallChangeEntity fwChange;

	@Test
	public void findByChangeId() {
		Date date = new Date();
		fwChange = new FirewallChangeEntity();
		fwChange.setChangeId("changeId");
		fwChange.setItsmId("001");
		fwChange.setId(2);
		fwChange.setSessionId("sessionId001");
		fwChange.setAlgoSecChangeRetentionType(IConstant.AlgosecChangeRententionType.TEMPORARY);
		fwChange.setChangeType(IConstant.AlgosecChangeType.POLICY_CREATE);
		fwChange.setTimeStamp(date);
		firewallRepository.save(fwChange);
		List<FirewallChangeEntity> firewallChange = firewallRepository.findBySessionIdAndAlgoSecChangeRetentionTypeAndChangeTypeIn("sessionId001", IConstant.AlgosecChangeRententionType.TEMPORARY, Arrays.asList(IConstant.AlgosecChangeType.POLICY_CREATE, IConstant.AlgosecChangeType.POLICY_DELETE));
		Assert.assertEquals("changeId", firewallChange.get(0).getChangeId());
	}
}
