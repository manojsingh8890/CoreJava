package com.ibm.sec.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;

import static com.ibm.sec.TestData.getAlgosecApiResponseForRiskReport;
import static com.ibm.sec.TestData.getAlgosecApiResponseForStatus;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class UtilTest {

    @Autowired
    private Util util;
    private static final ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testRegex() {
        String testData = "CF.{Risk_API_Details}: {\n"
                + "       \"RisksURLs\" : \"firewalls/afa-1221/riskCheck_3_fireflow63/risks.html\",\n"
                + "       \"Risk\" : [\n"
                + "          {\n"
                + "             \"profile\" : \"test\",\n"
                + "             \"name\" : \"test\",\n"
                + "             \"severity\" : \"low\"\n"
                + "          }\n"
                + "       ]\n"
                + "    }\n"
                + "CF.{MSS Ticket}: \n";
        String response = "\"Risk\" : [\n"
                + "          {\n"
                + "             \"profile\" : \"test\",\n"
                + "             \"name\" : \"test\",\n"
                + "             \"severity\" : \"low\"\n"
                + "          }\n"
                + "       ]";
        assertEquals(response, util.riskReportRegexMatch(testData));
    }

    @Test
    public void testRegexForNoRiskFound() {
        String testData = "CF.{Change Object Values}: \n"
        		+ "CF.{api_update}: \n"
        		+ "CF.{Risk_API_Details}: No risks were found\n"
        		+ "CF.{MSS Ticket}: \n"
        		+ "CF.{__Requested__Name}: ";
        
        String response = "No risks were found";
        assertEquals(response, util.riskReportRegexMatch(testData));
    }
    
    @Test
    public void testNotRegex() {
        String testData = "CF.{Risk_API_Details}: {\n"
                + "       \"RisksURLs\" : \"firewalls/afa-1221/riskCheck_3_fireflow63/risks.html\",\n"
                + "       \"Risk\" : [\n"
                + "          {\n"
                + "             \"profile\" : \"test\",\n"
                + "          }\n"
                + "       ]\n"
                + "    }\n"
                + "CF.{MSS Ticket}: \n";
        String response = "\"Risk\" : [\n"
                + "          {\n"
                + "             \"profile\" : \"test\",\n"
                + "             \"name\" : \"test\",\n"
                + "             \"severity\" : \"low\"\n"
                + "          }\n"
                + "       ]";
        assertNotEquals(response, util.riskReportRegexMatch(testData));
    }

    @Test
    public void testIsIpValid(){
       String ip = "0.0.0.0";
       assertTrue(util.isIpValid(ip));
    }

    @Test
    public void testIsIpNotValid(){
        String ip = "0..0.0";
        assertFalse(util.isIpValid(ip));

    }

    @Test
    public void testListToCommaSeperated(){
       // String req=
        String[] devices = {"a","e","i","o","u"};
        String expectedResponse = "a,e,i,o,u";
        List<String> vowelsList = Arrays.asList(devices);
        assertEquals(expectedResponse,util.listToCommaSeparated(vowelsList));
    }

    @Test
    public void testListToCommaSeperatedReturnsError(){
        // String req=
        String[] devices = {"a","ei","o"};
        String expectedResponse = "a,e,i,o,u";
        List<String> vowelsList = Arrays.asList(devices);
        assertNotEquals(expectedResponse,util.listToCommaSeparated(vowelsList));
    }

    @Test
    public void testJsonArrayToList(){
        List<String> expectedResult = Arrays.asList("a", "b");
        ArrayNode rootNode = mapper.createArrayNode();
        rootNode.add("a");
        rootNode.add("b");
        assertEquals(expectedResult,util.jsonArrayToList(rootNode));
    }
    @Test
    public void testJsonArrayToListReturnsError(){
        List<String> expectedResult = Arrays.asList("ab");
        ArrayNode rootNode = mapper.createArrayNode();
        rootNode.add("a");
        rootNode.add("b");
        assertNotEquals(expectedResult,util.jsonArrayToList(rootNode));
    }

    @Test
    public void testIsProtocolNameValid(){
        String Protocolname= "TCP";
        assertTrue(util.isProtocolNameValid(Protocolname));
    }
    @Test
    public void testIsProtocolNameNotValid(){
        String Protocolname= "hps";
        assertFalse(util.isProtocolNameValid(Protocolname));
    }

    @Test
    public void testIsPortNumberValid(){
        String Portnumber="3000";
        assertTrue(util.isPortNumberValid(Portnumber));
    }

    @Test
    public void testIsPortNumberNotValid(){
        String Portnumber="aaa";
        assertFalse(util.isPortNumberValid(Portnumber));
    }

    @Test
    public void testRiskAnalysisDateRegexMatch(){
        String testData = "\"Date\" : \"Tue Jul 26 13:04:29 2022\"";
        assertEquals(testData, util.riskAnalysisDateRegexMatch(getAlgosecApiResponseForRiskReport()));
    }

    @Test
    public void testRiskAnalysisDateRegexNotMatch(){
        String testData = "\"Date\" : \"Tue 26 13:04 2022\"";
        assertNotEquals(testData, util.riskAnalysisDateRegexMatch(getAlgosecApiResponseForRiskReport()));
    }

    @Test
    public void testStatusRegexMatch(){
        String testData = "Status: check";
        String status = util.statusRegexMatch(getAlgosecApiResponseForStatus());
        assertEquals(testData, status.substring(0, status.indexOf("\n")));
    }

    @Test
    public void testStatusRegexNotMatch(){
        String testData = "Status: uncheck";
        String status = util.statusRegexMatch(getAlgosecApiResponseForStatus());
        assertNotEquals(testData, status.substring(0, status.indexOf("\n")));
    }

    @Test
    public void testGetUniqueId(){
        assertNotNull(util.getUniqueId());
    }

}



//Vignesh

