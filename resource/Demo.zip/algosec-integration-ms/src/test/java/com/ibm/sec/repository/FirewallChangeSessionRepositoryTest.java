package com.ibm.sec.repository;

import java.util.Date;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.ibm.sec.model.FirewallChangeSessionEntity;

@DataJpaTest
public class FirewallChangeSessionRepositoryTest {
	
	@Autowired
	FirewallChangeSessionRepository firewallChangeSessionRepository;
	
	FirewallChangeSessionEntity firewallChangeSessionEntity;

	@Test
	public void findByChangeId() {
		Date date = new Date();
		firewallChangeSessionEntity = new FirewallChangeSessionEntity();
		firewallChangeSessionEntity.setId(1);
		firewallChangeSessionEntity.setSessionId("sessionId001");
		firewallChangeSessionEntity.setTimeStamp(date);
		firewallChangeSessionRepository.save(firewallChangeSessionEntity);
		FirewallChangeSessionEntity firewallChange = firewallChangeSessionRepository.findBySessionId("sessionId001");
		Assert.assertEquals("sessionId001", firewallChange.getSessionId());
	}

}
