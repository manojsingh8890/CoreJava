package com.ibm.sec.util;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import com.ibm.sec.model.Claims;
import com.ibm.sec.model.UserSession;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SpringBootTest
public class RestUtilTest {

    @Autowired
    private static MockWebServer mockWebServer;

    @Autowired
    private RestUtil restUtil;

    //@MockBean
    private UserSession session;

    @BeforeAll
    static void setUp() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start();
    }

    @BeforeEach
    public void createUserSession() {
        session = new UserSession();
        session.setSessionId("abc");
        session.setAuthHeaderValue("def");
        session.setAlgoSecFaSessionId("ghi");
        session.setAlgoSecSessionId("jkl");
        session.setAlgoSecPhpSessionId("mno");
        session.setThreadUuid("pqr");
        Claims claims = new Claims();
        claims.setCustomerId("123");
        claims.setUserName("stu");
        session.setClaims(claims);
    }

    @AfterAll
    static void tearDown() throws IOException {
        mockWebServer.shutdown();
    }

    @BeforeEach
    void beforeTest() throws NoSuchFieldException, IllegalAccessException{
        Field webClientField = restUtil.getClass().getDeclaredField("webClient");
        webClientField.setAccessible(true);
        webClientField.set(restUtil, WebClient.create(mockWebServer.url("").toString()));
    }

    @Test
    public void testMakeGetCallSuccess() {
        String data = "[{\"id\": \"123\", \"name\": \"abc\"}]";
        mockWebServer.enqueue(new MockResponse().setBody(data).setResponseCode(200));
        Mono<String> stringMono = restUtil.makeGetCallToMSSAPIs(session, false, "", String.class);
        StepVerifier.create(stringMono).assertNext(string -> {
            assertEquals(data, string);
        }).verifyComplete();
    }

    @Test
    public void testMakeGetCallSuccessWithAdmin() {
        String data = "[{\"id\": \"123\", \"name\": \"abc\"}]";
        mockWebServer.enqueue(new MockResponse().setBody(data).setResponseCode(200));
        Mono<String> stringMono = restUtil.makeGetCallToMSSAPIs(session, true, "", String.class);
        StepVerifier.create(stringMono).assertNext(string -> {
            assertEquals(data, string);
        }).verifyComplete();
    }

    @Test
    public void testMakePutCallSuccess() {
        String data = "[{\"id\": \"123\", \"name\": \"abc\"}]";
        mockWebServer.enqueue(new MockResponse().setBody(data).setResponseCode(200));
        Mono<String> stringMono = restUtil.makePutCallToMSSAPIs(session, true, "", data, String.class);
        StepVerifier.create(stringMono).assertNext(string -> {
            assertEquals(data, string);
        }).verifyComplete();
    }

    @Test
    public void testMakePutCallSuccessWithAdmin() {
        String data = "[{\"id\": \"123\", \"name\": \"abc\"}]";
        mockWebServer.enqueue(new MockResponse().setBody(data).setResponseCode(200));
        Mono<String> stringMono = restUtil.makePutCallToMSSAPIs(session, false, "", data, String.class);
        StepVerifier.create(stringMono).assertNext(string -> {
            assertEquals(data, string);
        }).verifyComplete();
    }

    @Test
    public void testMakeGetCallAlgosecApiSuccess() {
        String data = "[{\"id\": \"123\", \"name\": \"abc\"}]";
        Map<String, String> headers = new HashMap();
        headers.put("abc", "xyz");
        mockWebServer.enqueue(new MockResponse().setBody(data).setResponseCode(200));
        Mono<String> stringMono = restUtil.makeGetCallToAlgosecAPIs(session, "", String.class, headers);
        StepVerifier.create(stringMono).assertNext(string -> {
            assertEquals(data, string);
        }).verifyComplete();
    } 
    
    @Test
    public void testMakePostCallAlgosecApiSuccess() {
        mockWebServer.enqueue(new MockResponse().setResponseCode(200));
        Mono<ClientResponse> response = restUtil.makePostCallToAlgosecAPIs(session, "", null, "");
        assertEquals(response.block().rawStatusCode(), 200);
    }

    @Test
    public void testMakePostCallAlgosecApiSuccessWithHeaders() {
        Map<String, String> headers = new HashMap();
        headers.put("abc", "xyz");
        mockWebServer.enqueue(new MockResponse().setResponseCode(200));
        Mono<ClientResponse> response = restUtil.makePostCallToAlgosecAPIs(session, "", headers, "");
        assertEquals(response.block().rawStatusCode(), 200);
    }

    @Test
    public void testMakePutCallAlgosecApiSuccessWithHeaders() {
        Map<String, String> headers = new HashMap();
        headers.put("abc", "xyz");
        mockWebServer.enqueue(new MockResponse().setResponseCode(200));
        Mono<ClientResponse> response = restUtil.makePutCallToAlgosecAPIs(session, "", headers, "");
        assertEquals(response.block().rawStatusCode(), 200);
    }
    
    @Test
    public void testMakePutCallAlgosecApiNegWithHeaders() {
        Map<String, String> headers = new HashMap();
        headers.put("abc", "xyz");
        mockWebServer.enqueue(new MockResponse().setResponseCode(500));
        Mono<ClientResponse> response = restUtil.makePutCallToAlgosecAPIs(session, "", headers, "");
        assertEquals(response.block().rawStatusCode(), 500);
    }

}
