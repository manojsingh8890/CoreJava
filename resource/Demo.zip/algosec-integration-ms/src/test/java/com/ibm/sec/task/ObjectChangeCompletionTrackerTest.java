package com.ibm.sec.task;

import com.ibm.sec.TestData;
import com.ibm.sec.dao.FirewallChangeDAO;
import com.ibm.sec.model.FirewallChangeRequestEntity;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.model.algosec.FireFlowAPIAuthResponse;
import com.ibm.sec.service.AlgosecService;
import com.ibm.sec.service.ApplicationService;
import com.ibm.sec.service.DeviceService;
import com.ibm.sec.service.ServiceFacade;
import com.ibm.sec.util.JsonUtil;
import com.ibm.sec.util.Util;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;


@SpringBootTest
public class ObjectChangeCompletionTrackerTest {

    @Autowired
    private ObjectChangeCompletionTracker objectChangeCompletionTracker;
    @MockBean
    private FirewallChangeDAO firewallChangeDAO;
    @Autowired
    private JsonUtil jsonUtil;
    @MockBean
    private AlgosecService algosecService;
    @Autowired
    private Util util;
    @MockBean
    private DeviceService deviceService;
    @MockBean
    private ServiceFacade businessLogic;
    @MockBean
    private ApplicationService applicationService;
    @Autowired
    private TaskQueue taskQueue;
    @BeforeEach
    public void fillQueue() {
        ObjectChangeStatusCheckerTask task = new ObjectChangeStatusCheckerTask();
        task.setSessionId("session001");
        task.setSocTicketId("ABC");
        task.setChangeIds(Arrays.asList("1", "2"));
        taskQueue.addTask(task);
    }

    @Test
    public void testCheckObjectChangeCompletionAsResolved() {
        FireFlowAPIAuthResponse response = new FireFlowAPIAuthResponse();
        response.setSessionId("si");
        response.setFaSessionId("fasi");
        response.setPhpSessionId("phpsi");
        Map<String,String> serviceResponse = new HashMap<>();
        serviceResponse.put("001", TestData.getAlgosecApiResponseForStatusResolved());
        String data = "\"{\\n  \\\"Object Update\\\": [\\n    {\\n      \\\"request_item\\\": \\\"1\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"object_type\\\": \\\"Host\\\",\\n      \\\"object_name\\\": \\\"H_10.1.1.1\\\",\\n      \\\"action_items\\\": \\\"10.1.1.1\\\",\\n      \\\"comments\\\": \\\"Create host with IP 10.1.1.1\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"2\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"object_type\\\": \\\"Host\\\",\\n      \\\"object_name\\\": \\\"H_10.1.1.2\\\",\\n      \\\"action_items\\\": \\\"10.1.1.2\\\",\\n      \\\"comments\\\": \\\"Create host with IP 10.1.1.2\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"5\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"object_type\\\": \\\"Network\\\",\\n      \\\"object_name\\\": \\\"N_11.1.1.0\\\",\\n      \\\"action_items\\\": \\\"1.12.25.0/24\\\",\\n      \\\"comments\\\": \\\"Create host with IP 10.1.1.4\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    }\\n  ],\\n  \\\"Policy Update\\\": [\\n    {\\n      \\\"request_item\\\": \\\"1\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"source_address\\\": \\\"192.168.12.1\\\",\\n      \\\"destination_address\\\": \\\"255.255.255.12\\\",\\n      \\\"service\\\": \\\"TCP/443\\\",\\n      \\\"application\\\": \\\"SNow,.IBM.box.com\\\",\\n      \\\"advance_security\\\": \\\"Apply Substandard_Policy\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Accept\\\",\\n      \\\"comments\\\": \\\"To allow traffic from one network to another on port 443\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"2\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"source_zone\\\": \\\"Inbound\\\",\\n      \\\"destination_zone\\\": \\\"Outbound\\\",\\n      \\\"source_address\\\": \\\"H_10.1.1.1\\\",\\n      \\\"destination_address\\\": \\\"ANY\\\",\\n      \\\"service\\\": \\\"TCP/443,TCP/80\\\",\\n      \\\"application\\\": \\\"DancedanceRevolution.org\\\",\\n      \\\"advance_security\\\": \\\"Dance_Fever_Protection_Suite\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Deny\\\",\\n      \\\"comments\\\": \\\"Protect Internal host from Boogie Fever\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"3\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"source_zone\\\": \\\"LAN4\\\",\\n      \\\"destination_zone\\\": \\\"WAN\\\",\\n      \\\"source_address\\\": \\\"N_11.1.1.0\\\",\\n      \\\"destination_address\\\": \\\"ANY\\\",\\n      \\\"service\\\": \\\"ANY\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Accept\\\",\\n      \\\"comments\\\": \\\"Customer Access\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"5\\\",\\n      \\\"action\\\": \\\"Delete\\\",\\n      \\\"rule_id\\\": \\\"CF9B1CA6-E509-4AF3-949F-927A342B2232\\\",\\n      \\\"source_address\\\": \\\"10.0.0.0/16\\\",\\n      \\\"destination_address\\\": \\\"123.45.67.90/32\\\",\\n      \\\"service\\\": \\\"ANY\\\",\\n      \\\"advance_security\\\": \\\"N/A\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Deny\\\",\\n      \\\"comments\\\": \\\"Remove Audit Scanners after Audit\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"6\\\",\\n      \\\"action\\\": \\\"Delete\\\",\\n      \\\"rule_id\\\": \\\"D978125E-0473-495C-ADCF-F1BD262EAB0A\\\",\\n      \\\"source_address\\\": \\\"10.0.0.0/16\\\",\\n      \\\"destination_address\\\": \\\"123.45.67.90/32\\\",\\n      \\\"service\\\": \\\"ANY\\\",\\n      \\\"advance_security\\\": \\\"N/A\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Deny\\\",\\n      \\\"comments\\\": \\\"Remove Audit Scanners after Audit\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"7\\\",\\n      \\\"action\\\": \\\"Delete\\\",\\n      \\\"rule_id\\\": \\\"02EAAED1-7FC1-46D3-BFC1-FB6EF2573DE9\\\",\\n      \\\"source_address\\\": \\\"10.0.0.0/16\\\",\\n      \\\"destination_address\\\": \\\"123.45.67.90/32\\\",\\n      \\\"service\\\": \\\"ANY\\\",\\n      \\\"advance_security\\\": \\\"N/A\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Deny\\\",\\n      \\\"comments\\\": \\\"Remove Audit Scanners after Audit\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    }\\n  ]\\n}\"";

        FirewallChangeRequestEntity entity = new FirewallChangeRequestEntity();
        entity.setChangeRequest(data);
        when(algosecService.authenticate(any())).thenReturn(response);
        when(algosecService.getRiskReport(any(), any(UserSession.class))).thenReturn(serviceResponse);
        when(applicationService.updateSocTicket(any(UserSession.class), any(), any(), anyBoolean())).thenReturn(Mono.just("{\"id\": \"abc\"}"));
        when(firewallChangeDAO.getChangeRequestBySessionId(anyString())).thenReturn(entity);
        objectChangeCompletionTracker.checkObjectChangeCompletion();
    }

    @Test
    public void testCheckObjectChangeCompletionAsChecked() {
        FireFlowAPIAuthResponse response = new FireFlowAPIAuthResponse();
        response.setSessionId("si");
        response.setFaSessionId("fasi");
        response.setPhpSessionId("phpsi");
        Map<String,String> serviceResponse = new HashMap<>();
        serviceResponse.put("001", TestData.getAlgosecApiResponseForStatus());
        String data = "\"{\\n  \\\"Object Update\\\": [\\n    {\\n      \\\"request_item\\\": \\\"1\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"object_type\\\": \\\"Host\\\",\\n      \\\"object_name\\\": \\\"H_10.1.1.1\\\",\\n      \\\"action_items\\\": \\\"10.1.1.1\\\",\\n      \\\"comments\\\": \\\"Create host with IP 10.1.1.1\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"2\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"object_type\\\": \\\"Host\\\",\\n      \\\"object_name\\\": \\\"H_10.1.1.2\\\",\\n      \\\"action_items\\\": \\\"10.1.1.2\\\",\\n      \\\"comments\\\": \\\"Create host with IP 10.1.1.2\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"5\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"object_type\\\": \\\"Network\\\",\\n      \\\"object_name\\\": \\\"N_11.1.1.0\\\",\\n      \\\"action_items\\\": \\\"1.12.25.0/24\\\",\\n      \\\"comments\\\": \\\"Create host with IP 10.1.1.4\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    }\\n  ],\\n  \\\"Policy Update\\\": [\\n    {\\n      \\\"request_item\\\": \\\"1\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"source_address\\\": \\\"192.168.12.1\\\",\\n      \\\"destination_address\\\": \\\"255.255.255.12\\\",\\n      \\\"service\\\": \\\"TCP/443\\\",\\n      \\\"application\\\": \\\"SNow,.IBM.box.com\\\",\\n      \\\"advance_security\\\": \\\"Apply Substandard_Policy\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Accept\\\",\\n      \\\"comments\\\": \\\"To allow traffic from one network to another on port 443\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"2\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"source_zone\\\": \\\"Inbound\\\",\\n      \\\"destination_zone\\\": \\\"Outbound\\\",\\n      \\\"source_address\\\": \\\"H_10.1.1.1\\\",\\n      \\\"destination_address\\\": \\\"ANY\\\",\\n      \\\"service\\\": \\\"TCP/443,TCP/80\\\",\\n      \\\"application\\\": \\\"DancedanceRevolution.org\\\",\\n      \\\"advance_security\\\": \\\"Dance_Fever_Protection_Suite\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Deny\\\",\\n      \\\"comments\\\": \\\"Protect Internal host from Boogie Fever\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"3\\\",\\n      \\\"action\\\": \\\"Create\\\",\\n      \\\"source_zone\\\": \\\"LAN4\\\",\\n      \\\"destination_zone\\\": \\\"WAN\\\",\\n      \\\"source_address\\\": \\\"N_11.1.1.0\\\",\\n      \\\"destination_address\\\": \\\"ANY\\\",\\n      \\\"service\\\": \\\"ANY\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Accept\\\",\\n      \\\"comments\\\": \\\"Customer Access\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"5\\\",\\n      \\\"action\\\": \\\"Delete\\\",\\n      \\\"rule_id\\\": \\\"CF9B1CA6-E509-4AF3-949F-927A342B2232\\\",\\n      \\\"source_address\\\": \\\"10.0.0.0/16\\\",\\n      \\\"destination_address\\\": \\\"123.45.67.90/32\\\",\\n      \\\"service\\\": \\\"ANY\\\",\\n      \\\"advance_security\\\": \\\"N/A\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Deny\\\",\\n      \\\"comments\\\": \\\"Remove Audit Scanners after Audit\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"6\\\",\\n      \\\"action\\\": \\\"Delete\\\",\\n      \\\"rule_id\\\": \\\"D978125E-0473-495C-ADCF-F1BD262EAB0A\\\",\\n      \\\"source_address\\\": \\\"10.0.0.0/16\\\",\\n      \\\"destination_address\\\": \\\"123.45.67.90/32\\\",\\n      \\\"service\\\": \\\"ANY\\\",\\n      \\\"advance_security\\\": \\\"N/A\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Deny\\\",\\n      \\\"comments\\\": \\\"Remove Audit Scanners after Audit\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    },\\n    {\\n      \\\"request_item\\\": \\\"7\\\",\\n      \\\"action\\\": \\\"Delete\\\",\\n      \\\"rule_id\\\": \\\"02EAAED1-7FC1-46D3-BFC1-FB6EF2573DE9\\\",\\n      \\\"source_address\\\": \\\"10.0.0.0/16\\\",\\n      \\\"destination_address\\\": \\\"123.45.67.90/32\\\",\\n      \\\"service\\\": \\\"ANY\\\",\\n      \\\"advance_security\\\": \\\"N/A\\\",\\n      \\\"acl_action_{accept,_deny}\\\": \\\"Deny\\\",\\n      \\\"comments\\\": \\\"Remove Audit Scanners after Audit\\\",\\n      \\\"firewall_policy\\\": \\\"atl_msslab_R8040_fw\\\"\\n    }\\n  ]\\n}\"";

        FirewallChangeRequestEntity entity = new FirewallChangeRequestEntity();
        entity.setChangeRequest(data);
        when(algosecService.authenticate(any())).thenReturn(response);
        when(algosecService.getRiskReport(any(), any(UserSession.class))).thenReturn(serviceResponse);
        objectChangeCompletionTracker.checkObjectChangeCompletion();
    }

}
