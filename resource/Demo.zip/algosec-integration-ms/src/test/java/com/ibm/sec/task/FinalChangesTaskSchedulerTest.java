package com.ibm.sec.task;

import org.awaitility.Duration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import static org.awaitility.Awaitility.await;
import static org.mockito.Mockito.verify;
import static org.mockito.internal.verification.VerificationModeFactory.times;

@SpringBootTest
@SpringJUnitConfig(TaskConfig.class)
public class FinalChangesTaskSchedulerTest {

    @SpyBean
    private FinalChangesTaskScheduler finalChangesTaskScheduler;
    @MockBean
    private ObjectChangeCompletionTracker objectChangeCompletionTracker;

    @Test
    public void jobRuns() {
        await().atMost(Duration.FIVE_SECONDS)
                .untilAsserted(() -> verify(finalChangesTaskScheduler, times(1)).scheduledObjectChangeCreationTask());
    }
}
