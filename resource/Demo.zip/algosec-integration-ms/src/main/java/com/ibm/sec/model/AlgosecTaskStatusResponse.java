package com.ibm.sec.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import static com.ibm.sec.util.IConstant.AlgosecTaskStatus;

import com.ibm.sec.util.IConstant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class AlgosecTaskStatusResponse {

    @JsonProperty("SESSION_ID")
    private String sessionId;
    private AlgosecTaskStatus status;
    private String data; //actual response
    private List<Error> errors = new ArrayList<>();

    @Getter
    @Setter
    @AllArgsConstructor
    public static class Error {
        private String message;
    }

    public void addError(String error) {
        errors.add(new Error(error));
    }
}
