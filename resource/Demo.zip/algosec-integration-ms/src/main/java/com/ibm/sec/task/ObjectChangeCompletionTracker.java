package com.ibm.sec.task;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.ibm.sec.dao.FirewallChangeDAO;
import com.ibm.sec.model.*;
import com.ibm.sec.model.algosec.FireFlowAPIAuthResponse;
import com.ibm.sec.service.AlgosecService;
import com.ibm.sec.service.ApplicationService;
import com.ibm.sec.service.DeviceService;
import com.ibm.sec.service.ServiceFacade;
import com.ibm.sec.util.IConstant;
import com.ibm.sec.util.JsonUtil;
import com.ibm.sec.util.Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ObjectChangeCompletionTracker {

    @Autowired
    private TaskQueue taskQueue;
    @Autowired
    private FirewallChangeDAO firewallChangeDAO;
    @Autowired
    private JsonUtil jsonUtil;
    @Autowired
    private AlgosecService algosecService;
    @Autowired
    private Util util;
    @Autowired
    private DeviceService deviceService;
    @Autowired
    private ServiceFacade businessLogic;
    @Autowired
    private ApplicationService applicationService;

    /**
     * checks the status of final object change request, and if it is in 'resolved' status then create/delete final policies
     */
    public void checkObjectChangeCompletion() {

        Optional<ObjectChangeStatusCheckerTask> sessionIdOptional = taskQueue.getTask();
        if (sessionIdOptional.isEmpty()) {
            return;
        }
        ObjectChangeStatusCheckerTask task = sessionIdOptional.get();

        UserSession session = new UserSession();
        FireFlowAPIAuthResponse authResponse = algosecService.authenticate(session);
        session.setAlgoSecSessionId(authResponse.getSessionId());
        session.setAlgoSecFaSessionId(authResponse.getFaSessionId());
        session.setAlgoSecPhpSessionId(authResponse.getPhpSessionId());
        session.setSessionId(task.getSessionId());
        session.setAlgosecSessionCreationTime(authResponse.getAlgosecSessionCreationTime());

        Map<String, String> changeIdsContent = algosecService.getRiskReport(task.getChangeIds(), session);
        changeIdsContent.forEach((changeId, algosecChangeContent) -> {
            log.info("Algosec Change Request content for session id {} and change id {} is {}", session.getSessionId(), changeId, algosecChangeContent);
        });

        Set<Map.Entry<String, String>> entry = changeIdsContent.entrySet();
        Iterator<Map.Entry<String, String>> i = entry.iterator();

        while (i.hasNext()) {
            Map.Entry<String, String> changeIdContent = i.next();
            String statusVal = util.statusRegexMatch(changeIdContent.getValue()).replaceFirst("Status:", "");
            String status = statusVal.substring(0, statusVal.indexOf("\n")).trim();
            log.info("Object Change Request completion status for session id {} and change id {} is {}", session.getSessionId(), changeIdContent.getKey(), status);
            if (!status.equals(IConstant.OBJECT_CHANGE_REQUEST_COMPLETION_STATUS)) {
                if (!taskQueue.hasTask(task)) taskQueue.addTask(task);
                continue;
            }

            // ticket-detail-ms call to update worklog text with completion status as resolved in SOC ticket
            try {
                StringBuilder worklogText = new StringBuilder();

                worklogText.append("{\"").append(IConstant.WORKLOG_TEXT).append("\":\"");
                worklogText.append("Object change request completion status for change id(s) ").append(String.join(",", changeIdContent.getKey())).append(" is resolved.");
                worklogText.append("\"}");
                String response = applicationService.updateSocTicket(session, worklogText.toString(), task.getSocTicketId(), true).block();
                log.info("response from ticket-detail-ms {}", response);
            } catch (Exception e) {
                log.error("Error updating worklog text in remedy for SessionId " + task.getSessionId(), e);
                firewallChangeDAO.saveError(e.getMessage(), IConstant.Functionality.FINAL_OBJECT_CHANGE, session.getSessionId());
                return;
            }
            FirewallChangeRequestEntity changeRequestEntity = null;
            //fetch change request from DB
            try {
                changeRequestEntity = firewallChangeDAO.getChangeRequestBySessionId(task.getSessionId());
            } catch (Exception e) {
                log.error("Error fetching change request from DB for SessionId " + task.getSessionId(), e);
                firewallChangeDAO.saveError(e.getMessage(), IConstant.Functionality.FINAL_OBJECT_CHANGE, session.getSessionId());
                return;
            }
            //parse change request into JsonNode
            JsonNode changeRequestJsonNode = null;
            try {
                JsonNode changeRequestJsonNodeTemp = jsonUtil.parse(changeRequestEntity.getChangeRequest());
                changeRequestJsonNode = jsonUtil.parse(changeRequestJsonNodeTemp.textValue());
            } catch (JsonProcessingException e) {
                log.error("Error parsing change request fetched from DB for SessionId " + task.getSessionId(), e);
                firewallChangeDAO.saveError(e.getMessage(), IConstant.Functionality.FINAL_OBJECT_CHANGE, session.getSessionId());
                return;
            }
            //create final policy create and rule delete requests
            String finalChangeIds = "";
            try {
                Devices devices = deviceService.fetchDeviceInfo(changeRequestJsonNode, session, true, IConstant.AlgosecChangeRententionType.FINAL);
                List<AlgosecChangeId> algosecChangeIds = businessLogic.createChange(changeRequestJsonNode, devices, IConstant.AlgosecChangeRententionType.FINAL, session, devices.getRemedyDeviceNameAlgosecNameMap());
                finalChangeIds = String.join(",", algosecChangeIds.stream().map(AlgosecChangeId::getChangeId).collect(Collectors.toList()).toArray(new String[algosecChangeIds.size()]));
                log.info("Algosec change ids {} created for session id {}", finalChangeIds, session.getSessionId());
            } catch (Exception e) {
                log.error("Error occurred for sessionId " + session.getSessionId(), e);
                firewallChangeDAO.saveError(e.getMessage(), IConstant.Functionality.FINAL_OBJECT_CHANGE, session.getSessionId());
            } finally {
                firewallChangeDAO.markCompleteFinalRequests(session.getSessionId());

            }

            // ticket-detail-ms call to add the algosecChangeIds for final policy create and rule delete requests in SOC ticket
            try {

                String ticketDetails = applicationService.getSocTicket(session, task.getSocTicketId(), true).block();
                JsonNode ticketJson = jsonUtil.parse(ticketDetails);
                String objectChangeIds = ticketJson.get(0).get(IConstant.POLICY_MGMT_TICKET_ID).asText();

                String socTicketBody = "{\"" + IConstant.POLICY_MGMT_TICKET_ID + "\":\"" + objectChangeIds + "," + finalChangeIds + "\"}";
                String response = applicationService.updateSocTicket(session, socTicketBody, task.getSocTicketId(), true).block();
                log.info("response from ticket-detail-ms {}", response);
            } catch (Exception e) {
                log.error("Error updating change ids in remedy for SessionId " + task.getSessionId(), e);
                firewallChangeDAO.saveError(e.getMessage(), IConstant.Functionality.FINAL_OBJECT_CHANGE, session.getSessionId());
                return;
            }
            i.remove();
            task.getChangeIds().remove(changeIdContent.getKey());
        }
    }
}
