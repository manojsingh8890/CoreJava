package com.ibm.sec.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Contains various attributes of the calling user.
 */
@Setter
@Getter(AccessLevel.PACKAGE)
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Claims {
    private String customerId;
    @JsonProperty("username")
    private String userName;
}
