package com.ibm.sec.model;

import java.util.Date;

import javax.persistence.*;

import com.ibm.sec.util.IConstant;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name="firewall_change")
public class FirewallChangeEntity implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private int id;
	
	@Column(name="Change_ID")
	private String changeId;
	
	@CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name="Timestamp")
	private Date timeStamp;
	
	@Column(name="ITSM_ID")
	private String itsmId;

	@Column(name="CHANGE_TYPE")
	@Enumerated(EnumType.STRING)
	private IConstant.AlgosecChangeType changeType;

	@Column(name="ALGOSEC_CHANGE_STATUS")
	@Enumerated(EnumType.STRING)
	private IConstant.AlgosecChangeStatus algoSecChangeStatus;

	@Column(name="SESSION_ID")
	private String sessionId;

	@Column(name="ALGOSEC_CHANGE_RETENTION_TYPE")
	@Enumerated(EnumType.STRING)
	private IConstant.AlgosecChangeRententionType algoSecChangeRetentionType;

	//public FirewallChangeEntity() {}

//	public FirewallChangeEntity(String changeId, String itsmId, String status) {
//		super();
//		this.changeId = changeId;
//		this.itsmId = itsmId;
//		this.status = status;
//	}
	
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = new Date(timeStamp.getTime());
	}
}