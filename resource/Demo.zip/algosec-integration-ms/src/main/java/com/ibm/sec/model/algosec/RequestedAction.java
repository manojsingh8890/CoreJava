package com.ibm.sec.model.algosec;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.ibm.sec.util.IConstant;
import lombok.Getter;
import lombok.Setter;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestedAction implements Comparable<RequestedAction> {
    private String action;
    private String name;
    private String type;
    private String isGroup;
    private List<String> values;
    @JsonIgnore
    private String groupType; //this field is not part of the contract and should never be passed to the API. This field is needed for sorting only

    @Override
    public int compareTo(@NotNull RequestedAction other) {
        if(groupType.equals(IConstant.OBJECT_GROUP_TYPE_GROUP_OBJECT)) {
            return 1;
        } else {
            return -1;
        }
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        RequestedAction action = (RequestedAction) o;
//        return name.equals(action.name);
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(name);
//    }
}
