package com.ibm.sec.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.error.ErrorConfig;
import com.ibm.sec.model.AlgosecChangeId;
import com.ibm.sec.model.Devices;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.model.algosec.*;
import com.ibm.sec.util.IConstant;
import com.ibm.sec.util.JsonUtil;
import com.ibm.sec.util.NetmaskUtil;
import com.ibm.sec.util.Util;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;

import java.util.*;

/**
 * This class takes Policy Update section of PCR Firewall template, generates the Algosec change request and calls the algosec APIs
 * to generate a change ID.
 */
@Component
@Slf4j
class TrafficChangeRequester implements ChangeRequester {

    @Autowired
    private ObjectsResolver objectsResolver;
    @Autowired
    private JsonUtil jsonUtil;
    @Autowired
    private AlgosecService service;
    @Autowired
    private ErrorConfig errorConfig;
    @Autowired
    private Util util;
    @Autowired
    private NetmaskUtil netmaskUtil;

    @Value("${policy_update_request_template}")
    private String policyUpdateRequestTemplateName;

    /**
     * This method creates Traffic Change Requests in Algosec
     * @param firewallChanges Input Json for traffic change
     * @param devices
     * @param changeRententionType TEMPORARY / FINAL*/
    @Override
    public List<AlgosecChangeId> createChangeRequest(JsonNode firewallChanges, Devices devices, IConstant.AlgosecChangeRententionType changeRententionType, ObjectsData objectsData, UserSession session) throws JsonProcessingException {
        List<AlgosecChangeId> changeIds = new ArrayList<>();
        if (firewallChanges.has(IConstant.POLICY_UPDATE_CHANGES)) {
            JsonNode policyUpdateNode = firewallChanges.get(IConstant.POLICY_UPDATE_CHANGES);
            Map<String, List<JsonNode>> remedyDeviceNamePolicyCreateChangeNodesMap = new HashMap<>();
            for (int i = 0; i < policyUpdateNode.size(); i++) {
                JsonNode policyUpdateRequestNode = policyUpdateNode.get(i);
                if (IConstant.CHANGE_ACTION_TYPE_CREATE.equals(policyUpdateRequestNode.get("action").asText())) {
                    String remedyDeviceName = policyUpdateRequestNode.get("firewall_policy").asText();
                    if (!remedyDeviceNamePolicyCreateChangeNodesMap.containsKey(remedyDeviceName)) {
                        remedyDeviceNamePolicyCreateChangeNodesMap.put(remedyDeviceName, new ArrayList<>());
                    }
                    remedyDeviceNamePolicyCreateChangeNodesMap.get(remedyDeviceName).add(policyUpdateRequestNode);
                }
            }
//            if (!remedyDeviceNamePolicyCreateChangeNodesMap.isEmpty()) {
//                //map remedy device names to algosec device names
//                // ... some other Stream processings
//                for (Map.Entry<String, List<JsonNode>> createRequest : remedyDeviceNamePolicyCreateChangeNodesMap.entrySet()) {
//                   // changeId = new AlgosecChangeId();
//                   // changeId.setChangeType(IConstant.POLICY_UPDATE_CHANGE);
//                    changeReqNumberToAlgosecTrafficChangeReqMappings.add(toAlgosecTrafficChangeRequestForPolicyUpdate(createRequest.getValue(), algosecDeviceNames, createRequest.getKey()));
////                    log.info("Change request::" + jsonUtil.toString(changeReqNumberToAlgosecTrafficChangeReqMapping.getRequest()));
////                    String sessionId = session.getSessionId();
////                    log.debug("SessionId: " + sessionId);
////                    changeId.setChangeId(String.valueOf(service.createChangeRequest(changeReqNumberToAlgosecTrafficChangeReqMapping.getRequest())));
////                    changeId.setSourceRequestNumbers(changeReqNumberToAlgosecTrafficChangeReqMapping.getSourceRequestNumbers());
//
//                }
//            }
            //List<String> sourceRequestNumbers = new ArrayList<>();
            List<TrafficChangeRequest> algosecTrafficChangeRequestObjects = createAlgosecTrafficChangeRequestObjects(remedyDeviceNamePolicyCreateChangeNodesMap, devices, changeRententionType, objectsData);
            if(!algosecTrafficChangeRequestObjects.isEmpty()) {
                Object[] responses = service.createTrafficRequest(algosecTrafficChangeRequestObjects, session);
                for (int r = 0; r < responses.length; r++) {
                    ClientResponse response = (ClientResponse) responses[r];
                    ResponseEntity<String> responseEntity = response.toEntity(String.class).block();
                    String responseBody = responseEntity.getBody();
                    if (response.rawStatusCode() != 200) {
                        log.error("SessionId: " + session.getSessionId() + " traffic change request: " + jsonUtil.toString(algosecTrafficChangeRequestObjects.get(r)) + ", response: " + responseBody + ", IsError? TRUE http code: " + response.rawStatusCode());
                        //log.error("Algosec traffic change request API call failed with http status code:" + response.rawStatusCode() + " and error response is:" + responseBody);
                        throw new BusinessLogicException(errorConfig.getHttpStatus().getInternalError(), errorConfig.getCode().getInternalError(), errorConfig.getMessage().getInternalError());
                    } else {
                        log.info("SessionId: " + session.getSessionId() + " traffic change request: " + jsonUtil.toString(algosecTrafficChangeRequestObjects.get(r)) + ", response: " + responseBody + ", IsError? FALSE");
                        AlgosecChangeId changeId = new AlgosecChangeId();
                        changeId.setChangeId(String.valueOf(jsonUtil.getFieldValueAsInt(responseBody, "$.data.changeRequestId")));
                        changeId.setChangeType(IConstant.AlgosecChangeType.POLICY_CREATE);
                        changeIds.add(changeId);
                    }
                }
            }
        }
        return changeIds;
    }

    private List<TrafficChangeRequest> createAlgosecTrafficChangeRequestObjects(Map<String, List<JsonNode>> remedyDeviceNamePolicyCreateChangeNodesMap, Devices devices, IConstant.AlgosecChangeRententionType changeRententionType, ObjectsData objectsData) {
        List<TrafficChangeRequest> changeRequestObjects = new ArrayList<>();
        Set<Map.Entry<String, List<JsonNode>>> set = remedyDeviceNamePolicyCreateChangeNodesMap.entrySet();
        for(Map.Entry<String, List<JsonNode>> entry : set) {
            String remedyDeviceName = entry.getKey();
            String algosecDeviceName = devices.getRemedyDeviceNameAlgosecNameMap().get(remedyDeviceName);
            List<JsonNode> createActionNodes = entry.getValue();

            TrafficChangeRequest changeRequestObject = new TrafficChangeRequest();
            changeRequestObject.setTemplate(policyUpdateRequestTemplateName);
            Field devicesField = new Field();
            devicesField.setName("devices");
            devicesField.setValues(Arrays.asList(algosecDeviceName));
            changeRequestObject.setFields(Arrays.asList(devicesField));

            List<Traffic> trafficChangeRequests = new ArrayList<>(createActionNodes.size());

            createActionNodes.forEach(actionNode -> {
                Traffic traffic = convertToTraffic(actionNode, algosecDeviceName, changeRententionType, objectsData);
                traffic.setAction(IConstant.ALGOSEC_CHANGE_ACTION_TYPE_ALLOW);
                trafficChangeRequests.add(traffic);
            });

            changeRequestObject.setTraffic(trafficChangeRequests);
            changeRequestObjects.add(changeRequestObject);
        }
        return changeRequestObjects;
    }

    private Traffic convertToTraffic(JsonNode policyUpdateRequestNode, String algosecDeviceName, IConstant.AlgosecChangeRententionType changeRententionType, ObjectsData objectsData) {
        String sourceAddressText = policyUpdateRequestNode.has("source_address") ? policyUpdateRequestNode.get("source_address").asText() : null;
        String destinationAddressText = policyUpdateRequestNode.has("destination_address") ? policyUpdateRequestNode.get("destination_address").asText() : null;
        String service = policyUpdateRequestNode.has("service") ? policyUpdateRequestNode.get("service").asText() : null;

        Traffic traffic = new Traffic();
        String[] sourceAddresses = sourceAddressText.split(",");
        String[] destinationAddresses = destinationAddressText.split(",");

        createSourceObjects(traffic, sourceAddresses, algosecDeviceName, changeRententionType, objectsData);
        createDestinatonObjects(traffic, destinationAddresses, algosecDeviceName, changeRententionType, objectsData);

        Service serviceObj = createServiceObject(algosecDeviceName, changeRententionType, service, objectsData);
        traffic.setService(serviceObj);

        return traffic;
    }

    @NotNull
    private Service createServiceObject(String algosecDeviceName, IConstant.AlgosecChangeRententionType changeRententionType, String service, ObjectsData objectsData) {
        Service serviceObj = new Service();
        String[] serviceNames = service.split(",");
        for (String serviceName : serviceNames) {
            if (IConstant.ANY.equalsIgnoreCase(serviceName)) {
                createServiceItemObject(serviceObj, serviceName);
                continue;
            }
            if (changeRententionType == IConstant.AlgosecChangeRententionType.TEMPORARY) {

                //first check if this service value is an object
                List<String> resolvedServiceNames = objectsResolver.resolveIfObject(serviceName, algosecDeviceName, IConstant.AlgosecObjectType.SERVICE, objectsData);
                if (!resolvedServiceNames.isEmpty()) { //object resolved
                    resolvedServiceNames.forEach(resolvedServiceName -> {
                        createServiceItemObject(serviceObj, resolvedServiceName);
                    });
                } else { //object not resolved so check if valid protocol + port
                    String protocolName = null;
                    String port = "*";
                    if (serviceName.contains("_") || serviceName.contains("/")) { //could be a regular service such as tcp/443
                        boolean protocolValid = false;
                        boolean portValid = false;
                        String[] serviceNameComponents = serviceName.split("_|/");
                        if (serviceNameComponents.length != 2) {
                            throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), String.format(errorConfig.getMessage().getInvalidService(), serviceName));
                        }
                        protocolName = serviceNameComponents[0];
                        port = serviceNameComponents[1];
                        if (util.isProtocolNameValid(protocolName)) {
                            protocolValid = true;
                        } else {
                            throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), String.format(errorConfig.getMessage().getInvalidProtocol(), protocolName, serviceName));
                        }
                        if (util.isPortNumberValid(port)) {
                            portValid = true;
                        } else {
                            throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), String.format(errorConfig.getMessage().getInvalidPort(), port, serviceName));
                        }
                        if (protocolValid && portValid) {
                            serviceName = String.join("/", protocolName, port);
                            createServiceItemObject(serviceObj, serviceName);
                        }
                    }
                }
            } else {
                if (objectsData.getDeviceNameServiceObjectDetailsMap().get(algosecDeviceName).containsKey(serviceName)) {
                    createServiceItemObject(serviceObj, serviceName);
                } else { //could be a regular service such as tcp/443
                    String[] serviceNameComponents = serviceName.split("_|/");
                    if (serviceNameComponents.length == 2 && util.isProtocolNameValid(serviceNameComponents[0]) && util.isPortNumberValid(serviceNameComponents[1])) {
                        //this is a service object
                        serviceName = String.join("/", serviceNameComponents[0], serviceNameComponents[1]);
                        createServiceItemObject(serviceObj, serviceName);
                    }
                }
            }
        }
        return serviceObj;
    }

    private void createServiceItemObject(Service serviceObj, String serviceName) {
        ServiceItem serviceItem = new ServiceItem();
        serviceItem.setService(serviceName);
        serviceObj.getItems().add(serviceItem);
    }

    private void createSourceObjects(Traffic traffic, String[] sourceAddresses, String algosecDeviceName, IConstant.AlgosecChangeRententionType changeRententionType, ObjectsData objectsData) {
        for (String sourceAddress : sourceAddresses) {
            if (util.IsIpRange(sourceAddress) || util.isIpValid(netmaskUtil.santizeIPAddress(sourceAddress))) {
                createSourceObject(sourceAddress, traffic);
            } else {
                if (changeRententionType == IConstant.AlgosecChangeRententionType.TEMPORARY) {
                    //resolve if object
                    List<String> resolvedSourceAddresses = objectsResolver.resolveIfObject(sourceAddress, algosecDeviceName, IConstant.AlgosecObjectType.NETWORK, objectsData);
                    if (resolvedSourceAddresses.isEmpty()) {
                        throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), String.format(errorConfig.getMessage().getInvalidPolicyUpdateSource(), sourceAddress));
                    } else {
                        resolvedSourceAddresses.forEach(resolvedSourceAddress -> {
                            createSourceObject(resolvedSourceAddress, traffic);
                        });
                    }
                } else {
                    //final requests creation...use object names as is
                    createSourceObject(sourceAddress, traffic);
                }
            }

        }
    }

    private void createDestinatonObjects(Traffic traffic, String[] destinationAddresses, String algosecDeviceName, IConstant.AlgosecChangeRententionType changeRententionType, ObjectsData objectsData) {
        for (String destinationAddress : destinationAddresses) {
            if (util.IsIpRange(destinationAddress) || util.isIpValid(netmaskUtil.santizeIPAddress(destinationAddress))) {
                createDestinationObject(destinationAddress, traffic);
            } else {
                if (changeRententionType == IConstant.AlgosecChangeRententionType.TEMPORARY) {
                    //resolve if object
                    List<String> resolvedDestinationAddresses = objectsResolver.resolveIfObject(destinationAddress, algosecDeviceName, IConstant.AlgosecObjectType.NETWORK, objectsData);
                    if (resolvedDestinationAddresses.isEmpty()) {
                        throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), String.format(errorConfig.getMessage().getInvalidPolicyUpdateDestination(), destinationAddress));
                    } else {
                        resolvedDestinationAddresses.forEach(resolvedSourceAddress -> {
                            createDestinationObject(resolvedSourceAddress, traffic);
                        });
                    }
                } else {
                    //final requests creation...use object names as is
                    createDestinationObject(destinationAddress, traffic);
                }
            }
        }
    }

    private void createDestinationObject(String destinationAddressText, Traffic traffic) {
        if (traffic.getDestination() == null) {
            traffic.setDestination(new Destination());
        }
        if (traffic.getDestination().getItems() == null) {
            traffic.getDestination().setItems(new ArrayList<>());
        }
        AddressItem destinationAddressItem = new AddressItem();
        destinationAddressItem.setAddress(destinationAddressText);
        traffic.getDestination().getItems().add(destinationAddressItem);
    }

    private void createSourceObject(String sourceAddressText, Traffic traffic) {
        if (traffic.getSource() == null) {
            traffic.setSource(new Source());
        }
        if (traffic.getSource().getItems() == null) {
            traffic.getSource().setItems(new ArrayList<>());
        }
        AddressItem sourceAddressItem = new AddressItem();
        sourceAddressItem.setAddress(sourceAddressText);
        traffic.getSource().getItems().add(sourceAddressItem);
    }
}
