package com.ibm.sec.repository;

import com.ibm.sec.model.FirewallChangeRequestEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FirewallChangeRequestRepository extends JpaRepository<FirewallChangeRequestEntity, Integer>{
    FirewallChangeRequestEntity findBySessionId(String sessionId);
}
