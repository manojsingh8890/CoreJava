package com.ibm.sec.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class JsonUtil {

    private static final ObjectMapper mapper = new ObjectMapper();

    /**
     * Convert Json string to JsonNode
     * @param data
     * @return
     * @throws JsonProcessingException
     */
    public JsonNode parse(String data) throws JsonProcessingException {
        return mapper.readTree(data);
    }

    /**
     * Convert Json string to the specified class
     * @param data
     * @param clazz
     * @param <T>
     * @return
     * @throws JsonProcessingException
     */
    public <T> T parse(String data, Class<T> clazz) throws JsonProcessingException {
        return mapper.readValue(data, clazz);
    }

    /**
     * Convert JsonNode to string
     * @param node
     * @return
     * @throws JsonProcessingException
     */
    public String toString(JsonNode node) throws JsonProcessingException {
        return mapper.writeValueAsString(node);
    }

    public String toString(Object object) throws JsonProcessingException {
        return mapper.writeValueAsString(object);
    }

    public List<Map> getFieldValuesAsMaps(String data, String fieldPath) {
        Object document = Configuration.defaultConfiguration().jsonProvider().parse(data);
        return JsonPath.read(document, fieldPath);
    }

    /**
     * Returns the one or more values associated with the key
     * @param data key from the json to search
     * @param fieldPath
     * @return
     */
    public List<String> getFieldValuesAsText(String data, String fieldPath) {
        Object document = Configuration.defaultConfiguration().jsonProvider().parse(data);
        return JsonPath.read(document, fieldPath);
    }

    public String getFieldValueAsText(String data, String fieldPath) {
        Object document = Configuration.defaultConfiguration().jsonProvider().parse(data);
        return JsonPath.read(document, fieldPath);
    }

    public int getFieldValueAsInt(String data, String fieldPath) {
        Object document = Configuration.defaultConfiguration().jsonProvider().parse(data);
        return JsonPath.read(document, fieldPath);
    }

    public ObjectNode newNode() {
        return mapper.createObjectNode();
    }

    public ArrayNode newArrayNode() {
        return mapper.createArrayNode();
    }

    public List<String> getValues(ArrayNode arrayNode) {
        List<String> values = new ArrayList<>(arrayNode.size());
        for (int i=0; i < arrayNode.size(); i++ ) {
            values.add(arrayNode.get(i).textValue());
        }
        return values;
    }
}
