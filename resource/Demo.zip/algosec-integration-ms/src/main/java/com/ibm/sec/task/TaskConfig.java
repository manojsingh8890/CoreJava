package com.ibm.sec.task;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

@Configuration
@ComponentScan("com.ibm.sec.task")
@EnableAutoConfiguration
@EnableScheduling
public class TaskConfig {

    @Value("${task_scheduler_thread_pool_size}")
    private int taskSchedulerThreadPoolSize;

    @Bean
    public TaskScheduler taskScheduler() {
        final ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(taskSchedulerThreadPoolSize);
        scheduler.setThreadGroupName("ScheduledTasks-");
        return scheduler;
    }
}
