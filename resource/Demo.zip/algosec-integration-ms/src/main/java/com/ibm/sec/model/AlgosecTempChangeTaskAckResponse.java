package com.ibm.sec.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Response to return to caller when a task to create temporary change requests in Algosec is placed.
 */
@Getter
@Setter
public class AlgosecTempChangeTaskAckResponse {
//    @JsonProperty("Policy Update")
    //private List<AlgosecChangeId> policyUpdates;
    @JsonProperty("SESSION_ID")
    private String sessionId;
}
