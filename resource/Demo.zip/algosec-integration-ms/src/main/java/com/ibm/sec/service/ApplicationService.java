package com.ibm.sec.service;

import com.ibm.sec.model.UserSession;
import com.ibm.sec.util.RestUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * A single point of contact for calling APIs.
 */
@Service
@Slf4j
public class ApplicationService {

    @Autowired
    private RestUtil restUtil;
    @Autowired
    private ServicesConfig servicesConfig;

    /**
     * Input devices containing host name are fetched in this method
     *
     * @param params
     * @return
     */
    public Mono<String> getDevicesWithHostName(UserSession session, String params, boolean callAsAdmin) {
        return restUtil.makeGetCallToMSSAPIs(session, callAsAdmin, servicesConfig.getDeviceUrlWithHostname(), String.class, params);
    }

    /**
     * Input devices containing host name are fetched in this method
     *
     * @param params
     * @return
     */
    public Mono<String> getDevicesWithalgoSecUniqueName(UserSession session, String algosecUniqueNames, boolean callAsAdmin) {
        return restUtil.makeGetCallToMSSAPIs(session, callAsAdmin, servicesConfig.getDeviceUrlWithAlgosecUniqueName(), String.class, algosecUniqueNames);
    }

    /**
     * Updates Change Ids to SOC Ticket Id in field Policy Management Ticket Id
     * @param session
     * @param body
     * @param params
     */
    public Mono<String> updateSocTicket(UserSession session, String body, String params, boolean callAsAdmin) {
        return restUtil.makePutCallToMSSAPIs(session, callAsAdmin, servicesConfig.getUpdateSocTicketUrl(), body, String.class, params);
    }

    /**
     * Input devices containing host name are fetched in this method
     *
     * @param params
     * @return
     */
    public Mono<String> getSocTicket(UserSession session, String params, boolean callAsAdmin) {
        return restUtil.makeGetCallToMSSAPIs(session, callAsAdmin, servicesConfig.getUpdateSocTicketUrl(), String.class, params);
    }
}