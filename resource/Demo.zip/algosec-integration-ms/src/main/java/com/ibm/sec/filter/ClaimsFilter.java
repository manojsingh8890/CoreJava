package com.ibm.sec.filter;

import com.ibm.sec.model.UserSession;
import com.ibm.sec.model.algosec.FireFlowAPIAuthResponse;
import com.ibm.sec.service.AlgosecService;
import com.ibm.sec.util.IConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * A servlet filter to intercept all requests.
 */
@Slf4j
public class ClaimsFilter implements Filter {

    @Autowired
    private AlgosecService algosecService;

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        UserSession session = new UserSession();
        session.setAuthHeaderValue(request.getHeader("Authorization"));
        RequestContextHolder.currentRequestAttributes().setAttribute(IConstant.USER_SESSION_REQ_ATTR_KEY, session, RequestAttributes.SCOPE_REQUEST);
        filterChain.doFilter(servletRequest, servletResponse);
    }
}
