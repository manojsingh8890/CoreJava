package com.ibm.sec.model.algosec;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FireFlowAPIAuthRequest {

    @JsonProperty("username")
    private String userName;
    private String password;
}
