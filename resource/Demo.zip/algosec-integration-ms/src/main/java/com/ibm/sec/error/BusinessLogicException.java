package com.ibm.sec.error;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * This is custom exception, solely meant for business logic validation errors. For any technical errors regular Exception types must be used.
 */
@Getter
public class BusinessLogicException extends RuntimeException {

    private String httpStatus;
    private String code;
    private String message;
    private String sessionId;

    public BusinessLogicException(String httpStatus, String code, String message) {
        init(httpStatus, code, message);
    }

    public BusinessLogicException(String httpStatus, String code, String message, Throwable cause) {
        super(cause);
        init(httpStatus, code, message);
    }

    private void init(String httpStatus, String code, String message) {
        this.httpStatus = httpStatus;
        this.code = code;
        this.message = message;
    }
}
