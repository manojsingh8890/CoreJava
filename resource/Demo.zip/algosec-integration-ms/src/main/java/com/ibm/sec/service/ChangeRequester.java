package com.ibm.sec.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.ibm.sec.model.AlgosecChangeId;
import com.ibm.sec.model.Devices;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.util.IConstant;

import java.util.List;

public interface ChangeRequester {

    public List<AlgosecChangeId> createChangeRequest(JsonNode firewallChanges, Devices devices, IConstant.AlgosecChangeRententionType changeRententionType, ObjectsData objectsData, UserSession session) throws Exception;
}
