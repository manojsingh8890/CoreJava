package com.ibm.sec.task;

import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Repesents a queue of tasks where a task is represented by a session_id that relates a single session between the consumer of this microservice and the microservice.
 * respect to Algosec.
 */
@Component
public class TaskQueue {
    private ConcurrentLinkedQueue<ObjectChangeStatusCheckerTask> queue = new ConcurrentLinkedQueue<>();

    /**
     * Adds a session id to the tail of the queue. This is a non-blocking operation.
     * @param task
     */
    public void addTask(ObjectChangeStatusCheckerTask task) {
        queue.offer(task);
    }

    /**
     * Returns an Optional session id. If the queue is empty the Optional will be empty. It is a non-blocking operation.
     * @return Optional
     */
    public Optional<ObjectChangeStatusCheckerTask> getTask() {
        return Optional.ofNullable(queue.poll());
    }

    /**
     * Checks if the task is already added to the queue or not.
     * @return Optional
     */
    public boolean hasTask(ObjectChangeStatusCheckerTask task) {
        return queue.contains(task);
    }


}
