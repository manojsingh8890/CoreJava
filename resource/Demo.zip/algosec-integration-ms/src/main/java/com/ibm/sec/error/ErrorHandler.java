package com.ibm.sec.error;

import com.ibm.sec.model.Error;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.util.IConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

/**
 * A centralized error handler to intercept exceptions thrown during processing of a request and
 * return an appropriate error response to the caller with a meaningful message, an error code and appropriate HTTP status code.
 */
@ControllerAdvice
@Slf4j
public class ErrorHandler extends ResponseEntityExceptionHandler {

    @Autowired
    private ErrorConfig errorConfig;
    //@Autowired
    //private UserSession userSession;

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        List<String> errorMessages = new ArrayList<>();
        ex.getBindingResult().getAllErrors().forEach(error -> errorMessages.add(error.getDefaultMessage()));
        return buildResponseFromError(errorMessages, String.valueOf(status.value()), String.valueOf(status.value()));
    }

    /**
     * All custom Exceptions thrown from the source code are handled here
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(value = {BusinessLogicException.class})
    protected ResponseEntity<Object> handleApplicationError(BusinessLogicException ex) {
        UserSession userSession = (UserSession) RequestContextHolder.currentRequestAttributes().getAttribute(IConstant.USER_SESSION_REQ_ATTR_KEY, RequestAttributes.SCOPE_REQUEST);
        log.error(String.format("SessionId: %s Error occurred: %s", userSession.getUserName(), userSession.getThreadUuid(), ex.getMessage()), ex);
        return buildErrorResponseEntity(ex.getHttpStatus(), ex.getCode(), ex.getMessage());
    }

    /**
     * This method is invoked when json request is converted to PCRTicketRequest object and validator is applied to that object
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(value = {ConstraintViolationException.class})
    protected ResponseEntity<Object> handleConstraintViolations(ConstraintViolationException ex) {
        List<String> errorMessages = new ArrayList<>();
        ex.getConstraintViolations().forEach(violation -> errorMessages.add(violation.getMessage()));
        return buildResponseFromError(errorMessages, String.valueOf(HttpStatus.BAD_REQUEST.value()), String.valueOf(HttpStatus.BAD_REQUEST.value()));
    }

    /**
     * All other exception are handled here
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(value = {Exception.class})
    protected ResponseEntity<Object> handleEverythingElse(Exception ex) {
        return translateErrorToResponse(ex);
    }

    private ResponseEntity<Object> buildErrorResponseEntity(String httpStatus, String errorCode, String message) {
        Error error = new Error();
        error.setCode(errorCode);
        error.setMessage(message);
        return new ResponseEntity<>(error, HttpStatus.resolve(Integer.parseInt(httpStatus)));
    }

    /**
     *  Translate certain type of exceptions into error responses. For the rest of the exception types builds an error response with Internal Error message.
     */
    private ResponseEntity<Object> translateErrorToResponse(Exception ex) {
        UserSession userSession = (UserSession) RequestContextHolder.currentRequestAttributes().getAttribute(IConstant.USER_SESSION_REQ_ATTR_KEY, RequestAttributes.SCOPE_REQUEST);
        log.error(String.format("SessionId: %s Error occurred: %s", userSession.getSessionId(), ex.getMessage()), ex);
        if(ex.getClass() == WebClientResponseException.Unauthorized.class || ex.getClass() == HttpClientErrorException.Unauthorized.class) {
            return buildErrorResponseEntity(errorConfig.getHttpStatus().getUnauthorized(), errorConfig.getCode().getUnauthorized(), errorConfig.getMessage().getUnauthorized());
        }
        if(ex.getClass() == WebClientResponseException.Forbidden.class || ex.getClass() == HttpClientErrorException.Forbidden.class) {
            return buildErrorResponseEntity(errorConfig.getHttpStatus().getForbidden(), errorConfig.getCode().getForbidden(), errorConfig.getMessage().getForbidden());
        }
        return buildErrorResponseEntity(errorConfig.getHttpStatus().getInternalError(), errorConfig.getCode().getInternalError(), errorConfig.getMessage().getInternalError());
    }

    /**
     * Takes a list of error messages along with http status and error code, appends the messages and returns a response entity.
     */
    private ResponseEntity<Object> buildResponseFromError(List<String> errorMessages, String httpStatus, String code) {
        StringBuilder errors = new StringBuilder();
        errorMessages.forEach(error -> errors.append(error).append(' '));
        if (errors.charAt(errors.length() - 1) == ' ') {
            errors.deleteCharAt(errors.length() - 1);
        }
        return buildErrorResponseEntity(httpStatus, code, errors.toString());
    }
}
