package com.ibm.sec.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.ibm.sec.error.BusinessLogicException;
import com.ibm.sec.error.ErrorConfig;
import com.ibm.sec.model.AlgosecChangeId;
import com.ibm.sec.model.Devices;
import com.ibm.sec.model.UserSession;
import com.ibm.sec.model.algosec.ObjectChangeRequest;
import com.ibm.sec.model.algosec.RequestAction;
import com.ibm.sec.model.algosec.RequestedAction;
import com.ibm.sec.util.*;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.cert.ocsp.Req;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;

import javax.swing.*;
import java.util.*;
import java.util.stream.Stream;
/**
 * This class takes Object Update section of PCR Firewall template, generates the Object Change request and calls the algosec APIs
 * to generate a change ID.
 */
@Component
@Slf4j
public class ObjectChangeRequester implements ChangeRequester {

    @Value("${object_update_rquest_template}")
    private String objectUpdateRequestTemplate;
    @Autowired
    private JsonUtil jsonUtil;
    @Autowired
    private RestUtil restUtil;
    @Autowired
    private ServicesConfig servicesConfig;
    @Autowired
    private ErrorConfig errorConfig;
    @Autowired
    private NetmaskUtil netmaskUtil;
    @Autowired
    private AlgosecService algosecService;
    @Autowired
    private Util util;
    @Autowired
    private ObjectsUtil objectsUtil;

    /**
     * This method creates Object Change Requests in Algosec
     * @param firewallChanges Input Json for traffic change
     * @param devices
     * @param changeRententionType TEMPORARY / FINAL*/
    @Override
    public List<AlgosecChangeId> createChangeRequest(JsonNode firewallChanges, Devices devices, IConstant.AlgosecChangeRententionType changeRententionType, ObjectsData objectsData, final UserSession session) throws Exception {
        List<AlgosecChangeId> changeIds = new ArrayList<>();
        if(firewallChanges.has(IConstant.OBJECT_UPDATE_CHANGES)) {
            JsonNode objectUpdateChanges = firewallChanges.get(IConstant.OBJECT_UPDATE_CHANGES);
            Map<String, List<JsonNode>> remedyDeviceNamePolicyCreateChangeNodesMap = new HashMap<String, List<JsonNode>>();
            //Group changes by device name
            for (JsonNode objectUpdateChange : objectUpdateChanges) {
                String remedyDeviceName = objectUpdateChange.get("firewall_policy").asText();
               // if (IConstant.CHANGE_ACTION_TYPE_CREATE.equals(objectUpdateChange.get("action").asText())) {
                    if (!remedyDeviceNamePolicyCreateChangeNodesMap.containsKey(remedyDeviceName)) {
                        remedyDeviceNamePolicyCreateChangeNodesMap.put(remedyDeviceName, new ArrayList<JsonNode>());
                    }
                    remedyDeviceNamePolicyCreateChangeNodesMap.get(remedyDeviceName).add(objectUpdateChange);
               // }
            }
//             =algoSecDeviceNameObjectChangesMap.entrySet().stream().map(entry -> {
//                try {
//                    return doObjectChangeByDevice(entry.getKey(), entry.getValue(), session);
//                } catch (JsonProcessingException e) {
//                    log.error("Error parsing JSON for object changes for device " + entry.getKey() + " for session id::" + session.getSessionId());
//                    throw new BusinessLogicException(errorConfig.getHttpStatus().getInternalError(), errorConfig.getCode().getInternalError(), errorConfig.getMessage().getInternalError());
//                }
//            }).collect(Collectors.toList());
            List<ObjectChangeRequest> objectChangeRequestObjects = createObjectChangeRequestObjects(remedyDeviceNamePolicyCreateChangeNodesMap, devices);
            if(!objectChangeRequestObjects.isEmpty()) {
                Object[] responses = algosecService.createObjectChangeRequest(objectChangeRequestObjects, session);
                for (int r = 0; r < responses.length; r++) {
                    ClientResponse response = (ClientResponse) responses[r];
                    ResponseEntity<String> responseEntity = response.toEntity(String.class).block();
                    String responseBody = responseEntity.getBody();
                    if (response.rawStatusCode() != 200) {
                        log.error("Algosec object change request API call failed with http status code:" + response.rawStatusCode() + " and error response is:" + responseBody);
                        throw new BusinessLogicException(errorConfig.getHttpStatus().getInternalError(), errorConfig.getCode().getInternalError(), errorConfig.getMessage().getInternalError());
                    } else {
                        AlgosecChangeId changeId = new AlgosecChangeId();
                        changeId.setChangeId(String.valueOf(jsonUtil.getFieldValueAsInt(responseBody, "$.data.changeRequestId")));
                        changeId.setChangeType(IConstant.AlgosecChangeType.OBJECT);
                        changeIds.add(changeId);
                    }
                }
            }
        }
        return changeIds;
    }

    private List<ObjectChangeRequest> createObjectChangeRequestObjects(Map<String, List<JsonNode>> remedyDeviceNamePolicyCreateChangeNodesMap, Devices devices) {
        List<ObjectChangeRequest> changeRequestObjects = new ArrayList<>();
        Set<Map.Entry<String, List<JsonNode>>> set = remedyDeviceNamePolicyCreateChangeNodesMap.entrySet();
        for(Map.Entry<String, List<JsonNode>> entry : set) {
            String remedyDeviceName = entry.getKey();
            List<JsonNode> objectUpdateChanges = entry.getValue();

            ObjectChangeRequest objectChangeRequest = new ObjectChangeRequest();
            objectChangeRequest.setTemplate(objectUpdateRequestTemplate);
            objectChangeRequest.getDevices().add(devices.getRemedyDeviceNameAlgosecNameMap().get(remedyDeviceName));
            objectUpdateChanges.forEach(objectUpdateChange -> {
                RequestedAction action = makeRequestedActionObject(objectUpdateChange);
                objectChangeRequest.getRequestedActions().add(action);
            });
            Collections.sort(objectChangeRequest.getRequestedActions(), new Comparator<RequestedAction>() {
                @Override
                public int compare(RequestedAction abc1, RequestedAction abc2) {
                    return Boolean.compare(new Boolean(abc1.getIsGroup()),new Boolean(abc2.getIsGroup()));
                }
            });
            changeRequestObjects.add(objectChangeRequest);
        }
        return changeRequestObjects;
    }

//    @NotNull
//    private AlgosecChangeId doObjectChangeByDevice(String algoSecDeviceName, ArrayNode objectUpdateChanges, UserSession session) throws JsonProcessingException {
//        AlgosecChangeId changeId = new AlgosecChangeId();
//        changeId.setChangeType(IConstant.CHANGE_TYPE_OBJECT);
//
//        ObjectChangeRequest objectChangeRequest = new ObjectChangeRequest();
//        objectChangeRequest.setTemplate(objectUpdateRequestTemplate);
//        objectChangeRequest.getDevices().add(algoSecDeviceName);
//        makeRequestSectionForObjectCreateChanges(objectUpdateChanges, objectChangeRequest);
//        if(objectChangeRequest.getRequestedActions().isEmpty()) { //there are no changes to make
//            changeId.setChangeId(null);
//            return changeId;
//        }
//
//        String cookieHeader = String.format("FireFlow_Session=%s", session.getAlgoSecSessionId());
//        Map<String, String> headers = new HashMap<>();
//        headers.put("Cookie", cookieHeader);
//        log.info(jsonUtil.toString(objectChangeRequest));
//        Mono<ClientResponse> responseMono = restUtil.makePostCallToAlgosecAPIs(session, servicesConfig.getAlgosecFireflowObjectChangeRequestUrl(), headers, objectChangeRequest);
//        ClientResponse response = responseMono.block();
//        ResponseEntity<String> responseEntity = response.toEntity(String.class).block();
//        String responseBody = responseEntity.getBody();
//        if(response.rawStatusCode() != 200) {
//            log.error("Algosec change request API call failed with http status code:" + response.rawStatusCode() + " and error response is:" + responseBody + " for session id::" + session.getSessionId());
//            throw new BusinessLogicException(errorConfig.getHttpStatus().getInternalError(), errorConfig.getCode().getInternalError(), errorConfig.getMessage().getInternalError());
//        } else {
//            changeId.setChangeId(String.valueOf(jsonUtil.getFieldValueAsInt(responseBody, "$.data.changeRequestId")));
//            return changeId;
//        }
//    }

    private RequestedAction makeRequestedActionObject(JsonNode objectUpdateChange) {
        String actionType = objectUpdateChange.get("action").asText();
        String objectType = objectUpdateChange.get("object_type").asText();
        if(actionType.equals(IConstant.CHANGE_ACTION_TYPE_CREATE) && objectsUtil.shouldProcessObjectChange(objectUpdateChange)) {
            RequestedAction action = new RequestedAction();
            action.setGroupType(objectUpdateChange.get("object_type").asText());
            action.setAction("create");
            action.setName(objectUpdateChange.get("object_name").asText());
            List<String> values = new ArrayList<>();
            if(Stream.of(IConstant.OBJECT_GROUP_TYPE_HOST, IConstant.OBJECT_GROUP_TYPE_NETWORK).anyMatch(objectType::equals)) {
                action.setType("network");
                String[] actionItems = objectUpdateChange.get("action_items").asText().split(",");
                values.addAll(Arrays.asList(actionItems));
                if(values.size() == 1) {
                    String ipAddressCandidate = netmaskUtil.santizeIPAddress(values.get(0));
                    if(util.isIpValid(ipAddressCandidate)) {
                        values.set(0, ipAddressCandidate);
                    } else {
                        throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), String.format(errorConfig.getMessage().getInvalidIpAddress(), ipAddressCandidate));
                    }
                }

            }else if (objectType.equals(IConstant.OBJECT_GROUP_TYPE_NETWORK_GROUP)){
                action.setType("network");
                String[] actionItems = objectUpdateChange.get("action_items").asText().split(",");
                values.addAll(Arrays.asList(actionItems));
            } else if(objectType.equals(IConstant.OBJECT_GROUP_TYPE_SERVICE)) {
                action.setType("service");
                String[] serviceObjectValue = objectUpdateChange.get("action_items").asText().split("_|/"); //_ and / both are acceptable
                if(serviceObjectValue.length == 2 && util.isProtocolNameValid(serviceObjectValue[0]) && util.isPortNumberValid(serviceObjectValue[1])) {
                    values.add(String.join("/", serviceObjectValue[0], serviceObjectValue[1]));
                } else {
                        throw new BusinessLogicException(errorConfig.getHttpStatus().getBadRequest(), errorConfig.getCode().getBadRequest(), String.format(errorConfig.getMessage().getInvalidObjectDefinition(), serviceObjectValue));
                }
            }else if(objectType.equals(IConstant.OBJECT_GROUP_TYPE_SERVICE_GROUP)){
                action.setType("service");
                String[] actionItems = objectUpdateChange.get("action_items").asText().split(",");
                values.addAll(Arrays.asList(actionItems));
            }

            if(values.size() > 1) { //if multiple values it's a group
                action.setIsGroup("true");
            } else {
                action.setIsGroup("false");
            }
            action.setValues(values);
            return action;
        }else if(actionType.equals(IConstant.ALGOSEC_ACTION_TYPE_DELETE) && objectsUtil.shouldProcessObjectChange(objectUpdateChange)) {
            RequestedAction action = new RequestedAction();
            if(Stream.of(IConstant.OBJECT_GROUP_TYPE_HOST, IConstant.OBJECT_GROUP_TYPE_NETWORK, IConstant.OBJECT_GROUP_TYPE_NETWORK_GROUP).anyMatch(objectType::equals)) {
                action.setType("network");
            }else if(Stream.of(IConstant.OBJECT_GROUP_TYPE_SERVICE, IConstant.OBJECT_GROUP_TYPE_SERVICE_GROUP).anyMatch(objectType::equals)) {
                action.setType("service");
            }
            action.setAction("delete");
            action.setGroupType(objectUpdateChange.get("object_type").asText());
            action.setName(objectUpdateChange.get("object_name").asText());
            String[] actionItems = objectUpdateChange.get("action_items").asText().split(",");

            if(actionItems.length > 1) { //if multiple values it's a group
                action.setIsGroup("true");
            } else {
                action.setIsGroup("false");
            }
            return action;
        }else if(actionType.equals(IConstant.ALGOSEC_ACTION_TYPE_ADD_TO) && objectsUtil.shouldProcessObjectChange(objectUpdateChange)){
            RequestedAction action = new RequestedAction();
            action.setAction("addObjectsToGroup");
            action.setGroupType(objectUpdateChange.get("object_type").asText());
            if(Stream.of(IConstant.OBJECT_GROUP_TYPE_HOST, IConstant.OBJECT_GROUP_TYPE_NETWORK, IConstant.OBJECT_GROUP_TYPE_NETWORK_GROUP).anyMatch(objectType::equals)) {
                action.setType("network");
            }else if(Stream.of(IConstant.OBJECT_GROUP_TYPE_SERVICE, IConstant.OBJECT_GROUP_TYPE_SERVICE_GROUP).anyMatch(objectType::equals)) {
                action.setType("service");
            }
            action.setName(objectUpdateChange.get("object_name").asText());
            String[] actionItems = objectUpdateChange.get("action_items").asText().split(",");
            List<String> values = new ArrayList<>();
            values.addAll(Arrays.asList(actionItems));

            if(actionItems.length> 1) { //if multiple values it's a group
                action.setIsGroup("true");
            } else {
                action.setIsGroup("false");
            }
            action.setValues(values);
            return action;
        }else if(actionType.equals(IConstant.ALGOSEC_ACTION_TYPE_REMOVE_FROM) && objectsUtil.shouldProcessObjectChange(objectUpdateChange)){
            {
                RequestedAction action = new RequestedAction();
                action.setAction("removeObjectsFromGroup");
                action.setGroupType(objectUpdateChange.get("object_type").asText());
                if(Stream.of(IConstant.OBJECT_GROUP_TYPE_HOST, IConstant.OBJECT_GROUP_TYPE_NETWORK, IConstant.OBJECT_GROUP_TYPE_NETWORK_GROUP).anyMatch(objectType::equals)) {
                    action.setType("network");
                }else if(Stream.of(IConstant.OBJECT_GROUP_TYPE_SERVICE, IConstant.OBJECT_GROUP_TYPE_SERVICE_GROUP).anyMatch(objectType::equals)) {
                    action.setType("service");
                }
                action.setName(objectUpdateChange.get("object_name").asText());
                String[] actionItems = objectUpdateChange.get("action_items").asText().split(",");
                List<String> values = new ArrayList<>();
                values.addAll(Arrays.asList(actionItems));

                if(values.size() > 1) { //if multiple values it's a group
                    action.setIsGroup("true");
                } else {
                    action.setIsGroup("false");
                }
                action.setValues(values);
                return action;
            }
        }
        else {
            return null;
        }
    }
}
