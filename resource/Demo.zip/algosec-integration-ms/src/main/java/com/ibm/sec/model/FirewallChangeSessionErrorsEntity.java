package com.ibm.sec.model;

import com.ibm.sec.util.IConstant;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Table(name = "firewall_change_session_errors")
@Entity
@Getter
@Setter
@EqualsAndHashCode
public class FirewallChangeSessionErrorsEntity implements java.io.Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;

    @Column(name="SESSION_ID")
    private String sessionId;

    @Column(name="ERROR")
    private String error;

    @Column(name="FUNCTIONALITY")
    @Enumerated(EnumType.STRING)
    private IConstant.Functionality functionality;
}