package com.ibm.sec.model;

import com.ibm.sec.util.IConstant;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AlgosecChangeId {
    private IConstant.AlgosecChangeType changeType;
    private String changeId;
}
