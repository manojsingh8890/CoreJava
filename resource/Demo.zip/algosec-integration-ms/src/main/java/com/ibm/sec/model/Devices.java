package com.ibm.sec.model;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
public class Devices {
    private List<String> remedyDeviceNames = new ArrayList<>();
    private Map<String, String> remedyDeviceNameAlgosecNameMap = new HashMap<>();
    private List<String> remedyDeviceIds = new ArrayList<>();
}
